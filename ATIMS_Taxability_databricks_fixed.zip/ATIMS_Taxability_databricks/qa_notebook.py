# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.5 — QA
# MAGIC
# MAGIC Six statistical / consistency checks via Spark window functions + JOINs,
# MAGIC computed over the **full month's unified records** (AUDIT B8) so vendor /
# MAGIC category / amount distributions are not biased to the ML subset.
# MAGIC
# MAGIC 1. Vendor-category consistency  2. Amount z-score  3. State-category history
# MAGIC 4. Rule-vs-classifier conflict  5. Taxability sanity  6. Batch-level outlier
# MAGIC
# MAGIC Output: `anomalies`, `anomaly_score`, `review_priority`, `override_suggested`.
# MAGIC Re-route (3.6) is only suggested for ML rows; rule/RAG anomalies escalate.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql import Window
from pyspark.sql.functions import col, lit, when, count, array, array_compact
from pyspark.sql.functions import avg, stddev, abs as sabs

df = read_stage(spark, STAGE["tax_writer"])
zflag = PARAMS["amount_z_flag"]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check 1 — vendor-category consistency  &  Check 6 — batch outlier

# COMMAND ----------

# Vendor-consistency flags. Use vendor_id if present, else fall back to
# vendor_name (the legacy rule data keys vendors by name, not id).
_vendor_key = "vendor_id" if "vendor_id" in df.columns else "vendor_name"
w_vendor      = Window.partitionBy(_vendor_key)
w_vendor_cat  = Window.partitionBy(_vendor_key, "final_category")

df = (df
      .withColumn("_vendor_cat_freq", count("*").over(w_vendor_cat))
      .withColumn("_vendor_total",    count("*").over(w_vendor))
      .withColumn("_vendor_cat_ratio", col("_vendor_cat_freq") / col("_vendor_total"))
      .withColumn("flag_vendor_inconsistent", col("_vendor_cat_ratio") < lit(0.5))
      .withColumn("flag_batch_outlier",       col("_vendor_cat_ratio") < lit(0.05)))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check 2 — amount z-score within category

# COMMAND ----------

w_cat = Window.partitionBy("final_category")
df = (df
      .withColumn("_amt_mean", avg("amount").over(w_cat))
      .withColumn("_amt_std",  stddev("amount").over(w_cat))
      .withColumn("amount_z",
                  when(col("_amt_std") > 0,
                       sabs((col("amount") - col("_amt_mean")) / col("_amt_std")))
                  .otherwise(lit(0.0)))
      .withColumn("flag_amount_outlier", col("amount_z") > lit(zflag)))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check 3 — state-category history (unseen combo)

# COMMAND ----------

# FAIL-SOFT. This table is optional reference data, and on the first production
# run of a new environment it does not exist yet. Previously the missing table
# raised inside Task 3.5 and killed the whole job after 3.1-3.4 had already
# succeeded. A missing history means "no history to compare against", which is
# not the same as "every combination is new" - so the check is skipped, not
# fired, and the skip is logged.
try:
    hist = (spark.read.table(TABLES["historical_stats"])
                 .select(col("final_category").alias("_h_cat"),
                         col("state").alias("_h_state")).distinct())
    df = (df.join(F.broadcast(hist),
                  (col("final_category") == col("_h_cat")) & (col("state") == col("_h_state")),
                  "left")
            .withColumn("flag_new_state_combo", col("_h_cat").isNull())
            .drop("_h_cat", "_h_state"))
except Exception as e:
    print(f"[3.5] historical_stats unavailable ({type(e).__name__}); "
          f"check 3 (unseen state/category) skipped.")
    df = df.withColumn("flag_new_state_combo", lit(False))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check 4 — rule vs classifier conflict (ML cols may be null on rule rows)

# COMMAND ----------

# xgboost_pred only exists on the ML branch; unionByName leaves it NULL on
# rule/RAG rows, and it is absent entirely when Task 3.2 ran without the
# embedding column. Guard so the check degrades instead of raising.
if "xgboost_pred" not in df.columns:
    print("[3.5] xgboost_pred absent; check 4 (rule vs ML conflict) skipped.")
    df = df.withColumn("flag_rule_ml_conflict", lit(False))
else:
    df = df.withColumn(
        "flag_rule_ml_conflict",
        (col("match_type").isin("det", "rag")) & col("xgboost_pred").isNotNull()
        & (col("final_category") != col("xgboost_pred")))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check 5 — taxability sanity (service taxable in a no-service-tax state)

# COMMAND ----------

# FAIL-SOFT, same reasoning as check 3.
try:
    state_rules = (spark.read.table(TABLES["state_service_rules"])
                        .select(col("state").alias("_s_state"),
                                col("service_taxable").alias("_s_taxable")))
    df = (df.join(F.broadcast(state_rules), col("state") == col("_s_state"), "left")
            .withColumn("flag_tax_sanity",
                        (col("taxability") == "Taxable") & (col("_s_taxable") == lit(False)))
            .drop("_s_state", "_s_taxable"))
except Exception as e:
    print(f"[3.5] state_service_tax_rules unavailable ({type(e).__name__}); "
          f"check 5 (taxability sanity) skipped.")
    df = df.withColumn("flag_tax_sanity", lit(False))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Aggregate → anomaly score, review priority, override suggestion

# COMMAND ----------

flag_cols = ["flag_vendor_inconsistent", "flag_amount_outlier", "flag_new_state_combo",
             "flag_rule_ml_conflict", "flag_tax_sanity", "flag_batch_outlier"]

# Treat null flags as False so missing reference tables don't poison the score.
for c in flag_cols:
    df = df.withColumn(c, F.coalesce(col(c), lit(False)))

score_expr = sum(when(col(c), 1).otherwise(0) for c in flag_cols) / lit(float(len(flag_cols)))
df = (df
      .withColumn("anomaly_score", score_expr)
      .withColumn("anomalies",
                  array_compact(array(*[when(col(c), lit(c)) for c in flag_cols])))
      .withColumn("review_priority",
                  when(col("taxability").isNull(), lit("HIGH"))
                  .when(col("anomaly_score") >= 0.5,  lit("CRITICAL"))
                  .when(col("anomaly_score") >= 0.33, lit("HIGH"))
                  .when(col("anomaly_score") > 0,     lit("MED"))
                  .otherwise(lit("LOW")))
      # Only ML rows are eligible for re-classification (AUDIT B7).
      .withColumn("override_suggested",
                  (col("anomaly_score") >= 0.33) & (col("match_type") == "ml"))
      .withColumn("recommendation", lit(None).cast("string")))

out = df.drop("_vendor_cat_freq", "_vendor_total", "_vendor_cat_ratio",
              "_amt_mean", "_amt_std")

write_stage(out, STAGE["qa"])
print("[3.5] checks that fired:")
for c in flag_cols:
    print(f"    {c:28s} {out.filter(col(c)).count():,}")
print("[3.5] review_priority distribution:")
out.groupBy("review_priority").count().show()
dbutils.notebook.exit("3.5 OK")