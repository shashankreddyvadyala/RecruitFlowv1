# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.8 — MLflow Tracking + UC Model Versioning
# MAGIC
# MAGIC Run this LAST (after 3.7). It does NOT change any pipeline data — it only:
# MAGIC
# MAGIC 1. Logs one consolidated **MLflow run** for the month: params (month, endpoints,
# MAGIC    thresholds, rule counts, rules snapshot hash), metrics (row counts, match-type
# MAGIC    split, review priorities, audit-ready %, taxability split), and artifacts
# MAGIC    (active rules snapshot, pipeline_config, a sample of the output).
# MAGIC 2. Registers a new **version** of the pipeline model in the Unity Catalog model
# MAGIC    registry (`REGISTERED_MODEL`), bundling the exact rules + config + prompt
# MAGIC    manifest that produced this run — i.e. real version control of the logic.
# MAGIC 3. Tags the version and points the `latest` alias at it.
# MAGIC
# MAGIC Everything here is FAIL-SOFT: if registry permissions or MLflow are unavailable,
# MAGIC the run is still logged and the notebook does not crash the job.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

import mlflow, hashlib, json, os
import pandas as pd
from pyspark.sql.functions import col, lit
from mlflow.tracking import MlflowClient

# MLFLOW_REGISTRY_URI / REGISTERED_MODEL / MLFLOW_EXPERIMENT come from config_notebook
mlflow.set_registry_uri(MLFLOW_REGISTRY_URI)
try:
    _user = spark.sql("SELECT current_user() AS u").collect()[0]["u"]
except Exception:
    _user = "unknown"
EXPERIMENT_PATH = MLFLOW_EXPERIMENT or f"/Users/{_user}/atims_phase3"
mlflow.set_experiment(EXPERIMENT_PATH)
print(f"[3.8] experiment={EXPERIMENT_PATH}  registry={MLFLOW_REGISTRY_URI}  model={REGISTERED_MODEL}")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Gather run params, metrics, and artifacts from the output + rule tables

# COMMAND ----------

# Scope to THIS month. The output table is partitioned by `month` and written
# with a partition-scoped overwrite, so it accumulates history — reading it whole
# would blend every month processed to date into one run's metrics.
preds = spark.read.table(TABLES["predictions_out"])
if "month" in [c.lower() for c in preds.columns]:
    preds = preds.filter(col("month") == lit(MONTH))
else:
    print("[3.8] output table has no `month` column; metrics cover the whole table.")
total = preds.count()

def _counts(colname):
    rows = (preds.groupBy(colname).count()
                 .withColumnRenamed("count", "n").collect())
    return {("null" if r[colname] is None else str(r[colname])): int(r["n"]) for r in rows}

mt    = _counts("match_type")
rp    = _counts("review_priority")
tx    = _counts("taxability")
ec    = _counts("ensemble_confidence")
audit = _counts("audit_ready")
# Root cause of every unpriced line — the number that tells you whether the
# review queue is shrinking month over month, and which owner it belongs to.
ts    = _counts("tax_source") if "tax_source" in preds.columns else {}

# Active rules snapshot + a stable hash for the version.
rules = spark.read.table(TABLES["classification_rules"]).filter("active = true")
rules_pd = rules.toPandas().sort_values("rule_id")
rule_total = len(rules_pd)
rules_by_type = {k: int(v) for k, v in rules_pd["rule_type"].value_counts().items()}
rule_hash = hashlib.sha256(rules_pd.to_csv(index=False).encode()).hexdigest()[:16]

# pipeline_config as a dict (best-effort).
try:
    cfg_pd = spark.read.table(TABLES["pipeline_config"]).toPandas()
    config_dict = dict(zip(cfg_pd["config_key"], cfg_pd["config_value"]))
except Exception as e:
    config_dict = {"_error": str(e)}

print(f"[3.8] rows={total:,}  match_type={mt}  tax_source={ts}  "
      f"rules_active={rule_total} hash={rule_hash}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Log the MLflow run (params + metrics + artifacts)

# COMMAND ----------

os.makedirs("/tmp/atims_mlflow", exist_ok=True)
rules_csv = "/tmp/atims_mlflow/active_rules_snapshot.csv"
sample_csv = "/tmp/atims_mlflow/predictions_sample.csv"
rules_pd.to_csv(rules_csv, index=False)
preds.limit(200).toPandas().to_csv(sample_csv, index=False)

manifest = {
    "pipeline_version_month": MONTH,
    "rule_snapshot_sha": rule_hash,
    "rule_total_active": rule_total,
    "rules_by_type": rules_by_type,
    "llm_endpoint": ENDPOINTS["llm"],
    "embedding_endpoint": ENDPOINTS["embedding"],
    "xgboost_endpoint": ENDPOINTS["xgboost"],
    "thresholds": PARAMS,
    "generate_llm_writeups": bool(GENERATE_LLM_WRITEUPS),
    "config": config_dict,
    "output_table": TABLES["predictions_out"],
}
manifest_path = "/tmp/atims_mlflow/manifest.json"
with open(manifest_path, "w") as f:
    json.dump(manifest, f, indent=2, default=str)

params = {
    "month": MONTH, "catalog": CATALOG, "schema": SCHEMA,
    "llm_endpoint": ENDPOINTS["llm"], "embedding_endpoint": ENDPOINTS["embedding"],
    "xgboost_endpoint": ENDPOINTS["xgboost"],
    "generate_llm_writeups": bool(GENERATE_LLM_WRITEUPS),
    "rule_total_active": rule_total, "rule_snapshot_sha": rule_hash,
}
params.update({f"thr_{k}": v for k, v in PARAMS.items()})
params.update({f"rules_{k}": v for k, v in rules_by_type.items()})

metrics = {
    "rows_total": total,
    "match_det": mt.get("det", 0), "match_rag": mt.get("rag", 0), "match_ml": mt.get("ml", 0),
    "review_low": rp.get("LOW", 0), "review_med": rp.get("MED", 0),
    "review_high": rp.get("HIGH", 0), "review_critical": rp.get("CRITICAL", 0),
    "audit_ready_true": audit.get("true", 0) + audit.get("True", 0),
    "audit_pending": audit.get("false", 0) + audit.get("False", 0),
    "ensemble_llm_only": ec.get("LLM_ONLY", 0), "ensemble_resolve": ec.get("RESOLVE", 0),
    "taxable": tx.get("Taxable", 0), "exempt": tx.get("Exempt", 0),
    "taxability_null": tx.get("null", 0),
}

with mlflow.start_run(run_name=f"phase3_{MONTH}") as run:
    RUN_ID = run.info.run_id
    mlflow.set_tags({"phase": "3", "month": MONTH, "rule_snapshot_sha": rule_hash})
    mlflow.log_params(params)
    mlflow.log_metrics({k: float(v) for k, v in metrics.items()})
    mlflow.log_dict(manifest, "manifest.json")
    mlflow.log_dict({"match_type": mt, "review_priority": rp,
                     "taxability": tx, "ensemble": ec, "audit_ready": audit},
                    "run_profile.json")
    mlflow.log_artifact(rules_csv, artifact_path="rules")
    mlflow.log_artifact(sample_csv, artifact_path="sample")
    mlflow.log_artifact(manifest_path, artifact_path="manifest")

print(f"[3.8] logged MLflow run {RUN_ID}")
print(f"[3.8] metrics: {metrics}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Register a versioned pipeline model in the UC registry (fail-soft)

# COMMAND ----------

class ATIMSPipelineModel(mlflow.pyfunc.PythonModel):
    """Version stamp for the Phase 3 pipeline. The heavy scoring runs in the
    Spark notebooks; this registered model captures and versions the exact
    rules snapshot + config + prompt manifest that produced a given run, so the
    UC registry holds one governed, promotable version per release."""
    def load_context(self, context):
        import json
        with open(context.artifacts["manifest"]) as f:
            self.manifest = json.load(f)
    def predict(self, context, model_input):
        import pandas as pd
        v = self.manifest.get("pipeline_version_month")
        h = self.manifest.get("rule_snapshot_sha")
        return pd.Series([f"{v}:{h}"] * len(model_input))

try:
    from mlflow.models.signature import infer_signature
    example = pd.DataFrame({"ping": ["status"]})
    sig = infer_signature(example, pd.Series(["2022-12:abc"]))
    with mlflow.start_run(run_id=RUN_ID):
        info = mlflow.pyfunc.log_model(
            artifact_path="model",
            python_model=ATIMSPipelineModel(),
            artifacts={"manifest": manifest_path,
                       "rules": rules_csv,
                       "config": manifest_path},
            signature=sig,
            input_example=example,
            registered_model_name=REGISTERED_MODEL,
            pip_requirements=["mlflow", "pandas"],
        )
    # Tag the new version + point the 'latest' alias at it.
    client = MlflowClient()
    mv = None
    for rmv in client.search_model_versions(f"name='{REGISTERED_MODEL}'"):
        if rmv.run_id == RUN_ID:
            mv = rmv.version; break
    if mv:
        client.set_model_version_tag(REGISTERED_MODEL, mv, "month", MONTH)
        client.set_model_version_tag(REGISTERED_MODEL, mv, "rows_total", str(total))
        client.set_model_version_tag(REGISTERED_MODEL, mv, "rule_snapshot_sha", rule_hash)
        client.set_registered_model_alias(REGISTERED_MODEL, "latest", mv)
        print(f"[3.8] registered {REGISTERED_MODEL} version {mv} (alias 'latest')")
    else:
        print("[3.8] model logged but version lookup failed; check the registry UI.")
except Exception as e:
    print(f"[3.8] UC model registration skipped ({type(e).__name__}: {e}).")
    print("      The run + metrics + artifacts are still logged. To enable "
          "registration: ensure the cluster can CREATE MODEL in "
          f"{CATALOG}.{SCHEMA} and that UC model registry is enabled.")

dbutils.notebook.exit("3.8 OK")