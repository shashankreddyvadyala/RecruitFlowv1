# Databricks notebook source
# MAGIC %md
# MAGIC # config_notebook — shared Phase 3 configuration & helpers
# MAGIC
# MAGIC `%run` this at the top of every task notebook so all tasks share one source
# MAGIC of truth for the catalog/schema, tables, endpoints, KB indexes, thresholds
# MAGIC and helper functions.
# MAGIC
# MAGIC ```python
# MAGIC %run ./config_notebook
# MAGIC ```
# MAGIC
# MAGIC All tables live under one Unity Catalog namespace
# MAGIC (`31500_atims_dev.atims_taxability` by default). The catalog name starts with
# MAGIC a digit, so it is backtick-quoted everywhere. Rules + thresholds are read from
# MAGIC governed Delta tables (`classification_rules`, `pipeline_config`), not code.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, when

# ---------------------------------------------------------------------------
# Widgets (environment parameters)
# ---------------------------------------------------------------------------
dbutils.widgets.text("catalog", "31500_atims_dev", "Unity Catalog")
dbutils.widgets.text("schema",  "atims_taxability", "Schema")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")

# ---------------------------------------------------------------------------
# Accounting month to process (YYYY-MM). Edit this ONE line to pick the month.
# Deliberately NOT a widget: widget values are sticky per-notebook and were the
# cause of Task 3.1 filtering to an empty month. A plain variable cannot get
# stuck. Must be a month that exists in prediction_ready.<PERIOD_COL>.
#
# PERIOD_COL is the column that defines the tax period. `accounting_date` is the
# default because every line has exactly one accounting month, so consecutive
# monthly runs partition the source with no gaps and no overlaps. `invoice_month`
# does NOT have that property in the real feed — the two disagree on a small
# number of lines each month (48 of 7,281 in the 2023-01 sample), and running on
# invoice_month would silently drop the lines whose invoice and accounting months
# straddle a boundary.
# ---------------------------------------------------------------------------
MONTH      = "2023-01"
PERIOD_COL = "accounting_date"      # "accounting_date" | "invoice_month"

# Clean up any leftover 'month' widget from earlier runs so it can't confuse you.
try:
    dbutils.widgets.remove("month")
except Exception:
    pass

# ---------------------------------------------------------------------------
# Task 3.4 write-up mode. False (default) = fast deterministic templated
# justifications, NO LLM calls — use this for validation runs and while the
# taxability_matrix is still placeholder. True = generate full Opus audit
# write-ups, but ONLY for rows that need an audit narrative (use-tax reversal,
# COMPLEX disagreement, or ML-decided), not every row.
# ---------------------------------------------------------------------------
GENERATE_LLM_WRITEUPS = False

# ---------------------------------------------------------------------------
# MLflow tracking + Unity Catalog model registry (version control).
# Every Phase 3 run is logged as one MLflow run (params/metrics/artifacts) and
# registered as a new version of REGISTERED_MODEL in the UC model registry, so
# each monthly release of the pipeline logic is governed and promotable.
# REGISTERED_MODEL uses the 3-level UC name WITHOUT backticks (MLflow handles it).
# MLFLOW_EXPERIMENT=None -> defaults to /Users/<current_user>/atims_phase3.
# ---------------------------------------------------------------------------
MLFLOW_REGISTRY_URI = "databricks-uc"
MLFLOW_EXPERIMENT   = "/Workspace/Shared/ATIMS_Source/Taxability_MLFlow_Experiment_2"
UC_MODEL_NAME       = "31500_atims_dev.atims_taxability.xgboost_non_norad"
REGISTERED_MODEL    = UC_MODEL_NAME

# Backtick the catalog (it starts with a digit) -> `31500_atims_dev`.atims_taxability.<t>
FQ_SCHEMA = f"`{CATALOG}`.{SCHEMA}"
def _t(name):
    return f"{FQ_SCHEMA}.{name}"

# ---------------------------------------------------------------------------
# Unity Catalog tables (all under one catalog.schema)
# ---------------------------------------------------------------------------
TABLES = {
    # Input (from Phase 2)
    "prediction_ready":     _t("prediction_ready"),
    # Final output (Task 3.7)
    "predictions_out":      _t("non_norad_predictions"),
    # Governed rules + config (created by classification_rules.sql / create_reference_tables)
    "classification_rules": _t("classification_rules"),
    "pipeline_config":      _t("pipeline_config"),
    # Other reference / lookup
    "taxability_matrix":    _t("taxability_matrix"),
    "tax_writeups":         _t("tax_writeups"),
    "category_definitions": _t("category_definitions"),
    "state_service_rules":  _t("state_service_tax_rules"),
    "historical_stats":     _t("historical_stats"),
    # XGBoost label index map (StringIndexer inverse, from Phase 2)
    "xgb_label_index":      _t("xgboost_non_norad_label_index"),
}

# Intermediate task tables (chained between notebook tasks via Delta; same schema)
STAGE = {
    "rules_matched": _t("t31_rules_matched"),
    "rag_matched":   _t("t31_rag_matched"),
    "unmatched":     _t("t31_unmatched"),
    "classified":    _t("t32_classified"),
    "tax_lookup":    _t("t33_tax_lookup"),
    "use_tax":       _t("t33b_use_tax"),
    "tax_writer":    _t("t34_tax_writer"),
    "qa":            _t("t35_qa"),
    "reroute":       _t("t36_reroute"),
}

# ---------------------------------------------------------------------------
# Model Serving + Foundation Model endpoints
# ---------------------------------------------------------------------------
ENDPOINTS = {
    "embedding": "databricks-gte-large-en",
    "xgboost":   "xgboost-non-norad",
    "llm":       "databricks-meta-llama-3-3-70b-instruct",
}

# ---------------------------------------------------------------------------
# Vector Search indexes (GTE-embedded)
# ---------------------------------------------------------------------------
VS_ENDPOINT = "atims_vs_endpoint"
VS_INDEXES = {
    "rules":    _t("rules_kb_index"),
    "writeups": _t("tax_writeups_index"),
}

# ---------------------------------------------------------------------------
# Feature column — GTE Large 1024-dim dense embedding (NOT TF-IDF)
# ---------------------------------------------------------------------------
FEATURE_COL = "gte_embedding"

# ---------------------------------------------------------------------------
# Jurisdictions the taxability_matrix actually covers (50 states + DC + 7
# territories). The real AP feed also carries foreign and placeholder codes
# (HK, JP, FR, ON, DF, II, US, XM, ...). Those can never match the matrix, so
# they are labelled `out_of_scope_jurisdiction` in Task 3.3 rather than being
# mixed into the review queue as if a mapping were missing.
# ---------------------------------------------------------------------------
US_JURISDICTIONS = {
    "AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA",
    "KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ",
    "NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT",
    "VA","WA","WV","WI","WY","DC","AS","GU","MH","MP","PR","UM","VI",
}

# ---------------------------------------------------------------------------
# Thresholds / behaviour — loaded from pipeline_config (defaults as fallback)
# ---------------------------------------------------------------------------
_DEFAULT_PARAMS = {
    "agreement_high_conf": 0.80,
    "rag_match_min_score": 0.75,
    "max_reroute_passes":  2,
    "vs_num_results":      1,
    "amount_z_flag":       3.0,
}


def _load_params(spark):
    p = dict(_DEFAULT_PARAMS)
    try:
        for r in spark.read.table(TABLES["pipeline_config"]).collect():
            k, v, t = r["config_key"], r["config_value"], r["value_type"]
            if k in p and v is not None:
                p[k] = int(v) if t == "int" else float(v) if t == "float" else v
        print("[config] thresholds loaded from pipeline_config")
    except Exception as e:
        print(f"[config] pipeline_config unavailable ({e}); using default thresholds.")
    return p


PARAMS = _load_params(spark)

# ---------------------------------------------------------------------------
# Downstream notification (use a Secret Scope for the real value)
# ---------------------------------------------------------------------------
try:
    WEBHOOK_URL = dbutils.secrets.get(scope="atims", key="phase3_webhook_url")
except Exception:
    WEBHOOK_URL = ""

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper functions

# COMMAND ----------

def load_categories(spark):
    """Label space for the classifier.

    Order of preference:
      1. category_definitions  — the governed taxonomy, if it exists
      2. taxability_matrix     — the clusters the client's mapping can actually price
      3. classification_rules  — last resort

    Why the matrix ranks above the rules table: the label space and the pricing
    key must be the SAME vocabulary. Deriving labels from classification_rules
    hands the LLM 82 options, 24 of which have no row in the matrix — including
    migration junk like '450', 'ERTU' and 'Name OR apparel OR backpack'. Every
    time the model picks one, the line classifies "successfully" and then falls
    straight out of the matrix join as `no_match`. Restricting the label space to
    what the matrix can price makes an unpriceable answer impossible to give.
    """
    try:
        rows = (spark.read.table(TABLES["category_definitions"])
                     .select("cluster").distinct().collect())
        cats = sorted(r["cluster"] for r in rows if r["cluster"])
        if cats:
            return cats
        print("[config] category_definitions empty; falling back to taxability_matrix.")
    except Exception as e:
        print(f"[config] category_definitions unavailable ({type(e).__name__}); "
              f"falling back to taxability_matrix.")

    try:
        rows = (spark.read.table(TABLES["taxability_matrix"])
                     .select("cluster").distinct().collect())
        cats = sorted(r["cluster"] for r in rows if r["cluster"])
        if cats:
            print(f"[config] label space = {len(cats)} clusters from taxability_matrix.")
            return cats
    except Exception as e:
        print(f"[config] taxability_matrix unavailable ({type(e).__name__}); "
              f"deriving from classification_rules.")

    rows = (spark.read.table(TABLES["classification_rules"])
                 .select("category").distinct().collect())
    cats = sorted(r["category"] for r in rows if r["category"])
    if not cats:
        raise ValueError("No categories found in category_definitions, "
                         "taxability_matrix or classification_rules.")
    print(f"[config] WARNING: label space = {len(cats)} rule categories; some may "
          f"have no taxability_matrix row and will never price.")
    return cats


def sql_label_array(categories):
    escaped = ", ".join("'" + c.replace("'", "''") + "'" for c in categories)
    return f"array({escaped})"


def load_xgb_label_decoder(spark):
    try:
        rows = spark.read.table(TABLES["xgb_label_index"]).collect()
        return {int(r["label_index"]): r["cluster"] for r in rows}
    except Exception as e:
        print(f"[config] xgb_label_index unavailable ({e}); assuming endpoint returns names.")
        return {}


def vs_batch_search(index_name, query_texts, num_results, columns):
    """Batch nearest-neighbour search against a Databricks Vector Search index.

    FAIL-OPEN: if the `databricks-vectorsearch` library is not installed, or the
    endpoint/index does not exist, return a no-match (score 0.0) for every query
    instead of raising. RAG is an optional enhancement on top of the explicit
    rules table — when it is unavailable, those lines simply fall through to the
    ML classifier (Task 3.1) or get an empty prior-examples block (Task 3.4).

    To ENABLE real Vector Search: `%pip install databricks-vectorsearch` on the
    cluster and create VS_ENDPOINT + the indexes named in VS_INDEXES.
    """
    none_hit = lambda: {c: None for c in columns} | {"score": 0.0}
    try:
        from databricks.vector_search.client import VectorSearchClient
        vsc = VectorSearchClient(disable_notice=True)
        index = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name=index_name)
    except Exception as e:
        print(f"[config] Vector Search unavailable ({type(e).__name__}); RAG disabled -> no-match.")
        return [none_hit() for _ in query_texts]
    out = []
    for q in query_texts:
        try:
            if q is None or str(q).strip() == "":
                out.append(none_hit()); continue
            res = index.similarity_search(query_text=str(q), columns=columns, num_results=num_results)
            rows = (res.get("result", {}).get("data_array")) or []
            if not rows:
                out.append(none_hit()); continue
            top = rows[0]
            rec = {c: top[i] for i, c in enumerate(columns)}
            rec["score"] = float(top[-1])
            out.append(rec)
        except Exception:
            out.append(none_hit())
    return out


def load_active_rules(spark):
    return (spark.read.table(TABLES["classification_rules"])
                 .filter(col("active") == lit(True))
                 .filter(col("effective_from").isNull() | (col("effective_from") <= F.current_date()))
                 .filter(col("effective_to").isNull() | (col("effective_to") >= F.current_date())))


def write_stage(df, table):
    (df.write.format("delta").mode("overwrite")
       .option("overwriteSchema", "true").saveAsTable(table))
    print(f"   → wrote {table}")


def read_stage(spark, table):
    return spark.read.table(table)



def normalize_input(df):
    """Map a raw prediction_ready export onto the canonical columns Phase 3 uses.

    Idempotent and case-insensitive. Everything here is derived from what the
    real Phase 1/2 export actually contains — see the notes on each block.

      lowercase headers
      literal 'null' -> real NULL            (PO_NUMBER / TAX_AMOUNT / DRIVERID
                                              arrive as the 4-character string)
      mic_cln  <- mic                        ('' and 'NONE' both mean "not set")
      amount   <- tran_amount | invoice_amount
      state    <- trimmed + upper-cased
      is_us_jurisdiction                     (matrix coverage flag)
      use_tax_amount <- tax_amount where tax_type = 'UT'
      line_uid                               (stable surrogate grain key)
    """
    # The source export uses UPPERCASE headers (INVOICE_ID, VENDOR_NAME, ...) but
    # the pipeline references lowercase names throughout. Without this, Task 3.7's
    # case-sensitive column check adds duplicate null columns and corrupts output.
    df = df.toDF(*[c.lower() for c in df.columns])
    cols = {c.lower() for c in df.columns}

    # ------------------------------------------------------------------ nulls
    # The export writes unset values as the literal text 'null', not as an empty
    # field. Left alone, `col IS NULL` is false everywhere and every downstream
    # COALESCE/aggregate silently treats the string as data.
    for c, t in df.dtypes:
        if t == "string":
            df = df.withColumn(c, F.when(F.lower(F.trim(col(c))).isin("null", "none", ""),
                                         lit(None).cast("string"))
                                   .otherwise(F.trim(col(c))))

    # ---------------------------------------------------------------- mic_cln
    if "mic_cln" not in cols:
        df = df.withColumn("mic_cln",
                           col("mic").cast("string") if "mic" in cols
                           else lit(None).cast("string"))

    # ----------------------------------------------------------------- amount
    if "amount" not in cols:
        if "tran_amount" in cols and "invoice_amount" in cols:
            src_amt = F.coalesce(col("tran_amount").cast("double"),
                                 col("invoice_amount").cast("double"))
        elif "tran_amount" in cols:
            src_amt = col("tran_amount").cast("double")
        elif "invoice_amount" in cols:
            src_amt = col("invoice_amount").cast("double")
        else:
            src_amt = lit(None).cast("double")
        df = df.withColumn("amount", src_amt)

    # ------------------------------------------------------------------ state
    # 296 of 7,281 sample lines carry a non-US code. Flag rather than drop: they
    # still belong in the output, they just cannot be priced from this matrix.
    if "state" in cols:
        df = df.withColumn("state", F.upper(F.trim(col("state"))))
    else:
        df = df.withColumn("state", lit(None).cast("string"))
    df = df.withColumn("is_us_jurisdiction", col("state").isin(*sorted(US_JURISDICTIONS)))

    # --------------------------------------------------------- use_tax_amount
    # Task 3.3b needs this and the raw feed has no such column: use tax is carried
    # as TAX_AMOUNT qualified by TAX_TYPE = 'UT' (vs 'ST' sales tax, 'OB' other).
    if "use_tax_amount" not in cols:
        if "tax_amount" in cols and "tax_type" in cols:
            df = df.withColumn("use_tax_amount",
                               F.when(F.upper(col("tax_type")) == "UT",
                                      col("tax_amount").cast("double")))
        elif "tax_amount" in cols:
            df = df.withColumn("use_tax_amount", col("tax_amount").cast("double"))
        else:
            df = df.withColumn("use_tax_amount", lit(None).cast("double"))

    # --------------------------------------------------------------- line_uid
    # (invoice_id, inv_line_number) is NOT unique in the real feed - 85 pairs in
    # the sample cover two genuinely different lines that differ only by
    # account_code. Keying the rules engine on that pair makes both lines inherit
    # one line's rule match. line_uid restores a true one-row-per-line grain.
    _grain = [c for c in ["invoice_id", "inv_line_number", "source", "account_code",
                          "company_code", "tran_amount"] if c in df.columns]
    df = df.withColumn("line_uid",
                       F.sha2(F.concat_ws("||", *[F.coalesce(col(c).cast("string"),
                                                             lit("~")) for c in _grain]), 256))
    return df


def select_month(spark, df, month=None, period_col=None):
    """Filter to one accounting month and FAIL LOUDLY if that month is empty.

    The previous behaviour was a silent zero-row run: MONTH was pinned to
    2022-12 while the feed held 2023-01, so Task 3.1 processed 47 rows out of
    7,281 and every downstream count looked plausible.
    """
    month      = month or MONTH
    period_col = period_col or PERIOD_COL
    if period_col not in [c.lower() for c in df.columns]:
        raise ValueError(f"period column '{period_col}' not in prediction_ready; "
                         f"have {sorted(df.columns)}")
    key = (F.date_format(F.to_date(col(period_col)), "yyyy-MM")
           if period_col.endswith("date") else col(period_col))
    out = df.filter(key == lit(month))
    n = out.count()
    if n == 0:
        avail = (df.select(key.alias("m")).groupBy("m").count()
                   .orderBy("m").collect())
        raise ValueError(
            f"MONTH='{month}' matches 0 rows on {period_col}. "
            f"Months present: {[(r['m'], r['count']) for r in avail]}")
    print(f"[config] month={month} on {period_col}: {n:,} rows")
    return out


def assert_grain(df, keys, label):
    """Guard that `keys` is a true grain. Raises rather than writing dupes."""
    total  = df.count()
    unique = df.select(*keys).distinct().count()
    if total != unique:
        raise ValueError(f"[{label}] {keys} is not unique: {total:,} rows, "
                         f"{unique:,} distinct keys")
    print(f"[{label}] grain OK on {keys}: {total:,} rows")
    return total


print(f"config_notebook loaded — namespace=`{CATALOG}`.{SCHEMA}  month={MONTH} on {PERIOD_COL}")