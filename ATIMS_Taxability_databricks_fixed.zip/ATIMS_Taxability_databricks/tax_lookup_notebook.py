# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.3 — Tax Lookup
# MAGIC
# MAGIC **Unifies** the three Task-3.1/3.2 outputs into one DataFrame *before* the
# MAGIC matrix join, so every record — rule-matched, RAG-matched and ML-classified —
# MAGIC receives a taxability (AUDIT B1). The canonical category column is
# MAGIC `final_category` everywhere (AUDIT B2).
# MAGIC
# MAGIC `LEFT JOIN taxability_matrix ON final_category = cluster AND state = state`
# MAGIC → `taxability` ("Taxable" | "Exempt" | null), `tax_source` ("matrix" | "no_match").
# MAGIC Null taxability is escalated to HIGH review in Task 3.5 (Tax Reasoning agent removed).

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, when

rules_matched = read_stage(spark, STAGE["rules_matched"])
rag_matched   = read_stage(spark, STAGE["rag_matched"])
classified    = read_stage(spark, STAGE["classified"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Unify all paths (rule + rag + ml) on `final_category`

# COMMAND ----------

unified = (rules_matched
           .withColumn("processing_path", lit("FAST"))
           .unionByName(rag_matched.withColumn("processing_path", lit("FAST")),
                        allowMissingColumns=True)
           .unionByName(classified.withColumn(
                            "processing_path",
                            when(col("ensemble_confidence") == "RESOLVE", lit("COMPLEX"))
                            .otherwise(lit("STANDARD"))),
                        allowMissingColumns=True))

print(f"[3.3] unified records: {unified.count():,}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Matrix join

# COMMAND ----------

# Taxability matrix is keyed on (cluster, state) — the client mapping flattened by
# load_taxability_matrix.sql:  cluster -> vertex_category -> TAC grid -> state flag.
# Missing table / missing (cluster, state) pair -> taxability stays NULL so the row
# routes to human review in Task 3.5 (AUDIT B6). NULL is never read as Exempt.
#
# `taxability` in the matrix is already resolved to 'Taxable' | 'Exempt' | NULL.
# NULL there means T* (conditional, undefined by the client) or a cluster whose
# vertex category has no TAC row — both are review cases, not tax decisions.
try:
    raw_matrix = spark.read.table(TABLES["taxability_matrix"])
    _has_matrix = raw_matrix.limit(1).count() > 0
except Exception as e:
    print(f"[3.3] taxability_matrix unavailable ({type(e).__name__}); taxability left NULL.")
    _has_matrix = False

if _has_matrix:
    _cols = {c.lower() for c in raw_matrix.columns}
    _missing = {"cluster", "state", "taxability"} - _cols
    if _missing:
        print(f"[3.3] matrix missing column(s) {sorted(_missing)}; taxability left NULL.")
        _has_matrix = False

if _has_matrix:
    matrix = (raw_matrix.toDF(*[c.lower() for c in raw_matrix.columns])
              .withColumn("_m_cluster", F.upper(F.trim(col("cluster"))))
              .withColumn("_m_state",   F.upper(F.trim(col("state"))))
              .select("_m_cluster", "_m_state",
                      col("taxability").alias("_m_tax"),
                      (col("flag") if "flag" in _cols
                       else lit(None).cast("string")).alias("_m_flag"),
                      (col("status") if "status" in _cols
                       else lit(None).cast("string")).alias("_m_status")))

    # The client's Cluster Names sheet contains case/spelling collisions
    # ("Security Service" vs "Security service"). The join below is
    # case-insensitive, so those would match the SAME line twice and duplicate
    # it. Collapse to one row per (cluster, state) key and say so out loud.
    _dupes = (matrix.groupBy("_m_cluster", "_m_state")
                    .agg(F.countDistinct("_m_tax").alias("_n"))
                    .filter(col("_n") > 1).count())
    if _dupes:
        print(f"[3.3] WARNING: {_dupes} cluster key(s) have conflicting taxability "
              f"across case/spelling variants; first value wins. Fix the source sheet.")
    matrix = matrix.dropDuplicates(["_m_cluster", "_m_state"])

    out = (unified.join(F.broadcast(matrix),
                        (F.upper(F.trim(col("final_category"))) == col("_m_cluster")) &
                        (F.upper(F.trim(col("state")))          == col("_m_state")),
                        "left")
           .withColumn("taxability", col("_m_tax"))
           .withColumn("taxability_flag", col("_m_flag"))
           # tax_source distinguishes the three reasons a line can end up unpriced,
           # so review queues can be worked separately:
           #   matrix             -> resolved from the client mapping
           #   conditional_T*     -> matched, but the client marked it T* (undefined)
           #   unmapped_category  -> cluster exists but its vertex category has no TAC row
           #   no_match           -> the cluster is not in the mapping at all
           #   out_of_scope_jurisdiction -> state is not a US jurisdiction the
           #                                 matrix covers (HK, JP, ON, DF, II...);
           #                                 no mapping will ever exist, so these
           #                                 must not sit in the same queue as a
           #                                 genuinely missing cluster.
           .withColumn("tax_source",
                       when(col("taxability").isNotNull(), lit("matrix"))
                       .when(col("_m_status").startswith("CONDITIONAL"), lit("conditional_T*"))
                       .when(col("_m_status").startswith("UNMAPPED"), lit("unmapped_category"))
                       .when(~F.coalesce(col("is_us_jurisdiction"), lit(False)),
                             lit("out_of_scope_jurisdiction"))
                       .otherwise(lit("no_match")))
           .drop("_m_cluster", "_m_state", "_m_tax", "_m_flag", "_m_status"))
else:
    out = (unified
           .withColumn("taxability", lit(None).cast("string"))
           .withColumn("taxability_flag", lit(None).cast("string"))
           .withColumn("tax_source", lit("no_matrix")))

# Defensive: the flag is set in normalize_input, but 3.3 can also be re-run
# against a stage table written before that column existed.
if "is_us_jurisdiction" not in out.columns:
    out = out.withColumn("is_us_jurisdiction", lit(None).cast("boolean"))

# fan-out guard: the matrix join must never change the row count
_before, _after = unified.count(), out.count()
if _before != _after:
    raise ValueError(f"[3.3] matrix join changed row count {_before} -> {_after}")
print(f"[3.3] row count preserved through matrix join: {_after:,}")

print("[3.3] tax_source split:")
out.groupBy("tax_source").count().show()

no_match = out.filter(col("taxability").isNull()).count()
print(f"[3.3] unresolved taxability (→ HIGH review): {no_match:,}")

# The most useful single diagnostic: which clusters are costing the most lines.
print("[3.3] top unresolved clusters:")
(out.filter(col("taxability").isNull())
    .groupBy("tax_source", "final_category").count()
    .orderBy(col("count").desc()).show(15, truncate=False))

# COMMAND ----------

write_stage(out, STAGE["tax_lookup"])
dbutils.notebook.exit("3.3 OK")