# Changes vs. the uploaded workspace export

Five files differ. Everything else is byte-identical to what you sent.
All changes were executed end to end on a local Spark against 16 sample
invoice lines; 12 assertions pass (see the dry-run log).

---

## NEW — `load_taxability_matrix.sql`

Creates and populates `taxability_matrix`: **3,480 rows = 60 clusters x 58
jurisdictions**, flattened from the client workbook
(`Cluster Names` -> Vertex Category -> `TAC Code Mapping` -> state flag).

| column | meaning |
| --- | --- |
| `cluster` | cluster name — equals `final_category` from Task 3.1/3.2 |
| `vertex_category` | Vertex category from the Cluster Names sheet |
| `taxability_category_code` | Taxability Category Code from the TAC sheet |
| `state` | 50 states + DC + 7 territories |
| `flag` | raw client mark: `T` / `E` / `T*` |
| `taxability` | resolved: `Taxable` / `Exempt` / NULL |
| `status` | `OK` / `CONDITIONAL (T*)` / `UNMAPPED` |

`taxability` is NULL for 134 rows — 116 because `Fuels` and `Streaming
Services` have no TAC row, 18 because the client marked them `T*` with no
footnote defining it. NULL routes the line to human review; it is never
read as exempt.

Run this **once** before the first pipeline run, and again whenever the
client reissues the mapping workbook. It ends with three verification
queries, including one that lists every rule category with no matrix row.

---

## `tax_lookup_notebook.py` (Task 3.3)

**Was:** joined the matrix on **state alone** and de-duplicated to one row
per state, so every line in a state got the same answer regardless of
cluster. Correct against the all-`Taxable` placeholder matrix, wrong
against the real one.

**Now:** single join on `(final_category, state)`, both keys trimmed and
upper-cased.

* De-duplicates to one row per `(cluster, state)` key **after**
  normalisation. Without this the case collisions in the client's cluster
  list (`Security Service` / `Security service`) match the same line twice
  and duplicate it — this actually produced 13 output rows from 12 inputs
  before the fix.
* Adds `taxability_flag` (the raw `T` / `E` / `T*` mark).
* `tax_source` now names the root cause instead of a bare match/no-match:
  `matrix` | `conditional_T*` | `unmapped_category` | `no_match` | `no_matrix`.
* Hard fan-out guard: raises if the join changes the row count.
* Still fail-soft — missing table or missing columns leaves `taxability`
  NULL and routes to review.

---

## `classifier_notebook.py` (Task 3.2) — **crash fix**

`out_schema = unmatched.schema.add("xgboost_pred", ...)` — `StructType.add()`
mutates in place and `DataFrame.schema` is cached, so that line silently
appended two columns to `unmatched`'s own schema. `mapInPandas` then
iterates `self.columns`, asks Spark for a column that does not exist, and
the task dies with `UNRESOLVED_COLUMN`.

Fixed by building a new `StructType` from the fields. This is PySpark
semantics, not environment-specific — Task 3.2 could not have completed a
run in which any line reached it.

---

## `reroute_notebook.py` (Task 3.6)

`matrix_join()` joined on raw values with no de-duplication and its own
two-value `tax_source`. A re-routed line could hit the same case collision
and duplicate, and a category returned by the LLM in different casing
missed the matrix entirely.

Now identical to Task 3.3: same normalisation, same de-duplication, same
`tax_source` vocabulary, same fan-out guard. Also drops and re-derives
`taxability_flag` so a re-routed row never carries a stale mark.

---

## `write_output_notebook.py` (Task 3.7)

Added `tax_source` and `taxability_flag` to `FINAL_COLS` (24 -> 26 columns),
so the review queue can be triaged by root cause instead of worked as one
undifferentiated `HIGH` pile:

| tax_source | who acts | action |
| --- | --- | --- |
| `conditional_T*` | client | define what `T*` means |
| `unmapped_category` | client | add the missing TAC row |
| `no_match` | us | fix a bad rule category |

---

## Order of operations

1. Import this folder into the workspace.
2. Run `load_taxability_matrix.sql` (once).
3. Run the job as normal.

---

## Not changed — still open

* `MONTH = "2022-12"` is hardcoded in `config_notebook`, while
  `workflow.json` passes `month` / `shared_catalog` / `out_catalog` /
  `staging_schema` as job parameters that no notebook reads.
* Output is written with `mode("overwrite")`, so each monthly run replaces
  the previous month rather than appending or merging by partition.
* `confidence` means three different things depending on `match_type`
  (rule confidence / RAG similarity / NULL for ML). Only comparable within
  a single `match_type`.
* Agreement in Task 3.2 is exact string equality between the XGBoost label
  and raw LLM output. Now that the endpoint is Llama 3.3 70B rather than
  Opus, expect more `RESOLVE` outcomes and therefore two LLM calls per
  unmatched line. Normalising case/whitespace before the comparison is a
  small change with a large cost effect.
* 23 categories in `classification_rules` do not exist in the client's
  cluster list (`ERTU`, `450`, `6G2`, `face OR mask`, and the truncated
  description strings on the Parker-Volpe rows). They will always land as
  `no_match`. The client's `NOTES` column also asks for 15 keyword rules to
  be removed and 4 to be re-pointed to `Telecom Equipment` — those are
  `UPDATE` statements against `classification_rules`, not code changes.
