# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.1 — Rules Expert (table-driven)
# MAGIC
# MAGIC Rules now come from the governed **`classification_rules`** table, not code.
# MAGIC Four rule types are evaluated and the **lowest-`priority` match wins** per line:
# MAGIC
# MAGIC 1. **exact_match** — `extc` + `mic_cln` + `account_code`
# MAGIC 2. **account_range** — `account_code` within `[from, to]` (optional `extc`)
# MAGIC 3. **vendor** — `vendor_name`
# MAGIC 4. **keyword** — substring found in `final_description`
# MAGIC
# MAGIC Only `active` rules whose effective-date window covers today are applied.
# MAGIC Lines with no rule match fall through to the **Vector Search** RAG fallback,
# MAGIC then to the Classifier (Task 3.2). Canonical category column is `final_category`.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql import Window
from pyspark.sql.functions import col, lit, lower, row_number, expr, pandas_udf
import pandas as pd

# One row per invoice LINE. (invoice_id, inv_line_number) is not unique in the
# real feed, so the rules engine keys on the surrogate line_uid built in
# normalize_input; otherwise two different lines sharing an invoice/line number
# both inherit whichever line matched a rule first.
KEYS = ["line_uid"]

raw = spark.read.table(TABLES["prediction_ready"])
src = normalize_input(raw)                 # lowercase, 'null'->NULL, mic_cln, amount, line_uid
src = select_month(spark, src)             # raises if the month is empty
src = src.cache()
n_src = assert_grain(src, KEYS, "3.1")
rules = load_active_rules(spark)
print(f"[3.1] records={n_src:,}  active rules={rules.count():,}")

# The XGBoost sub-model in Task 3.2 needs the Phase 2 embedding. Say so here
# rather than letting 3.2 fail soft into LLM-only without anyone noticing.
if FEATURE_COL not in [c.lower() for c in src.columns]:
    print(f"[3.1] WARNING: '{FEATURE_COL}' is not in prediction_ready — Task 3.2 "
          f"will run LLM-only (XGBoost sub-model disabled).")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Build candidate matches per rule type
# MAGIC Each branch yields: KEYS + rule_id, category, confidence, priority, rule_type.

# COMMAND ----------

CAND_COLS = ["line_uid", "rule_id", "category",
             "confidence", "priority", "rule_type"]

def _cand(df):
    return df.select(
        col("s.line_uid"),
        col("r.rule_id"), col("r.category"), col("r.confidence"),
        col("r.priority"), col("r.rule_type"))

s = src.alias("s")

# 1) exact_match — match on whichever of extc / mic_cln / account_code are set
em = (rules.filter(col("rule_type") == "exact_match")
           .filter(col("extc").isNotNull() | col("mic_cln").isNotNull() | col("account_code").isNotNull())
           .alias("r"))
c_exact = _cand(s.join(em,
    (col("r.extc").isNull()         | (col("s.extc") == col("r.extc"))) &
    (col("r.mic_cln").isNull()      | (col("s.mic_cln") == col("r.mic_cln"))) &
    (col("r.account_code").isNull() | (col("s.account_code") == col("r.account_code"))), "inner"))

# 2) account_range (cast to int; optional extc filter)
# Account codes in the real feed are not integers - 7,160 of 7,281 sample lines
# carry a decimal or a letter ('6121.3', '1300.9102', '1180.21A6'). try_cast(... AS INT)
# nulls every one of them, so an int-based range test can never fire. Compare on
# the numeric prefix as a DOUBLE instead, which keeps '6121.3' inside 6000-6999.
_num_acct = "try_cast(regexp_extract(account_code, '^[0-9]+(\\\\.[0-9]+)?', 0) as double)"
ar = (rules.filter(col("rule_type") == "account_range")
            .withColumn("_from", expr("try_cast(account_code_from as double)"))
            .withColumn("_to",   expr("try_cast(account_code_to as double)")).alias("r"))
s_acct = src.withColumn("_acct", expr(_num_acct)).alias("s")
c_range = _cand(s_acct.join(ar,
    (col("s._acct").isNotNull()) &
    (col("s._acct") >= col("r._from")) & (col("s._acct") <= col("r._to")) &
    (col("r.extc").isNull() | (col("s.extc") == col("r.extc"))), "inner"))

# 3) vendor — legacy rules match on vendor_name (case-insensitive)
vr = rules.filter(col("rule_type") == "vendor").alias("r")
c_vendor = _cand(s.join(vr, F.upper(col("s.vendor_name")) == F.upper(col("r.vendor_name")), "inner"))

# 4) keyword (substring in description)
kr = rules.filter(col("rule_type") == "keyword").alias("r")
c_keyword = _cand(s.join(kr,
    lower(col("s.final_description")).contains(lower(col("r.keyword"))), "inner"))

candidates = c_exact.unionByName(c_range).unionByName(c_vendor).unionByName(c_keyword)

# 5) expression — evaluate each active SQL predicate (driver loop; invalid exprs skipped)
expr_rules = (rules.filter(col("rule_type") == "expression")
                   .select("rule_id", "match_expression", "category", "confidence", "priority").collect())
for er in expr_rules:
    me = er["match_expression"]
    if not me:
        continue
    try:
        cond = F.expr(me)
        # Force parse + analysis NOW on this runtime (catches dialect-specific syntax
        # like NOT LIKE that some Databricks Runtimes parse lazily) so a bad predicate
        # is skipped + logged instead of crashing the whole task at the next action.
        src.where(cond).limit(0).count()
        sub = (src.where(cond)
                  .select(col("line_uid"),
                          lit(er["rule_id"]).alias("rule_id"),
                          lit(er["category"]).alias("category"),
                          lit(float(er["confidence"] or 0.9)).alias("confidence"),
                          lit(int(er["priority"])).alias("priority"),
                          lit("expression").alias("rule_type")))
        candidates = candidates.unionByName(sub)
    except Exception as e:  # bad predicate -> skip, don't fail the batch
        print(f"[3.1] skipped expression rule {er['rule_id']}: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Resolve: lowest priority wins (tie-break by rule_id)

# COMMAND ----------

w = Window.partitionBy(*KEYS).orderBy(col("priority").asc(), col("rule_id").asc())
best = (candidates.withColumn("_rn", row_number().over(w))
                  .filter(col("_rn") == 1).drop("_rn"))

rules_matched = (src.join(best, KEYS, "inner")
                 .withColumn("final_category", col("category"))
                 .withColumn("rule_match", lit(True))
                 .withColumn("match_type", lit("det"))
                 .drop("category"))

no_rules = src.join(best.select(*KEYS), KEYS, "left_anti")
print(f"[3.1] rule matches={rules_matched.count():,}  no-rule={no_rules.count():,}")

# Which rule types actually fire on this month's data. A rule type sitting at
# zero month after month is a migration defect, not a quiet success.
print("[3.1] winning rule by type:")
best.groupBy("rule_type").count().orderBy(col("count").desc()).show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Vector Search RAG fallback (Rules KB) on the remainder

# COMMAND ----------

_rules_index = VS_INDEXES["rules"]
_num         = PARAMS["vs_num_results"]
_min_score   = PARAMS["rag_match_min_score"]


@pandas_udf("struct<final_category:string,rule_id:string,score:double>")
def rules_kb_search(text: pd.Series) -> pd.DataFrame:
    hits = vs_batch_search(_rules_index, text.tolist(), _num, columns=["category", "rule_id"])
    return pd.DataFrame([
        {"final_category": h.get("category"), "rule_id": h.get("rule_id"),
         "score": h.get("score", 0.0)} for h in hits])


scored = (no_rules
          .withColumn("_m", rules_kb_search(col("final_description")))
          .withColumn("final_category", col("_m.final_category"))
          .withColumn("rule_id", col("_m.rule_id"))
          .withColumn("confidence", col("_m.score"))
          .withColumn("rule_type", lit("rag")).drop("_m"))

rag_matched = (scored.filter(col("confidence") >= _min_score)
                     .withColumn("rule_match", lit(True))
                     .withColumn("match_type", lit("rag")))
unmatched = (scored.filter((col("confidence") < _min_score) | col("confidence").isNull())
                   .drop("final_category", "rule_id", "confidence", "rule_type")
                   .withColumn("match_type", lit("ml")))

print(f"[3.1] rag matches={rag_matched.count():,}  unmatched → ML={unmatched.count():,}")

# COMMAND ----------

# The four rule branches are unioned, so a bug in any join key shows up here as
# more rows out than in. Catch it before three downstream tasks inherit it.
_split = rules_matched.count() + rag_matched.count() + unmatched.count()
if _split != n_src:
    raise ValueError(f"[3.1] row count changed: {n_src:,} in -> {_split:,} out "
                     f"(rules/rag/unmatched must partition the input)")
print(f"[3.1] row count preserved: {n_src:,}")

write_stage(rules_matched, STAGE["rules_matched"])
write_stage(rag_matched,   STAGE["rag_matched"])
write_stage(unmatched,     STAGE["unmatched"])
dbutils.notebook.exit("3.1 OK")