# Databricks notebook source
# MAGIC %md
# MAGIC # Setup — reference tables (run once)
# MAGIC
# MAGIC Two governed tables make the pipeline data-driven instead of hard-coded:
# MAGIC
# MAGIC | Table | Created/loaded by | Consumed by |
# MAGIC |---|---|---|
# MAGIC | `classification_rules` (147 migrated rules) | **`classification_rules.sql`** | Task 3.1 rules_expert |
# MAGIC | `pipeline_config` (thresholds) | this notebook | config_notebook |
# MAGIC
# MAGIC **Run `classification_rules.sql` first** (it owns the rules-table schema +
# MAGIC loads all 147 rules from the Cluster-Rules spreadsheet), then run this
# MAGIC notebook to create/seed `pipeline_config`.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

# MAGIC %md
# MAGIC ## pipeline_config (thresholds)

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {TABLES['pipeline_config']} (
    config_key   STRING NOT NULL COMMENT 'Tunable name',
    config_value STRING          COMMENT 'Value (stored as string)',
    value_type   STRING          COMMENT 'int | float | string — how to cast on read',
    description  STRING,
    updated_at   TIMESTAMP
)
USING DELTA
COMMENT 'Pipeline thresholds/tunables consumed by config_notebook.'
""")
spark.sql(f"DELETE FROM {TABLES['pipeline_config']}")
spark.sql(f"""
INSERT INTO {TABLES['pipeline_config']} VALUES
 ('agreement_high_conf', '0.80', 'float', 'XGBoost conf above which agreement = HIGH/ACCEPT', current_timestamp()),
 ('rag_match_min_score', '0.75', 'float', 'Vector Search score floor for a strong rule match',  current_timestamp()),
 ('max_reroute_passes',  '2',    'int',   'Task 3.6 iteration cap',                              current_timestamp()),
 ('vs_num_results',      '1',    'int',   'Nearest neighbours retrieved per Vector Search query', current_timestamp()),
 ('amount_z_flag',       '3.0',  'float', 'QA z-score above which an amount is an outlier',       current_timestamp())
""")
print("seeded pipeline_config:")
spark.table(TABLES["pipeline_config"]).show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ## verify classification_rules loaded (run the .sql first)

# COMMAND ----------

try:
    spark.table(TABLES["classification_rules"]).groupBy("rule_type", "active").count().show()
    n = spark.table(TABLES["classification_rules"]).filter("needs_review is not null").count()
    print(f"classification_rules present — {n} rule(s) flagged needs_review.")
except Exception as e:
    print("classification_rules not found — run classification_rules.sql first.", e)

# COMMAND ----------

dbutils.notebook.exit("setup OK")