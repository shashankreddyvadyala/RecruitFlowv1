# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.2 — Classifier  (runs on `unmatched` only)
# MAGIC
# MAGIC Two sub-models + agreement logic.
# MAGIC
# MAGIC - **Sub-model A — XGBoost** via Model Serving, batch-scored on the 1024-dim
# MAGIC   `gte_embedding` (AUDIT A1). Numeric predictions are decoded to category
# MAGIC   names via the Phase 2 label index (AUDIT B5).
# MAGIC - **Sub-model B — `ai_query()`** zero-shot: the LLM picks one category from the
# MAGIC   full label list (ai_classify caps at 20 labels, so we use ai_query). Returns
# MAGIC   **only a label, no confidence**, so the only confidence in agreement is `xgboost_conf`.
# MAGIC
# MAGIC Agreement → disagreements resolved by `ai_query()` GPT-4o with a **null-safe**
# MAGIC prompt and a valid label-array literal (AUDIT B3).
# MAGIC
# MAGIC Output: `STAGE['classified']` with `final_category`, `ensemble_confidence`.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql.functions import col, lit, when

unmatched = read_stage(spark, STAGE["unmatched"]).cache()
categories = load_categories(spark)
label_arr  = sql_label_array(categories)
decoder    = load_xgb_label_decoder(spark)
n_unmatched = unmatched.count()
print(f"[3.2] unmatched rows: {n_unmatched:,}  categories: {len(categories)}")

# ---------------------------------------------------------------------------
# Classify DISTINCT (description, vendor) pairs, not rows.
#
# Both sub-models are pure functions of the description + vendor, and the real
# feed is extremely repetitive: 7,281 invoice lines carry only 402 distinct
# descriptions. Scoring every row means paying for the same answer hundreds of
# times - one line ('Current Liab-Refunds-CAPM ERP-AP Clearing | Corporate Entry
# - Other') repeats 1,240 times on its own. Deduplicate, classify once, join the
# answer back. Identical output, an order of magnitude fewer endpoint calls.
# ---------------------------------------------------------------------------
CLS_KEY = ["final_description", "vendor_name"]

_keep = CLS_KEY + ([FEATURE_COL] if FEATURE_COL in unmatched.columns else [])
work = unmatched.select(*_keep).dropDuplicates(CLS_KEY).cache()
n_work = work.count()
print(f"[3.2] distinct classification keys: {n_work:,} "
      f"({n_work / max(n_unmatched, 1):.1%} of rows -> that is the endpoint call volume)")

if FEATURE_COL not in unmatched.columns:
    print(f"[3.2] WARNING: '{FEATURE_COL}' absent — Sub-model A (XGBoost) cannot "
          f"score; ensemble degrades to LLM-only for this run.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sub-model A — XGBoost serving (batch, per-partition client)

# COMMAND ----------

_endpoint = ENDPOINTS["xgboost"]
_feature  = FEATURE_COL          # "gte_embedding" (1024-dim dense array)
_decoder  = decoder              # {index: name}; empty -> endpoint returns names


def _score_partition(iterator):
    # Sub-model A is FAIL-SOFT: if mlflow is not installed on the executor, or the
    # xgboost serving endpoint is unavailable, return NULL XGBoost predictions so
    # the classifier degrades to LLM-only (Opus) instead of crashing the task.
    try:
        from mlflow.deployments import get_deploy_client
        client = get_deploy_client("databricks")
    except Exception:
        client = None
    for pdf in iterator:
        n = len(pdf)
        if client is None:
            pdf["xgboost_pred"] = [None] * n
            pdf["xgboost_conf"] = [0.0] * n
            yield pdf
            continue
        try:
            vectors = [list(v) for v in pdf[_feature]]
            resp = client.predict(endpoint=_endpoint, inputs={"inputs": vectors})
            preds = resp["predictions"]
            names, confs = [], []
            for prow in preds:
                raw = prow.get("category", prow.get("prediction"))
                conf = float(prow.get("confidence", prow.get("probability", 0.0)))
                if _decoder and not isinstance(raw, str):
                    raw = _decoder.get(int(raw), str(raw))
                names.append(raw)
                confs.append(conf)
            pdf["xgboost_pred"] = names
            pdf["xgboost_conf"] = confs
        except Exception:
            pdf["xgboost_pred"] = [None] * n
            pdf["xgboost_conf"] = [0.0] * n
        yield pdf


# NOTE: do NOT use `unmatched.schema.add(...)` here. StructType.add() mutates the
# StructType in place and DataFrame.schema is cached, so that call silently appends
# xgboost_pred / xgboost_conf to `unmatched`'s own schema. mapInPandas then iterates
# self.columns, asks for a column that does not exist, and the task dies with
# UNRESOLVED_COLUMN. Build a NEW StructType from the fields instead.
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

out_schema = StructType(list(work.schema.fields) + [
    StructField("xgboost_pred", StringType(), True),
    StructField("xgboost_conf", DoubleType(), True),
])
df = work.mapInPandas(_score_partition, schema=out_schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sub-model B — `ai_query()` zero-shot (LLM picks one category; no label cap)

# COMMAND ----------

df.createOrReplaceTempView("unmatched_temp")
# Sub-model B: LLM zero-shot. ai_classify() caps at 20 labels; we have many more
# categories, so we use ai_query() against the LLM endpoint (no label limit).
_llm = ENDPOINTS["llm"]
_label_csv = ", ".join(c.replace("'", "") for c in categories)
df = spark.sql(f"""
    SELECT *,
        ai_query('{_llm}', concat_ws(' ',
            'Classify this AP invoice line into exactly one category from the allowed list.',
            'Respond with ONLY the exact category name from the list, nothing else.',
            'Description:', COALESCE(final_description, ''),
            'Vendor:', COALESCE(vendor_name, ''),
            'Allowed categories:', '{_label_csv}')) AS llm_pred
    FROM unmatched_temp
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Agreement + GPT-4o resolution
# MAGIC `xgboost_conf` is the only model confidence. Prompt uses `concat_ws` +
# MAGIC `COALESCE` so a NULL field never nullifies the whole prompt (AUDIT B3).

# COMMAND ----------

high = PARAMS["agreement_high_conf"]
label_csv = ", ".join(c.replace("'", "") for c in categories)   # for the prompt text

# ---------------------------------------------------------------------------
# Canonicalise both predictions before comparing them.
#
# Agreement used to be raw string equality between the decoded XGBoost label and
# whatever the LLM returned. A chat model routinely answers 'Repair Services.'
# or 'Category: Repair Services', which is not equal to 'Repair Services' — so a
# correct answer scored as a disagreement and bought a second LLM call. Strip
# punctuation/case, then resolve back to the canonical label from the taxonomy;
# anything that still does not resolve is a genuine miss and stays NULL.
# ---------------------------------------------------------------------------
_labels = spark.createDataFrame(
    [(c,) for c in categories], "label string"
).withColumn("_lk", F.upper(F.trim(col("label"))))

def _canonical(frame, src_col, out_col):
    key = F.upper(F.trim(F.regexp_replace(col(src_col), r"[^A-Za-z0-9 /&\\-]", "")))
    return (frame.withColumn("_k", key)
                 .join(F.broadcast(_labels.select(col("_lk"),
                                                  col("label").alias(out_col))),
                       col("_k") == col("_lk"), "left")
                 .drop("_k", "_lk"))

df = _canonical(df, "xgboost_pred", "_xgb_label")
df = _canonical(df, "llm_pred",     "_llm_label")

df = (df
      .withColumn("agreement", col("_xgb_label").eqNullSafe(col("_llm_label"))
                               & col("_xgb_label").isNotNull())
      .withColumn("final_category",
                  when(col("_xgb_label").isNull(), col("_llm_label"))   # XGBoost unavailable -> trust LLM
                  .when(col("agreement"), col("_xgb_label"))
                  .otherwise(lit(None)))
      .withColumn("ensemble_confidence",
                  when(col("_xgb_label").isNull(), lit("LLM_ONLY"))
                  .when(col("agreement") & (col("xgboost_conf") > high), lit("HIGH"))
                  .when(col("agreement"), lit("MEDIUM"))
                  .otherwise(lit("RESOLVE")))
      .drop("_xgb_label", "_llm_label"))

df.createOrReplaceTempView("agreed_temp")
llm = ENDPOINTS["llm"]
resolved = spark.sql(f"""
    SELECT *,
        CASE WHEN ensemble_confidence = 'RESOLVE' THEN
            ai_query(
                '{llm}',
                concat_ws(' ',
                    'Pick the single best category for this AP invoice line.',
                    'XGBoost predicted:', COALESCE(xgboost_pred, 'n/a'),
                    '. LLM predicted:', COALESCE(llm_pred, 'n/a'),
                    '. Description:', COALESCE(final_description, ''),
                    '. Vendor:', COALESCE(vendor_name, ''),
                    '. Respond with exactly one label from this list:',
                    '{label_csv}'
                )
            )
        ELSE final_category END AS final_category_resolved
    FROM agreed_temp
""")

answers = (resolved
           .withColumn("final_category",
                       F.coalesce(col("final_category"), col("final_category_resolved")))
           .drop("final_category_resolved")
           .select(*CLS_KEY, "final_category", "ensemble_confidence",
                   "xgboost_pred", "xgboost_conf", "llm_pred", "agreement")
           .dropDuplicates(CLS_KEY))

# Null-safe join: description or vendor can legitimately be NULL, and a plain
# equi-join would drop those rows instead of classifying them.
_cond = None
for k in CLS_KEY:
    c = col(f"u.{k}").eqNullSafe(col(f"a.{k}"))
    _cond = c if _cond is None else (_cond & c)

classified = (unmatched.alias("u")
              .join(F.broadcast(answers.alias("a")), _cond, "left")
              .select("u.*", "a.final_category", "a.ensemble_confidence",
                      "a.xgboost_pred", "a.xgboost_conf", "a.llm_pred", "a.agreement"))

_after = classified.count()
if _after != n_unmatched:
    raise ValueError(f"[3.2] classification join changed row count "
                     f"{n_unmatched:,} -> {_after:,}")

# COMMAND ----------

write_stage(classified, STAGE["classified"])
n_resolve = classified.filter(col("ensemble_confidence") == "RESOLVE").count()
n_null    = classified.filter(col("final_category").isNull()).count()
print(f"[3.2] classified: {_after:,}  rows needing LLM resolution: {n_resolve:,}  "
      f"still uncategorised: {n_null:,}")
print(f"[3.2] endpoint calls: {n_work:,} distinct keys instead of {n_unmatched:,} rows")
print("[3.2] ensemble_confidence split:")
classified.groupBy("ensemble_confidence").count().show(truncate=False)
dbutils.notebook.exit("3.2 OK")