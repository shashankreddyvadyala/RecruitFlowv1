# Changes — round 2 (validated against the real `prediction_ready` export)

Round 1 was validated against 16 synthetic invoice lines. This round was run
end to end against the **real 7,281-row export** (`run_all_pipeline.csv`,
accounting months 2022-12 / 2023-01 / 2023-02).

Ten files changed. `classification_rules.sql` and `load_taxability_matrix.sql`
are unchanged.

---

## Why this round exists — what the unmodified code did on real data

```
[3.1] records=47                     <- out of 7,281
[3.1] rule matches=0                 <- none of the 147 rules fired
[3.5] FAILED: historical_stats not found
```

Task 3.1 selected **47 rows out of 7,281** and reported it as a clean run.
Task 3.5 then crashed outright, after 3.1–3.4 had already written their stage
tables. Neither failure is visible without real data — the synthetic sample had
the right month and shipped every reference table.

After the changes below, on the same input:

```
[3.1] month=2023-01 on accounting_date: 7,233 rows
[3.1] grain OK on ['line_uid']: 7,233 rows
[3.1] rule matches=2,903   no-rule=4,330
      keyword 1,689 | exact_match 667 | expression 526 | vendor 21
[3.2] distinct classification keys: 884  (20.4% of rows)
[3.3] matrix 6,715 | no_match 169 | out_of_scope 296 | conditional_T* 29 | unmapped 24
[3.7] wrote 7,233 rows, 31 columns
      12/12 end-state assertions pass
```

---

## `config_notebook.py`

### `MONTH` / new `PERIOD_COL`

`MONTH` was pinned to `"2022-12"` while the feed holds 2023-01. Now `"2023-01"`,
and `PERIOD_COL` makes the period column explicit.

`accounting_date` stays the default because every line has exactly one
accounting month, so consecutive monthly runs partition the source with no gaps
and no overlaps. `invoice_month` does **not** have that property — the two
columns disagree on 48 of the 7,281 sample lines, and running on `invoice_month`
would silently drop lines whose invoice and accounting months straddle a
boundary. Change `PERIOD_COL` if the client's definition of the tax period
differs.

### New `select_month()` — fails loudly on an empty month

The old failure mode was a silent zero-row run: every downstream count was
internally consistent and simply small. `select_month()` raises and prints the
months that *are* present.

### New `assert_grain()`

Guards that a key is unique before a task writes on it.

### `normalize_input()` — rewritten

| Added | Why |
| --- | --- |
| literal `'null'` → real NULL | `PO_NUMBER`, `TAX_AMOUNT`, `DRIVERID` arrive as the four-character string `null` on all 7,281 rows. Left alone, `IS NULL` is false everywhere and every `COALESCE` treats the string as data. `'none'` and `''` are folded in too — `MIC` uses all three for "not set". |
| `state` trimmed + upper-cased, plus `is_us_jurisdiction` | 296 lines carry a non-US code (`HK`, `JP`, `FR`, `ON`, `DF`, `II`, `US`, `XM`, …). |
| `use_tax_amount` derived | Task 3.3b needs it and the raw feed has no such column. Use tax is carried as `TAX_AMOUNT` qualified by `TAX_TYPE = 'UT'` (vs `ST` sales tax, `OB` other). |
| `line_uid` surrogate key | See below. |

### New `US_JURISDICTIONS`

The 58 jurisdictions the matrix covers, used by Tasks 3.3 and 3.6.

### `load_categories()` — label space now comes from the matrix

**This was the largest correctness defect found this round.** The label space
handed to the LLM was the distinct `category` values in `classification_rules`
— 82 options, 24 of which have no row in `taxability_matrix`, including
migration junk like `450`, `6G2`, `ERTU` and `Name OR apparel OR backpack`.
Every time the model picked one, the line classified "successfully" and then
fell straight out of the matrix join as `no_match`.

Preference order is now `category_definitions` → **`taxability_matrix.cluster`**
→ `classification_rules.category` (with a warning on the last). The label space
and the pricing key are now the same 60-value vocabulary, so an unpriceable
answer is impossible to give. Unresolved lines fell from 1,945 to 518.

---

## `rules_expert_notebook.py` (Task 3.1)

### Grain: `KEYS` is now `["line_uid"]`

`(invoice_id, inv_line_number)` is **not unique** in the real feed — 85 pairs
cover two genuinely different lines that differ only by `account_code`:

```
349135487  line 2  6532.11    Ntwk Admin Exp ...  | Land & Buildings-Rental
349135487  line 2  1300.9102  Prepaid Tax-VAT     | Corporate Entry - Other
```

Keying the rules engine on that pair makes both lines inherit whichever one
matched a rule first — a silent misclassification, not a crash. `line_uid` is a
sha2 over invoice / line / source / account / company / amount.

### `account_range` rules could never fire

7,160 of 7,281 account codes carry a decimal or a letter (`6121.3`,
`1300.9102`, `1180.21A6`). `try_cast(account_code AS INT)` nulls every one, so
an int-based range test matched nothing. Now compares the numeric prefix as a
DOUBLE, which keeps `6121.3` inside a 6000–6999 range.

### Added

- `select_month()` + `assert_grain()` at the top.
- A warning when `gte_embedding` is missing, so Task 3.2's LLM-only degradation
  is announced rather than discovered later.
- A per-rule-type breakdown of which rules actually won. A rule type sitting at
  zero month after month is a migration defect, not a quiet success.
- A partition check: rules + rag + unmatched must equal the input row count.

---

## `classifier_notebook.py` (Task 3.2)

### Classify distinct keys, not rows

Both sub-models are pure functions of description + vendor, and the feed is
extremely repetitive — 7,281 lines carry only **402 distinct descriptions**, and
one description repeats 1,240 times on its own. Task 3.2 now deduplicates to
`(final_description, vendor_name)`, classifies once, and joins the answer back
null-safely with a row-count guard.

On this sample: **884 endpoint calls instead of 4,330 — 20.4%.** Identical
output. This compounds with the `ai_query` calls in 3.4 and 3.6.

### Agreement no longer breaks on formatting

Agreement was raw string equality between the decoded XGBoost label and whatever
the LLM returned. A chat model routinely answers `Repair Services.` or
`Category: Repair Services`, neither of which equals `Repair Services` — so a
correct answer scored as a disagreement and bought a second LLM call. Both
predictions are now canonicalised (punctuation and case stripped, then resolved
back to the taxonomy label) before comparison. Anything that still fails to
resolve is a genuine miss and stays NULL rather than being invented.

This matters more since the endpoint swap to Llama 3.3 70B.

---

## `tax_lookup_notebook.py` (Task 3.3)

- New `tax_source` value **`out_of_scope_jurisdiction`** for the 296 lines whose
  state is not one of the 58 the matrix covers. No mapping will ever exist for
  these, so they must not sit in the same queue as a genuinely missing cluster.
- Defensive default for `is_us_jurisdiction` when re-running against a stage
  table written before that column existed.
- New diagnostic: the top unresolved clusters by line count, which is the single
  most useful number for deciding what to chase the client about.

---

## `qa_notebook.py` (Task 3.5) — **crash fix**

Checks 3 and 5 read `historical_stats` and `state_service_tax_rules` with no
error handling. On a new environment those tables do not exist yet and the
`AnalysisException` killed the job **after** 3.1–3.4 had already succeeded —
unlike Task 3.3, which was already fail-soft.

Both are now wrapped. A missing history means "no history to compare against",
which is not the same as "every combination is new", so the check is **skipped,
not fired**, and the skip is logged. Check 4 is likewise guarded for a missing
`xgboost_pred` column.

Added a per-check fired count, so a check that never fires is visible.

---

## `reroute_notebook.py` (Task 3.6)

- `matrix_join()` is now fail-soft on a missing matrix, matching Task 3.3.
- Same `out_of_scope_jurisdiction` vocabulary as 3.3.
- `use_tax()` guards a missing `use_tax_amount` column.
- Row-count guard across the whole task.

---

## `write_output_notebook.py` (Task 3.7)

### Partition-scoped write

`mode("overwrite")` replaced the **entire** table on every monthly run — last
month's results disappeared the moment this month's job ran. Now stamps a
`month` column, partitions by it, and uses dynamic partition overwrite, so only
this month's partition is replaced.

### Output is 31 columns (was 26)

Added `line_uid` (the true grain — `invoice_id` + `inv_line_number` alone cannot
join this table back to the AP ledger), `account_code`, `company_code`,
`is_us_jurisdiction`, `month`.

Added a review-queue breakdown by `tax_source` × `review_priority` at the end.

---

## `mlflow_tracking_notebook.py` (Task 3.8)

Now filters `predictions_out` to `MONTH`. With the table partitioned and
accumulating history, reading it whole would blend every month processed to date
into one run's metrics. Also logs the `tax_source` split — the number that shows
whether the review queue is shrinking month over month.

---

## `run_all_pipeline.py` / `load_prediction_ready.py` / `README.md`

Documentation corrections: the stale `MONTH = "2022-12"` reference, the stale
"set the month widget" instruction (there is no month widget), a note that
`load_taxability_matrix.sql` is a `.sql` file and is not in `SETUP_STEPS`, and a
new diagnostic in the loader printing the lines where `invoice_month` and the
accounting month disagree.

---

## Open items — these need the client or the upstream feed, not code

**`use_tax_amount` is NULL on all 7,233 lines, so Task 3.3b is inert.**
`Reverse_UseTax` is NULL for every row. `TAX_AMOUNT` is the literal string
`"null"` in all 7,281 rows, while 112 rows carry `TAX_TYPE = 'UT'` — so the feed
says use tax was accrued but carries no amount. Either the amount lives in a
column not in this export, or the extract needs fixing. Until then the Class B
reversal logic cannot be tested against real data.

**`gte_embedding` is absent from the export.** The README lists it as a
prerequisite (1024-dim, from Phase 2). Without it Sub-model A cannot score and
the ensemble silently degrades to LLM-only — which is exactly what happened in
this run. It now warns in 3.1 and 3.2.

**169 lines land as `no_match`** — a rules-engine category with no
`taxability_matrix` row (`Tools and Testing Equipment`, `450`, `ERTU`,
`Name OR apparel OR backpack` and the other truncated Parker-Volpe values).
Either the client adds the TAC rows or those rules are repointed. This is the
queue that shrinks fastest per unit of effort.

**`Propane / Fuels` (23 lines) and `Content Fees` (1 line)** remain
`unmapped_category` — their vertex categories (`Fuels`, `Streaming Services`)
have no TAC row in the client workbook, in any of the 58 jurisdictions.

**`Distribution Equipment` (27 lines) and `Data Processing` (2)** are
`conditional_T*` — the client marked them `T*` with no footnote defining it.

**Still open from round 1:** `confidence` means three different things depending
on `match_type`; the Task 3.6 loop resolves each record once regardless of
`max_reroute_passes`; the client's `NOTES` column asks for 15 keyword rules to be
removed and 4 repointed to `Telecom Equipment` (those are `UPDATE` statements
against `classification_rules`, not code changes).
