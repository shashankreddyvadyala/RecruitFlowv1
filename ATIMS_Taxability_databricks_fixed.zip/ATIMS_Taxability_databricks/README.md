# Phase 3 — Databricks notebooks (.ipynb)

Import these into a Databricks workspace (keep them in one folder so
`%run ./config_notebook` resolves). Markdown renders natively; the
`ai_classify` / `ai_query` SQL functions and Vector Search run on a cluster.

## Run order

1. **`create_reference_tables`** — run **once** (and whenever rules/thresholds
   change). Creates two governed Delta tables so the pipeline is data-driven, not
   hard-coded:
   - `classification_rules` — full rules engine (exact-match, account-range,
     vendor, keyword) with `priority` (lowest wins) + effective-date windows.
   - `pipeline_config` — thresholds (agreement, RAG floor, re-route passes, …).
2. **`load_taxability_matrix.sql`** — run **once** (and whenever the client
   reissues the mapping workbook). It is a `.sql` file, not a notebook, so run it
   from a SQL editor or a `%sql` cell; it is deliberately not in `SETUP_STEPS`.
3. The monthly job (chained tasks, see `workflow.json`):
   `rules_expert → classifier → tax_lookup → use_tax_lookup → tax_writer → qa → reroute → write_output`

Create the job from `workflow.json` (Jobs UI → *Create from JSON*, or
`databricks jobs create --json @workflow.json`).

## Editing rules without code

`classification_rules` is a normal Delta table — `INSERT`/`UPDATE`/toggle
`active` to change classifications. `rules_expert` evaluates all active,
in-window rules across four `rule_type`s and the lowest `priority` wins per line;
unmatched lines fall through to Vector Search RAG, then the ML classifier.

## Prerequisites

- `prediction_ready` carries the 1024-dim `gte_embedding` column (Phase 2). If it
  is absent, Tasks 3.1 and 3.2 warn and the ensemble degrades to LLM-only —
  it does not fail, but Sub-model A contributes nothing.
- Raw export column names are fine (`INVOICE_ID`, `MIC`, `TRAN_AMOUNT`, …);
  `normalize_input` in `config_notebook` owns all cleaning. Do not pre-clean the
  export in the loader as well, or the two will drift.
- Serving endpoints `xgboost-non-norad`, `databricks-gte-large-en`, and the LLM
  endpoint named in `ENDPOINTS['llm']` (currently
  `databricks-meta-llama-3-3-70b-instruct`).
- Vector Search endpoint + `rules_kb_index` / `tax_writeups_index`.
- `taxability_matrix` loaded from `load_taxability_matrix.sql` — one row per
  (cluster, jurisdiction), 60 x 58 = 3,480 rows, built from the client mapping
  workbook. Task 3.3 resolves taxability in a single join on
  (final_category, state); `taxability` NULL means unresolved and routes to
  human review, never "exempt".
- Reference tables in `atims_shared.reference` (tax_writeups,
  category_definitions, state_service_tax_rules, historical_stats) and
  `atims_shared.models.xgboost_non_norad_label_index`.
- Secret scope `atims` with key `phase3_webhook_url` (Task 3.7 notify).
