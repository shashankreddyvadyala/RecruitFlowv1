# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.4 — Tax Writer
# MAGIC
# MAGIC Audit-ready taxability justification via `ai_query()` → GPT-4o, grounded by
# MAGIC **Vector Search** RAG over the Prior Write-ups KB (AUDIT A2).
# MAGIC
# MAGIC **Short-circuit (AUDIT B6):** when `taxability IS NULL` the record is pending
# MAGIC human review — we do **not** fabricate an audit-ready write-up or spend a
# MAGIC GPT-4o call. We emit a `reviewer_note` and `audit_ready = false`.
# MAGIC
# MAGIC When `Reverse_UseTax = 'Yes'` the prompt requires the write-up to state that a
# MAGIC use-tax reversal is required and to include `use_tax_amount`.
# MAGIC
# MAGIC Output: `short_justification`, `full_writeup`, `reviewer_note`, `audit_ready`.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql.functions import col, lit, when, pandas_udf
import pandas as pd

df = read_stage(spark, STAGE["use_tax"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Batch RAG over Prior Write-ups KB (Vector Search)

# COMMAND ----------

_wu_index = VS_INDEXES["writeups"]
_num      = PARAMS["vs_num_results"]


@pandas_udf("string")
def writeups_search(text: pd.Series) -> pd.Series:
    hits = vs_batch_search(_wu_index, text.tolist(), _num, columns=["full_writeup"])
    return pd.Series([(h.get("full_writeup") or "") for h in hits])


# Only run RAG over the prior write-ups KB when we will actually call the LLM.
# In templated mode the retrieved text is unused, so skip the vector searches.
if GENERATE_LLM_WRITEUPS:
    df = df.withColumn("retrieved_writeups", writeups_search(col("final_description")))
else:
    df = df.withColumn("retrieved_writeups", lit("").cast("string"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write-up generation (skip null-taxability rows)

# COMMAND ----------

df.createOrReplaceTempView("writer_temp")
llm = ENDPOINTS["llm"]
gen_llm = "true" if GENERATE_LLM_WRITEUPS else "false"

# Write-up policy:
#   * taxability IS NULL                  -> no write-up (pending human review)
#   * needs audit narrative AND flag on   -> full Opus write-up (RAG-grounded)
#   * otherwise (known taxability)        -> instant templated justification
# "Needs audit narrative" = use-tax reversal, COMPLEX disagreement, or ML-decided.
gen = spark.sql(f"""
    SELECT *,
        CASE
            WHEN taxability IS NULL THEN NULL
            WHEN {gen_llm}
                 AND (Reverse_UseTax = 'Yes'
                      OR processing_path = 'COMPLEX'
                      OR match_type = 'ml')
            THEN ai_query(
                '{llm}',
                concat_ws(' ',
                    'Generate an audit-ready taxability justification for an AP invoice line.',
                    'Category:', COALESCE(final_category, 'n/a'),
                    '. State:', COALESCE(state, 'n/a'),
                    '. Taxability:', COALESCE(taxability, 'n/a'),
                    '. Reverse_UseTax:', COALESCE(Reverse_UseTax, 'n/a'),
                    '. UseTaxAmount:', COALESCE(CAST(use_tax_amount AS STRING), '0'),
                    CASE WHEN Reverse_UseTax = 'Yes'
                         THEN '. IMPORTANT: explicitly state that a use tax reversal is required and include the use tax amount.'
                         ELSE '' END,
                    '. Ground your answer in these prior examples:',
                    COALESCE(retrieved_writeups, '(none)')
                )
            )
            ELSE concat_ws(' ',
                concat('This ', COALESCE(final_category, 'uncategorized'), ' purchase'),
                concat('in ', COALESCE(state, 'n/a'), ' is treated as ',
                       COALESCE(taxability, 'n/a'), '.'),
                concat('Determination source: ', COALESCE(match_type, 'n/a'), ' match',
                       CASE WHEN ensemble_confidence IS NOT NULL
                            THEN concat(' (', ensemble_confidence, ')') ELSE '' END, '.'),
                CASE WHEN Reverse_UseTax = 'Yes'
                     THEN concat('A use tax reversal of ',
                                 COALESCE(CAST(use_tax_amount AS STRING), '0'), ' is required.')
                     ELSE '' END
            )
        END AS full_writeup
    FROM writer_temp
""")

out = (gen
       .withColumn("short_justification",
                   when(col("full_writeup").isNotNull(), col("full_writeup").substr(1, 280))
                   .otherwise(lit(None).cast("string")))
       .withColumn("reviewer_note",
                   when(col("taxability").isNull(),
                        lit("PENDING: no taxability match — awaiting human review"))
                   .otherwise(lit(None).cast("string")))
       # audit_ready when we have a known taxability + a justification (templated or LLM)
       .withColumn("audit_ready", col("taxability").isNotNull() & col("full_writeup").isNotNull())
       .drop("retrieved_writeups"))

write_stage(out, STAGE["tax_writer"])
print(f"[3.4] mode={'LLM-audit' if GENERATE_LLM_WRITEUPS else 'templated'}  "
      f"write-ups: {out.filter(col('audit_ready')).count():,}  "
      f"pending (null taxability): {out.filter(~col('audit_ready')).count():,}")
dbutils.notebook.exit("3.4 OK")