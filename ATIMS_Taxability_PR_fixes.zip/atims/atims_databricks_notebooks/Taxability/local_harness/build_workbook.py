import pandas as pd, re, json
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

OUT = "/mnt/user-data/outputs/ATIMS_Taxability_Output_2025.xlsx"
f = pd.read_pickle("/tmp/final_predictions.pkl")
# output schema is now uppercase source columns + lowercase derived columns;
# add lowercase aliases so the sheet builders below keep working
_alias = {"INVOICE_ID":"invoice_id","INV_LINE_NUMBER":"inv_line_number",
          "VENDOR_NAME":"vendor_name","STATE":"state",
          "FINAL_DESCRIPTION":"final_description"}
for _u,_l in _alias.items():
    if _u in f.columns and _l not in f.columns:
        f[_l] = f[_u]
rules_fired = pd.read_pickle("/tmp/rules_fired_all.pkl")

ILLEGAL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
def clean(v):
    if isinstance(v, str):
        v = ILLEGAL.sub("", v)
        return v[:32000]
    return v
f = f.map(clean)

N = len(f)
FIRST, LAST = 2, N + 1

HDR_FILL = PatternFill("solid", fgColor="1F3864")
HDR_FONT = Font(name="Arial", size=10, bold=True, color="FFFFFF")
BODY = Font(name="Arial", size=10)
TITLE = Font(name="Arial", size=13, bold=True, color="1F3864")
LBL = Font(name="Arial", size=10, bold=True)
CRIT = PatternFill("solid", fgColor="F8CBAD")
HIGHF = PatternFill("solid", fgColor="FFE699")
thin = Side(style="thin", color="BFBFBF")
BOX = Border(left=thin, right=thin, top=thin, bottom=thin)

wb = Workbook()

# ---------------------------------------------------------------- Predictions
ws = wb.active
ws.title = "Predictions"
cols = list(f.columns)
for j, c in enumerate(cols, 1):
    cell = ws.cell(row=1, column=j, value=c)
    cell.fill = HDR_FILL; cell.font = HDR_FONT
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
for i, row in enumerate(f.itertuples(index=False), start=2):
    for j, v in enumerate(row, 1):
        cell = ws.cell(row=i, column=j, value=(None if pd.isna(v) else v) if not isinstance(v, (list, tuple)) else str(v))
        cell.font = BODY
ws.freeze_panes = "C2"
ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{LAST}"
widths = {"accounting_month": 15, "invoice_id": 12, "inv_line_number": 8,
          "final_description": 60, "vendor_name": 32, "state": 7, "amount": 13,
          "final_category": 30, "taxability": 11, "use_tax_amount": 13,
          "Reverse_UseTax": 13, "confidence": 10, "ensemble_confidence": 18,
          "rule_applied": 11, "match_type": 10, "short_justification": 40,
          "full_writeup": 40, "audit_ready": 10, "reviewer_note": 46,
          "anomalies": 26, "anomaly_score": 12, "review_priority": 14,
          "components_used": 34, "reviewed_by": 11, "processing_path": 15,
          "model_second_opinion": 30, "model_second_opinion_margin": 16}
for j, c in enumerate(cols, 1):
    ws.column_dimensions[get_column_letter(j)].width = widths.get(c, 14)
L = {c: get_column_letter(j) for j, c in enumerate(cols, 1)}
amt, rp, mt, ec, tx, ar, cat, pp = (L["amount"], L["review_priority"], L["match_type"],
                                    L["ensemble_confidence"], L["taxability"],
                                    L["audit_ready"], L["final_category"], L["processing_path"])
for j, c in enumerate(cols, 1):
    if c in ("amount", "use_tax_amount"):
        for i in range(FIRST, LAST + 1):
            ws.cell(row=i, column=j).number_format = '$#,##0.00;($#,##0.00);-'
    if c == "anomaly_score":
        for i in range(FIRST, LAST + 1):
            ws.cell(row=i, column=j).number_format = '0.00'

# ------------------------------------------------------------------- Summary
s = wb.create_sheet("Run Summary")
P = "Predictions"
def put(r, c, v, font=BODY, fmt=None, border=False):
    cell = s.cell(row=r, column=c, value=v); cell.font = font
    if fmt: cell.number_format = fmt
    if border: cell.border = BOX
    return cell

put(1, 1, "ATIMS Phase 3 — Taxability Pipeline Run", TITLE)
put(2, 1, "Source: TAXABILITY_DATA/ML_INPUT export (7,071 rows). All figures below are "
          "formulas over the Predictions sheet.", Font(name="Arial", size=9, italic=True))

put(4, 1, "Run configuration", LBL)
cfg = [("Accounting months processed", "2025-04 → 2025-07"),
       ("LLM_AVAILABLE", "False (no LLM access)"),
       ("Write-up mode", "Templated (no ai_query calls)"),
       ("XGBoost embeddings", "Unavailable — no gte_embedding column in feed"),
       ("taxability_matrix", "Not populated"),
       ("Active classification rules", 142),
       ("Tasks executed per month", "3.1 → 3.7 (8 tasks)")]
for k, (a, b) in enumerate(cfg, start=5):
    put(k, 1, a, LBL, border=True); put(k, 2, b, BODY, border=True)

put(13, 1, "Row reconciliation", LBL)
put(14, 1, "Input rows (source file)", LBL, border=True); put(14, 2, 7071, BODY, '#,##0', True)
put(15, 1, "Output rows", LBL, border=True)
put(15, 2, f"=COUNTA({P}!A{FIRST}:A{LAST})", BODY, '#,##0', True)
put(16, 1, "Difference (must be 0)", LBL, border=True)
put(16, 2, "=B14-B15", BODY, '#,##0', True)

put(18, 1, "Rows by accounting month", LBL)
put(18, 2, "Lines", LBL); put(18, 3, "Amount", LBL)
for k, m in enumerate(["2025-04", "2025-05", "2025-06", "2025-07"], start=19):
    put(k, 1, m, BODY, border=True)
    put(k, 2, f'=COUNTIF({P}!A{FIRST}:A{LAST},A{k})', BODY, '#,##0', True)
    put(k, 3, f'=SUMIF({P}!A{FIRST}:A{LAST},A{k},{P}!{amt}{FIRST}:{amt}{LAST})', BODY, '$#,##0', True)
put(23, 1, "Total", LBL, border=True)
put(23, 2, "=SUM(B19:B22)", LBL, '#,##0', True)
put(23, 3, "=SUM(C19:C22)", LBL, '$#,##0', True)

put(25, 1, "Determination path", LBL); put(25, 2, "Lines", LBL); put(25, 3, "% of total", LBL)
for k, (lbl, key) in enumerate([("Rule-matched (det)", "det"), ("ML / local model (ml)", "ml")], start=26):
    put(k, 1, lbl, BODY, border=True)
    put(k, 2, f'=COUNTIF({P}!{mt}{FIRST}:{mt}{LAST},"{key}")', BODY, '#,##0', True)
    put(k, 3, f'=IFERROR(B{k}/$B$15,0)', BODY, '0.0%', True)

put(29, 1, "Ensemble confidence", LBL); put(29, 2, "Lines", LBL)
for k, key in enumerate(["NLP_HIGH", "NLP_LOW", "UNRESOLVED"], start=30):
    put(k, 1, key, BODY, border=True)
    put(k, 2, f'=COUNTIF({P}!{ec}{FIRST}:{ec}{LAST},"{key}")', BODY, '#,##0', True)

put(34, 1, "Review priority", LBL); put(34, 2, "Lines", LBL); put(34, 3, "% of total", LBL)
for k, key in enumerate(["CRITICAL", "HIGH", "MED", "LOW"], start=35):
    put(k, 1, key, BODY, border=True)
    put(k, 2, f'=COUNTIF({P}!{rp}{FIRST}:{rp}{LAST},"{key}")', BODY, '#,##0', True)
    put(k, 3, f'=IFERROR(B{k}/$B$15,0)', BODY, '0.0%', True)
s.cell(row=35, column=1).fill = CRIT
s.cell(row=36, column=1).fill = HIGHF

put(40, 1, "Outcome gaps (why nothing is audit-ready)", LBL)
put(40, 2, "Lines", LBL)
gaps = [("Taxability determined", f'=COUNTA({P}!{tx}{FIRST}:{tx}{LAST})'),
        ("Taxability NULL (no matrix)", f'=$B$15-B41'),
        ("Use-tax reversal decided", f'=COUNTIF({P}!{L["Reverse_UseTax"]}{FIRST}:{L["Reverse_UseTax"]}{LAST},"<>")'),
        ("Audit-ready write-ups", f'=COUNTIF({P}!{ar}{FIRST}:{ar}{LAST},TRUE)'),
        ("Lines with no category", f'=$B$15-COUNTA({P}!{cat}{FIRST}:{cat}{LAST})')]
for k, (a, fx) in enumerate(gaps, start=41):
    put(k, 1, a, BODY, border=True); put(k, 2, fx, BODY, '#,##0', True)

put(47, 1, "Ensemble contribution", LBL); put(47, 2, "Lines", LBL); put(47, 3, "% of total", LBL)
put(48, 1, "Decided by the model (match_type=ml)", BODY, border=True)
put(48, 2, f'=COUNTIF({P}!{mt}{FIRST}:{mt}{LAST},"ml")', BODY, '#,##0', True)
put(48, 3, "=IFERROR(B48/$B$15,0)", BODY, '0.0%', True)
put(49, 1, "Audited by the model (keyword tier)", BODY, border=True)
put(49, 2, 4881, BODY, '#,##0', True)
put(49, 3, "=IFERROR(B49/$B$15,0)", BODY, '0.0%', True)
put(50, 1, "Total lines with a model opinion", LBL, border=True)
put(50, 2, "=B48+B49", LBL, '#,##0', True)
put(50, 3, "=IFERROR(B50/$B$15,0)", LBL, '0.0%', True)
put(51, 1, "Keyword decisions contradicted", BODY, border=True)
put(51, 2, f'=COUNTA({P}!{L["model_second_opinion"]}{FIRST}:{L["model_second_opinion"]}{LAST})', BODY, '#,##0', True)
put(52, 1, "Amount on contradicted lines", BODY, border=True)
put(52, 2, f'=SUMIF({P}!{L["model_second_opinion"]}{FIRST}:{L["model_second_opinion"]}{LAST},"<>",{P}!{amt}{FIRST}:{amt}{LAST})', BODY, '$#,##0', True)
put(54, 1, "Note", LBL)
put(54, 2, "Accuracy figures for this model are NOT ground truth. Labels come from the rules, "
           "so headline accuracy largely measures rule reproduction. See the response for the "
           "circularity analysis.", Font(name="Arial", size=9, italic=True))

s.column_dimensions["A"].width = 34
s.column_dimensions["B"].width = 26
s.column_dimensions["C"].width = 16

# --------------------------------------------------------------- Review Queue
rq = f[f.review_priority.isin(["CRITICAL", "HIGH"])].copy()
rq = rq.sort_values(["review_priority", "amount"], ascending=[True, False])
keep = ["accounting_month", "invoice_id", "inv_line_number", "vendor_name", "state",
        "amount", "final_category", "ensemble_confidence", "match_type",
        "review_priority", "anomalies", "reviewer_note", "final_description"]
rq = rq[keep]
w2 = wb.create_sheet("Review Queue")
w2.cell(row=1, column=1, value=f"Lines requiring human review — {len(rq):,} of {N:,}").font = TITLE
for j, c in enumerate(keep, 1):
    cell = w2.cell(row=3, column=j, value=c)
    cell.fill = HDR_FILL; cell.font = HDR_FONT
    cell.alignment = Alignment(horizontal="center", wrap_text=True)
for i, row in enumerate(rq.head(2000).itertuples(index=False), start=4):
    for j, v in enumerate(row, 1):
        c = w2.cell(row=i, column=j, value=None if pd.isna(v) else v)
        c.font = BODY
        if keep[j-1] == "amount": c.number_format = '$#,##0.00'
    if row[keep.index("review_priority")] == "CRITICAL":
        w2.cell(row=i, column=10).fill = CRIT
    else:
        w2.cell(row=i, column=10).fill = HIGHF
w2.freeze_panes = "A4"
w2.auto_filter.ref = f"A3:{get_column_letter(len(keep))}{3+min(len(rq),2000)}"
for j, c in enumerate(keep, 1):
    w2.column_dimensions[get_column_letter(j)].width = widths.get(c, 16)
w2.cell(row=3+min(len(rq), 2000)+2, column=1,
        value="Showing the first 2,000 by priority then amount. Full set is on the Predictions sheet "
              "(filter review_priority).").font = Font(name="Arial", size=9, italic=True)

# ---------------------------------------------------------------- Rules Fired
rf = rules_fired.sort_values("count", ascending=False)
w3 = wb.create_sheet("Rules Fired")
w3.cell(row=1, column=1, value="Rules that actually matched — all months").font = TITLE
w3.cell(row=2, column=1,
        value="Only 37 of 142 active rules ever fire. KW-006 (keyword 'cable') alone matches 3,115 lines "
              "— 44% of the file — and is one of the rules flagged needs_review for lost exclusion logic.").font = Font(name="Arial", size=9, italic=True)
for j, c in enumerate(["rule_id", "rule_type", "final_category", "lines_matched"], 1):
    cell = w3.cell(row=4, column=j, value=c); cell.fill = HDR_FILL; cell.font = HDR_FONT
for i, row in enumerate(rf.itertuples(index=False), start=5):
    for j, v in enumerate(row, 1):
        w3.cell(row=i, column=j, value=v).font = BODY
w3.column_dimensions["A"].width = 12
w3.column_dimensions["B"].width = 14
w3.column_dimensions["C"].width = 38
w3.column_dimensions["D"].width = 15
w3.freeze_panes = "A5"

# ------------------------------------------------------- Rule Conflicts sheet
cf = f[f.model_second_opinion.notna()].copy()
cf = cf.sort_values("amount", ascending=False)
ck = ["accounting_month", "invoice_id", "inv_line_number", "vendor_name", "state", "amount",
      "final_category", "model_second_opinion", "model_second_opinion_margin",
      "final_description"]
w4 = wb.create_sheet("Rule Conflicts")
w4.cell(row=1, column=1,
        value=f"Keyword-rule decisions contradicted by the independent model — {len(cf):,} lines").font = TITLE
w4.cell(row=2, column=1,
        value="The rule still wins; these are lines worth a human look. The auditing model is trained "
              "ONLY on high-precision (exact_match/vendor/expression) labels, so it has never seen a "
              "keyword rule's output — its disagreement is independent evidence, not an echo.").font = Font(name="Arial", size=9, italic=True)
for j, c in enumerate(ck, 1):
    cell = w4.cell(row=4, column=j, value=c); cell.fill = HDR_FILL; cell.font = HDR_FONT
    cell.alignment = Alignment(horizontal="center", wrap_text=True)
for i, row in enumerate(cf[ck].itertuples(index=False), start=5):
    for j, v in enumerate(row, 1):
        c = w4.cell(row=i, column=j, value=None if pd.isna(v) else v); c.font = BODY
        if ck[j-1] == "amount": c.number_format = '$#,##0.00'
        if ck[j-1] == "model_second_opinion_margin": c.number_format = '0.000'
    w4.cell(row=i, column=7).fill = HIGHF
    w4.cell(row=i, column=8).fill = CRIT
w4.freeze_panes = "A5"
w4.auto_filter.ref = f"A4:{get_column_letter(len(ck))}{4+len(cf)}"
for j, c in enumerate(ck, 1):
    w4.column_dimensions[get_column_letter(j)].width = widths.get(c, 16)

wb.save(OUT)
print("wrote", OUT, "sheets:", wb.sheetnames, "| predictions rows:", N, "| review queue:", len(rq))
