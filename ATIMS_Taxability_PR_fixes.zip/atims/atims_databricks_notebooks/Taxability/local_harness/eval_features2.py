"""Which additional features actually help? Temporal holdout throughout.

Train on Apr+Jun, predict May. Macro-F1 is the decision metric: accuracy is
carried by the two biggest clusters and hides the tail, which is where cluster
models fail.

Signal in the 22 source columns that the current model does NOT use:

  ACCOUNT_CODE  '2003.845C' is treated as ONE opaque token, so 2003.845C and
                2003.822C share nothing. The GL hierarchy is real structure:
                2003 -> 2003.845 -> 2003.845C. Splitting it lets an unseen
                sub-account still match at the parent level.
  VENDOR_NAME   'KGP TELECOMMUNICATIONS>9I' bundles the vendor with a site
                suffix. Split gives both a general vendor signal and the code.
  MIC           '2FB000025N' likewise has a prefix structure.
  TRAN_AMOUNT   never used. Order of magnitude separates consumables from
                capital equipment.
  NORAD_FLAG / PROJ_NUM / SOURCE   never used at all.

Caveat unchanged: labels come from the rules, so this measures agreement with
the rules, not tax correctness.
"""
import re, sys
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, f1_score

sys.path.insert(0, "/home/claude/harness")
exec(open("/home/claude/harness/eval_classifier.py").read().split("kw_map =")[0])

d = data.copy()
d["month"] = pd.to_datetime(d.ACCOUNTING_DATE, errors="coerce").dt.strftime("%Y-%m")


def flat_codes(r):
    return (f"acct_{r.ACCOUNT_CODE or 'na'} extc_{r.EXTC or 'na'} "
            f"mic_{r.MIC or 'na'} cc_{r.COMPANY_CODE or 'na'} st_{r.STATE or 'na'}")


def hier_account(v):
    """2003.845C -> acct_2003 acct_2003_845 acct_2003_845C"""
    if not v:
        return "acct_na"
    v = str(v)
    parts = v.split(".")
    out = [f"acct_{parts[0]}"]
    if len(parts) > 1:
        tail = parts[1]
        digits = re.match(r"(\d+)", tail)
        if digits:
            out.append(f"acct_{parts[0]}_{digits.group(1)}")
        out.append(f"acct_{parts[0]}_{tail}")
    return " ".join(out)


def vendor_split(v):
    """'KGP TELECOMMUNICATIONS>9I' -> base name tokens + vsfx_9I"""
    if not v:
        return "vend_na"
    v = str(v)
    if ">" in v:
        base, sfx = v.rsplit(">", 1)
        return f"{base.lower()} vsfx_{sfx.strip()}"
    return v.lower()


def mic_split(v):
    if not v or str(v).lower() in ("none", "null"):
        return "mic_none"
    v = str(v)
    return f"mic_{v} micp_{v[:3]} micl_{len(v)}"


def amount_bucket(v):
    try:
        a = abs(float(v))
    except Exception:
        return "amt_na"
    if a == 0:      return "amt_zero"
    if a < 100:     return "amt_lt100"
    if a < 1000:    return "amt_1c"
    if a < 10000:   return "amt_1k"
    if a < 100000:  return "amt_10k"
    return "amt_100k"


def extras(r):
    return (f"norad_{r.NORAD_FLAG or 'na'} "
            f"proj_{'y' if r.PROJ_NUM else 'n'} "
            f"src_{r.SOURCE or 'na'} "
            f"{amount_bucket(r.TRAN_AMOUNT)}")


desc = d.FINAL_DESCRIPTION.fillna("").str.lower()
vend_raw = d.VENDOR_NAME.fillna("").str.lower()

FEATS = {}
FEATS["F0 production today (unigram, flat codes)"] = (
    desc + " " + vend_raw + " " + d.apply(flat_codes, axis=1))
FEATS["F1 + word bigrams"] = FEATS["F0 production today (unigram, flat codes)"]
FEATS["F2 + hierarchical account code"] = (
    desc + " " + vend_raw + " " + d.ACCOUNT_CODE.map(hier_account) + " "
    + "extc_" + d.EXTC.fillna("na") + " mic_" + d.MIC.fillna("na")
    + " cc_" + d.COMPANY_CODE.fillna("na") + " st_" + d.STATE.fillna("na"))
FEATS["F3 + vendor & MIC split"] = (
    desc + " " + d.VENDOR_NAME.map(vendor_split) + " "
    + d.ACCOUNT_CODE.map(hier_account) + " "
    + "extc_" + d.EXTC.fillna("na") + " " + d.MIC.map(mic_split)
    + " cc_" + d.COMPANY_CODE.fillna("na") + " st_" + d.STATE.fillna("na"))
FEATS["F4 ALL + amount/norad/proj/source"] = (
    FEATS["F3 + vendor & MIC split"] + " " + d.apply(extras, axis=1))

TEST = "2025-05"
print(f"{'feature set':46} {'acc':>7} {'macroF1':>9} {'vocab':>8}")
print("-" * 76)
best = None
for name, feat in FEATS.items():
    ng = (1, 2) if name != "F0 production today (unigram, flat codes)" else (1, 1)
    dd = d.assign(feat=feat.str.lower())
    m = dd[dd.category.notna() & dd.month.notna()]
    tr, te = m[m.month != TEST], m[m.month == TEST]
    vec = TfidfVectorizer(sublinear_tf=True, min_df=1, ngram_range=ng, max_features=200000)
    clf = make_pipeline(vec, LogisticRegression(max_iter=1000, C=4.0,
                                                class_weight="balanced"))
    clf.fit(tr.feat, tr.category)
    p = clf.predict(te.feat)
    a = accuracy_score(te.category, p)
    f = f1_score(te.category, p, average="macro", zero_division=0)
    print(f"{name:46} {a:7.3f} {f:9.3f} {len(vec.vocabulary_):8,}")

print("\n--- training-process variants, on the best feature set ---")
dd = d.assign(feat=FEATS["F4 ALL + amount/norad/proj/source"].str.lower())
m = dd[dd.category.notna() & dd.month.notna()]
tr, te = m[m.month != TEST], m[m.month == TEST]

def run(name, trf):
    vec = TfidfVectorizer(sublinear_tf=True, min_df=1, ngram_range=(1, 2), max_features=200000)
    clf = make_pipeline(vec, LogisticRegression(max_iter=1000, C=4.0, class_weight="balanced"))
    clf.fit(trf.feat, trf.category)
    p = clf.predict(te.feat)
    print(f"{name:46} {accuracy_score(te.category,p):7.3f} "
          f"{f1_score(te.category,p,average='macro',zero_division=0):9.3f} "
          f"n_train={len(trf):,}")

run("as-is", tr)
# de-duplicate identical feature rows: boilerplate descriptions repeat heavily
run("de-duplicated training rows", tr.drop_duplicates(subset=["feat", "category"]))
# cap per cluster so no single cluster dominates even after weighting
cap = pd.concat([g.sample(min(len(g), 300), random_state=0)
                 for _, g in tr.groupby("category")], ignore_index=True)
run("capped at 300 rows/cluster", cap)
run("dedup + capped", cap.drop_duplicates(subset=["feat", "category"]))
