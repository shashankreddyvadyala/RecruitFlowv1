# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.2 — Classifier  (runs on `unmatched` only)
# MAGIC
# MAGIC Two sub-models + agreement logic.
# MAGIC
# MAGIC - **Sub-model A — XGBoost** via Model Serving, batch-scored on the 1024-dim
# MAGIC   `gte_embedding` (AUDIT A1). Numeric predictions are decoded to category
# MAGIC   names via the Phase 2 label index (AUDIT B5).
# MAGIC - **Sub-model B — `ai_query()`** zero-shot: the LLM picks one category from the
# MAGIC   full label list (ai_classify caps at 20 labels, so we use ai_query). Returns
# MAGIC   **only a label, no confidence**, so the only confidence in agreement is `xgboost_conf`.
# MAGIC
# MAGIC Agreement → disagreements resolved by `ai_query()` GPT-4o with a **null-safe**
# MAGIC prompt and a valid label-array literal (AUDIT B3).
# MAGIC
# MAGIC Output: `STAGE['classified']` with `final_category`, `ensemble_confidence`.
# MAGIC
# MAGIC **No-LLM mode (`LLM_AVAILABLE = False` in config_notebook):** sub-model B and
# MAGIC the disagreement arbitration are both skipped — no `ai_query()` runs. XGBoost
# MAGIC decides alone (`XGB_ONLY` / `XGB_ONLY_HIGH`); if XGBoost is also unavailable the
# MAGIC row is `UNRESOLVED` with a NULL `final_category` and goes to human review.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql.functions import col, lit, when

unmatched = read_stage(spark, STAGE["unmatched"])
categories = load_categories(spark)
label_arr  = sql_label_array(categories)
decoder    = load_xgb_label_decoder(spark)
print(f"[3.2] unmatched rows: {unmatched.count():,}  categories: {len(categories)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sub-model A — XGBoost serving (batch, per-partition client)

# COMMAND ----------

_endpoint = ENDPOINTS["xgboost"]
_feature  = FEATURE_COL          # "gte_embedding" (1024-dim dense array)
_decoder  = decoder              # {index: name}; empty -> endpoint returns names

# EMBEDDINGS_AVAILABLE=False, or the embedding column simply absent from the
# feed, means sub-model A cannot run at all. Skip it rather than paying for a
# mapInPandas pass that returns NULL for every row.
_has_feature = _feature.lower() in {c.lower() for c in unmatched.columns}
_run_xgb = bool(EMBEDDINGS_AVAILABLE and _has_feature)
if not _run_xgb:
    _why = ("EMBEDDINGS_AVAILABLE=False" if not EMBEDDINGS_AVAILABLE
            else f"no '{_feature}' column in the feed")
    print(f"[3.2] sub-model A (XGBoost) skipped — {_why}.")


def _score_partition(iterator):
    # Sub-model A is FAIL-SOFT: if mlflow is not installed on the executor, or the
    # xgboost serving endpoint is unavailable, return NULL XGBoost predictions so
    # the classifier degrades to LLM-only (Opus) instead of crashing the task.
    try:
        from mlflow.deployments import get_deploy_client
        client = get_deploy_client("databricks")
    except Exception:
        client = None
    for pdf in iterator:
        n = len(pdf)
        if client is None:
            pdf["xgboost_pred"] = [None] * n
            pdf["xgboost_conf"] = [0.0] * n
            yield pdf
            continue
        try:
            vectors = [list(v) for v in pdf[_feature]]
            resp = client.predict(endpoint=_endpoint, inputs={"inputs": vectors})
            preds = resp["predictions"]
            names, confs = [], []
            for prow in preds:
                raw = prow.get("category", prow.get("prediction"))
                conf = float(prow.get("confidence", prow.get("probability", 0.0)))
                if _decoder and not isinstance(raw, str):
                    raw = _decoder.get(int(raw), str(raw))
                names.append(raw)
                confs.append(conf)
            pdf["xgboost_pred"] = names
            pdf["xgboost_conf"] = confs
        except Exception:
            pdf["xgboost_pred"] = [None] * n
            pdf["xgboost_conf"] = [0.0] * n
        yield pdf


# Build the output schema explicitly (portable across PySpark versions —
# StructType.add mutation semantics differ between releases and previously
# made this line fragile).
from pyspark.sql.types import StructType, StructField, StringType, DoubleType
out_schema = StructType(list(unmatched.schema.fields) +
                        [StructField("xgboost_pred", StringType(), True),
                         StructField("xgboost_conf", DoubleType(), True)])
if _run_xgb:
    df = unmatched.mapInPandas(_score_partition, schema=out_schema)
else:
    df = (unmatched
          .withColumn("xgboost_pred", lit(None).cast("string"))
          .withColumn("xgboost_conf", lit(0.0)))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sub-model C — local TF-IDF + Naive Bayes (no endpoints, no embeddings)
# MAGIC
# MAGIC Trained fresh each run on THIS month's rule-matched rows: the governed
# MAGIC rules table supplies the labels (weak supervision), and the model
# MAGIC generalises them to the lines no rule matched. Pure Spark MLlib — nothing
# MAGIC leaves the cluster.

# COMMAND ----------

_nlp_ready = False
nlp_labels = []

if LOCAL_NLP_CLASSIFIER:
  # FAIL-SOFT around the whole local model. Spark ML (pyspark.ml) is not
  # available on every compute type — serverless in particular restricts
  # parts of it. A missing API here must NOT kill Task 3.2: without the
  # local model the classifier simply has no opinion, rows come out
  # UNRESOLVED, and Task 3.5 routes them to human review. Losing the
  # model is a degraded run; a crashed task is a failed month.
  try:
        from pyspark.ml.feature import (RegexTokenizer, StopWordsRemover, CountVectorizer, IDF,
                                        StringIndexer)
        from pyspark.ml.classification import LogisticRegression
        from pyspark.ml.functions import vector_to_array

        _min_rows = int(PARAMS["nlp_min_train_rows"])
        _min_marg = float(PARAMS["nlp_min_confidence"])
        _min_cov  = float(PARAMS["nlp_min_coverage"])
        _vocab_sz = int(PARAMS["nlp_vocab_size"])

        def _text_col():
            """Description + vendor + STRUCTURED CODES as one bag of tokens.

            The description and vendor alone make the model largely a re-derivation
            of the rules: keyword rules label from a substring of the description,
            and vendor/expression rules label from the vendor name — both are
            already in the text, so the model can score ~99% by memorising them.

            The GL/classification codes are the one signal that is NOT in the text
            and NOT what the keyword tier keys on, so they let the model form an
            opinion that is genuinely independent of the rule that labelled the row.
            Prefixed (acct_/extc_/mic_/cc_/st_) so a code can never collide with a
            real word from the description.
            """
            def _tok(prefix, c):
                return F.concat(lit(prefix),
                                F.regexp_replace(F.coalesce(col(c).cast("string"), lit("na")),
                                                 r"[^A-Za-z0-9]", "_"))
            parts = [F.coalesce(col("final_description"), lit("")),
                     F.coalesce(col("vendor_name"), lit(""))]
            for prefix, c in (("acct_", "account_code"), ("extc_", "extc"),
                              ("mic_", "mic_cln"), ("cc_", "company_code"), ("st_", "state")):
                if c in {x.lower() for x in df.columns}:
                    parts.append(_tok(prefix, c))
            return F.lower(F.concat_ws(" ", *parts))

        # TRAINING-LABEL WEIGHTING. Rule-matched rows are weak supervision, but the
        # rule families are not equally trustworthy:
        #   exact_match / vendor / expression -> keyed on codes or an exact vendor,
        #       precise, and (for exact_match) label from a field NOT in the text.
        #   keyword -> a bare substring of the description, priority-50 fallback,
        #       and the tier carrying the known needs_review gaps. Training on these
        #       unweighted makes the model a copy of the keyword rules.
        # Weighting them down keeps their volume without letting them dominate.
        _kw_w = float(PARAMS["nlp_keyword_label_weight"])
        _rules_matched_df = read_stage(spark, STAGE["rules_matched"])
        _train = (_rules_matched_df
                  .withColumn("_txt", _text_col())
                  .withColumn("_w", when(col("rule_type") == "keyword", lit(_kw_w))
                                    .otherwise(lit(1.0)))
                  .select("_txt", "final_category", "_w", "rule_type")
                  .filter(col("final_category").isNotNull() & (F.length(col("_txt")) > 0)))
        _n_train = _train.count()
        _n_class = _train.select("final_category").distinct().count()

        if _n_train < _min_rows or _n_class < 2:
            print(f"[3.2] sub-model C skipped — only {_n_train:,} labelled row(s) / "
                  f"{_n_class} class(es); need >= {_min_rows} and >= 2.")
        else:
            _tok  = RegexTokenizer(inputCol="_txt", outputCol="_tokens",
                                   pattern=r"[^a-z0-9]+", minTokenLength=2)
            _stop = StopWordsRemover(inputCol="_tokens", outputCol="_clean")
            # CountVectorizer (not HashingTF) so we hold an explicit vocabulary and
            # can measure how much of an incoming row the model has actually seen.
            _cv   = CountVectorizer(inputCol="_clean", outputCol="_counts",
                                    vocabSize=_vocab_sz, minDF=2.0)
            _idf  = IDF(inputCol="_counts", outputCol="_features", minDocFreq=2)

            _tokenized = _stop.transform(_tok.transform(_train))
            _cv_model  = _cv.fit(_tokenized)
            _idf_model = _idf.fit(_cv_model.transform(_tokenized))

            def _featurize(frame):
                return _idf_model.transform(_cv_model.transform(_stop.transform(_tok.transform(frame))))

            _train_f = _featurize(_train)
            _lab = StringIndexer(inputCol="final_category", outputCol="_label").fit(_train_f)
            nlp_labels = list(_lab.labelsArray[0]) if hasattr(_lab, "labelsArray") else list(_lab.labels)

            # Logistic regression rather than Naive Bayes: measurably more accurate
            # here (0.994 vs 0.956 on a leakage-masked holdout) and its probabilities
            # are far less saturated, so the margin below is actually informative.
            _model = LogisticRegression(featuresCol="_features", labelCol="_label",
                                        weightCol="_w",
                                        maxIter=30, regParam=0.01).fit(_lab.transform(_train_f))

            _scored = _model.transform(_featurize(df.withColumn("_txt", _text_col())))
            _probs  = vector_to_array(col("probability"))
            _idx_to_label = F.element_at(F.array(*[lit(l) for l in nlp_labels]),
                                         (col("prediction") + 1).cast("int"))
            df = (_scored
                  .withColumn("nlp_pred", _idx_to_label)
                  # MARGIN, not max probability. Max prob saturates near 1.0 for
                  # almost every row and cannot separate good calls from bad ones.
                  .withColumn("nlp_conf",
                              F.array_max(_probs) - F.element_at(F.array_sort(_probs), -2))
                  # OUT-OF-DISTRIBUTION GUARD. The training labels come from the
                  # rules, so the model only knows rule-shaped spend. The rows it is
                  # asked to classify are the ones NO rule matched — often a
                  # different kind of spend entirely, whose correct category may not
                  # even exist in the label set. Coverage = share of this row's
                  # tokens that the model saw in training. Low coverage means the
                  # prediction is an extrapolation and must not be trusted.
                  .withColumn("nlp_coverage",
                              F.aggregate(vector_to_array(col("_counts")), lit(0.0), lambda a, b: a + b)
                              / F.greatest(F.size(col("_clean")).cast("double"), lit(1.0)))
                  .drop("_txt", "_tokens", "_clean", "_counts", "_features",
                        "rawPrediction", "probability", "prediction"))
            _nlp_ready = True
            print(f"[3.2] sub-model C (TF-IDF + logistic regression) trained on "
                  f"{_n_train:,} rule-labelled rows, {_n_class} classes, "
                  f"vocab={len(_cv_model.vocabulary):,}.")

            # ------------------------------------------------------------------
            # SCOPE EXPANSION — second opinion on the KEYWORD tier.
            #
            # Task 3.2 normally only sees the ~13% of lines that no rule matched.
            # The other ~69% are decided by priority-50 keyword rules — a single
            # substring match, the tier holding the known needs_review gaps, and
            # where one rule can carry 40%+ of a month. Those lines get no model
            # opinion at all today, so nothing ever contradicts a weak rule.
            #
            # Here the trained model scores those rows too. It NEVER overrides the
            # governed rule — the output is advisory only and lands in a separate
            # audit table that Task 3.5 turns into a review flag. Deterministic
            # rules stay authoritative; the model just says where to look.
            # ------------------------------------------------------------------
            _audit_min = float(PARAMS["nlp_audit_min_margin"])
            _kw_rows = _rules_matched_df.filter(col("rule_type") == "keyword")

            # The DECISION model above is trained on every rule family, keyword rows
            # included (down-weighted). That makes it a poor auditor of the keyword
            # tier: having learned those labels, it agrees with them almost always
            # and produces no useful disagreements.
            #
            # So the audit uses a SECOND, independent model trained ONLY on
            # high-precision labels (exact_match / vendor / expression). It has
            # never seen a keyword rule's output, so when it contradicts one that is
            # real evidence rather than an echo.
            _hp = _train.filter(col("rule_type") != "keyword")
            _n_hp = _hp.count()
            _n_hp_class = _hp.select("final_category").distinct().count()
            _audit_ready = False
            if _kw_rows.limit(1).count() > 0 and _n_hp >= _min_rows and _n_hp_class >= 2:
                _hp_tok = _stop.transform(_tok.transform(_hp))
                _hp_cv = CountVectorizer(inputCol="_clean", outputCol="_counts",
                                         vocabSize=_vocab_sz, minDF=2.0).fit(_hp_tok)
                _hp_idf = IDF(inputCol="_counts", outputCol="_features",
                              minDocFreq=2).fit(_hp_cv.transform(_hp_tok))

                def _hp_featurize(frame):
                    return _hp_idf.transform(_hp_cv.transform(_stop.transform(_tok.transform(frame))))

                _hp_f = _hp_featurize(_hp)
                _hp_lab = StringIndexer(inputCol="final_category", outputCol="_label").fit(_hp_f)
                _hp_labels = (list(_hp_lab.labelsArray[0]) if hasattr(_hp_lab, "labelsArray")
                              else list(_hp_lab.labels))
                _hp_model = LogisticRegression(featuresCol="_features", labelCol="_label",
                                               maxIter=30, regParam=0.01).fit(_hp_lab.transform(_hp_f))
                _audit_ready = True
                print(f"[3.2] audit model (independent) trained on {_n_hp:,} high-precision "
                      f"rows only, {_n_hp_class} classes.")

            if _audit_ready:
                _ka = _hp_model.transform(_hp_featurize(_kw_rows.withColumn("_txt", _text_col())))
                _kp = vector_to_array(col("probability"))
                _audit = (_ka
                          .withColumn("second_opinion",
                                      F.element_at(F.array(*[lit(l) for l in _hp_labels]),
                                                   (col("prediction") + 1).cast("int")))
                          .withColumn("second_opinion_margin",
                                      F.array_max(_kp) - F.element_at(F.array_sort(_kp), -2))
                          # Only meaningful where the audit model's label space even
                          # contains the rule's answer — otherwise disagreement is
                          # guaranteed and says nothing.
                          .withColumn("_comparable",
                                      col("final_category").isin(*_hp_labels) if _hp_labels else lit(False))
                          .withColumn("second_opinion_conflict",
                                      col("_comparable")
                                      & (col("second_opinion") != col("final_category"))
                                      & (col("second_opinion_margin") >= lit(_audit_min)))
                          .select("invoice_id", "inv_line_number", "rule_id",
                                  col("final_category").alias("rule_category"),
                                  "second_opinion", "second_opinion_margin",
                                  "second_opinion_conflict"))
                write_stage(_audit, STAGE["rule_audit"])
                _n_kw = _audit.count()
                _n_conf = _audit.filter(col("second_opinion_conflict")).count()
                print(f"[3.2] keyword-tier audit: {_n_kw:,} rule-decided line(s) given an "
                      f"independent second opinion; {_n_conf:,} confident disagreement(s) "
                      f"({_n_conf/max(_n_kw,1)*100:.1f}%) flagged for review in Task 3.5.")
            else:
                write_stage(
                    spark.createDataFrame([], "invoice_id string, inv_line_number int, "
                                              "rule_id string, rule_category string, "
                                              "second_opinion string, second_opinion_margin double, "
                                              "second_opinion_conflict boolean"),
                    STAGE["rule_audit"])
                print("[3.2] keyword-tier audit skipped — no keyword rows, or too few "
                      "high-precision rows to train an independent auditor.")
  except Exception as _nlp_err:
    _nlp_ready = False
    print(f'[3.2] local NLP model unavailable ({type(_nlp_err).__name__}: '
          f'{str(_nlp_err).splitlines()[0][:160]}); continuing without it.')

if not _nlp_ready:
    df = (df.withColumn("nlp_pred", lit(None).cast("string"))
            .withColumn("nlp_conf", lit(None).cast("double"))
            .withColumn("nlp_coverage", lit(None).cast("double")))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sub-model B — `ai_query()` zero-shot (LLM picks one category; no label cap)

# COMMAND ----------

# Sub-model B: LLM zero-shot. ai_classify() caps at 20 labels; we have many more
# categories, so we use ai_query() against the LLM endpoint (no label limit).
#
# NO-LLM MODE: when LLM_AVAILABLE is False this sub-model is skipped entirely and
# llm_pred is NULL for every row. The agreement block below is null-safe, so the
# classifier degrades to XGBoost-only rather than failing on a missing endpoint.
_llm = ENDPOINTS["llm"]
_label_csv = ", ".join(c.replace("'", "") for c in categories)

if LLM_AVAILABLE:
    df.createOrReplaceTempView("unmatched_temp")
    df = spark.sql(f"""
        SELECT *,
            ai_query('{_llm}', concat_ws(' ',
                'Classify this AP invoice line into exactly one category from the allowed list.',
                'Respond with ONLY the exact category name from the list, nothing else.',
                'Description:', COALESCE(final_description, ''),
                'Vendor:', COALESCE(vendor_name, ''),
                'Allowed categories:', '{_label_csv}')) AS llm_pred
        FROM unmatched_temp
    """)
else:
    df = df.withColumn("llm_pred", lit(None).cast("string"))
    print("[3.2] LLM_AVAILABLE=False -> sub-model B skipped; the decision falls to "
          f"{'XGBoost' if _run_xgb else ''}{' + ' if (_run_xgb and _nlp_ready) else ''}"
          f"{'the local NLP model' if _nlp_ready else ''}"
          f"{'nothing (rows go to human review)' if not (_run_xgb or _nlp_ready) else ''}.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Agreement + GPT-4o resolution
# MAGIC `xgboost_conf` is the only model confidence. Prompt uses `concat_ws` +
# MAGIC `COALESCE` so a NULL field never nullifies the whole prompt (AUDIT B3).

# COMMAND ----------

high = PARAMS["agreement_high_conf"]
label_csv = ", ".join(c.replace("'", "") for c in categories)   # for the prompt text

# Three possible signals now: xgboost_pred (A), llm_pred (B), nlp_pred (C).
# The ensemble treats ONE primary and ONE secondary opinion:
#   primary   = xgboost_pred            (null unless EMBEDDINGS_AVAILABLE)
#   secondary = llm_pred, else nlp_pred (the local model stands in for the LLM)
# so the original agreement/arbitration structure still applies unchanged, and
# with LLM+embeddings both off the local NLP model simply becomes the decider.
df = (df
      .withColumn("secondary_pred", F.coalesce(col("llm_pred"), col("nlp_pred")))
      .withColumn("secondary_src",
                  when(col("llm_pred").isNotNull(), lit("llm"))
                  .when(col("nlp_pred").isNotNull(), lit("nlp"))
                  .otherwise(lit(None).cast("string"))))

# A local-NLP call is trusted only when BOTH the decision margin and the
# vocabulary coverage clear their floors. Margin alone is not enough: the model
# is confidently wrong on spend it has never seen.
_nlp_conf_ok = ((col("nlp_conf") >= lit(float(PARAMS["nlp_min_confidence"])))
                & (col("nlp_coverage") >= lit(float(PARAMS["nlp_min_coverage"]))))

df = (df
      .withColumn("agreement",
                  col("xgboost_pred").isNotNull() & col("secondary_pred").isNotNull()
                  & (col("xgboost_pred") == col("secondary_pred")))
      .withColumn("final_category",
                  when(col("xgboost_pred").isNull() & col("secondary_pred").isNull(), lit(None))
                  .when(col("secondary_pred").isNull(), col("xgboost_pred"))   # XGBoost alone
                  .when(col("xgboost_pred").isNull(), col("secondary_pred"))   # LLM or NLP alone
                  .when(col("agreement"), col("xgboost_pred"))
                  # Disagreement: if the LLM is available it arbitrates below.
                  # If it is not, prefer whichever model is more confident rather
                  # than discarding two usable opinions.
                  .when(lit(LLM_AVAILABLE), lit(None))
                  .when(col("xgboost_conf") >= F.coalesce(col("nlp_conf"), lit(0.0)),
                        col("xgboost_pred"))
                  .otherwise(col("secondary_pred")))
      .withColumn("ensemble_confidence",
                  when(col("xgboost_pred").isNull() & col("secondary_pred").isNull(),
                       lit("UNRESOLVED"))
                  # local-NLP-only paths (the current default configuration)
                  .when(col("xgboost_pred").isNull() & (col("secondary_src") == "nlp")
                        & _nlp_conf_ok, lit("NLP_HIGH"))
                  .when(col("xgboost_pred").isNull() & (col("secondary_src") == "nlp"),
                        lit("NLP_LOW"))
                  .when(col("xgboost_pred").isNull(), lit("LLM_ONLY"))
                  .when(col("secondary_pred").isNull() & (col("xgboost_conf") > high),
                        lit("XGB_ONLY_HIGH"))
                  .when(col("secondary_pred").isNull(), lit("XGB_ONLY"))
                  .when(col("agreement") & (col("xgboost_conf") > high), lit("HIGH"))
                  .when(col("agreement"), lit("MEDIUM"))
                  .when(lit(LLM_AVAILABLE), lit("RESOLVE"))
                  .otherwise(lit("RESOLVE_LOCAL"))))

llm = ENDPOINTS["llm"]

# NO-LLM MODE: RESOLVE requires two disagreeing opinions, so it cannot occur when
# sub-model B was skipped — there is nothing to arbitrate and the whole SQL step
# is bypassed. The guard is written defensively anyway so the notebook is safe to
# run with LLM_AVAILABLE=False under any upstream state.
if LLM_AVAILABLE:
    df.createOrReplaceTempView("agreed_temp")
    resolved = spark.sql(f"""
        SELECT *,
            CASE WHEN ensemble_confidence = 'RESOLVE' THEN
                ai_query(
                    '{llm}',
                    concat_ws(' ',
                        'Pick the single best category for this AP invoice line.',
                        'XGBoost predicted:', COALESCE(xgboost_pred, 'n/a'),
                        '. LLM predicted:', COALESCE(llm_pred, 'n/a'),
                        '. Description:', COALESCE(final_description, ''),
                        '. Vendor:', COALESCE(vendor_name, ''),
                        '. Respond with exactly one label from this list:',
                        '{label_csv}'
                    )
                )
            ELSE final_category END AS final_category_resolved
        FROM agreed_temp
    """)
    classified = (resolved
                  .withColumn("final_category",
                              F.coalesce(col("final_category"), col("final_category_resolved")))
                  .drop("final_category_resolved"))
else:
    # Any row still without a category (RESOLVE / UNRESOLVED) keeps final_category
    # NULL and is escalated to human review by Task 3.5.
    classified = df
    print("[3.2] LLM_AVAILABLE=False -> LLM arbitration unavailable; disagreements "
          "resolved locally by higher confidence (RESOLVE_LOCAL), and any row with "
          "no opinion at all is left NULL for human review.")

# COMMAND ----------

write_stage(classified, STAGE["classified"])
n_resolve    = classified.filter(col("ensemble_confidence") == "RESOLVE").count()
n_unresolved = classified.filter(col("final_category").isNull()).count()
print(f"[3.2] classified: {classified.count():,}  "
      f"llm={'on' if LLM_AVAILABLE else 'off'}  "
      f"xgb={'on' if _run_xgb else 'off'}  nlp={'on' if _nlp_ready else 'off'}  "
      f"arbitrated: {n_resolve:,}  no category (→ human review): {n_unresolved:,}")
classified.groupBy("ensemble_confidence").count().show()
dbutils.notebook.exit("3.2 OK")