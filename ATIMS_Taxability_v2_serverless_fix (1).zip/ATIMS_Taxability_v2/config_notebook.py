# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# MAGIC %md
# MAGIC # config_notebook — shared Phase 3 configuration & helpers
# MAGIC
# MAGIC `%run` this at the top of every task notebook so all tasks share one source
# MAGIC of truth for the catalog/schema, tables, endpoints, KB indexes, thresholds
# MAGIC and helper functions.
# MAGIC
# MAGIC ```python
# MAGIC %run ./config_notebook
# MAGIC ```
# MAGIC
# MAGIC All tables live under one Unity Catalog namespace
# MAGIC (`31500_atims_dev.atims_taxability` by default). The catalog name starts with
# MAGIC a digit, so it is backtick-quoted everywhere. Rules + thresholds are read from
# MAGIC governed Delta tables (`classification_rules`, `pipeline_config`), not code.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, when

# ---------------------------------------------------------------------------
# Widgets (environment parameters)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# FIX 1 (review comment): environment selector — storage account, container and
# catalog are resolved dynamically per environment, never hardcoded downstream.
# Promote dev -> qa -> prod by changing ONLY the 'env' job parameter.
# ---------------------------------------------------------------------------
dbutils.widgets.text("env", "dev", "Environment (dev|qa|prod)")
ENV = dbutils.widgets.get("env").strip().lower()

# TODO(infra): fill in the real qa/prod values before promoting.
ENV_CONFIG = {
    "dev": {
        "storage_account": "nprdatimsstore",
        "container":       "atims",
        "catalog":         "31500_atims_dev",
        "mlflow_experiment": "/Shared/ATIMS_Source/Taxability_MLFlow_Experiment_2",
    },
    "qa": {
        "storage_account": "REPLACE_QA_STORAGE_ACCOUNT",
        "container":       "REPLACE_QA_CONTAINER",
        "catalog":         "31500_atims_qa",
        "mlflow_experiment": "/Shared/ATIMS_Source/Taxability_MLFlow_Experiment_QA",
    },
    "prod": {
        "storage_account": "REPLACE_PROD_STORAGE_ACCOUNT",
        "container":       "REPLACE_PROD_CONTAINER",
        "catalog":         "31500_atims_prod",
        "mlflow_experiment": "/Shared/ATIMS_Source/Taxability_MLFlow_Experiment_PROD",
    },
}
if ENV not in ENV_CONFIG:
    raise ValueError(f"Unknown env '{ENV}'. Expected one of {sorted(ENV_CONFIG)}. "
                     "Set the 'env' widget / job parameter.")
_ENV = ENV_CONFIG[ENV]

STORAGE_ACCOUNT = _ENV["storage_account"]
CONTAINER       = _ENV["container"]
BASE_PATH       = f"abfss://{CONTAINER}@{STORAGE_ACCOUNT}.dfs.core.windows.net"
SOURCE_PATH     = f"{BASE_PATH}/TAXABILITY_DATA/ML_INPUT"

# Widgets still allow a one-off override, but their DEFAULT now follows env.
dbutils.widgets.text("catalog", _ENV["catalog"], "Unity Catalog")
dbutils.widgets.text("schema",  "atims_taxability", "Schema")

CATALOG = dbutils.widgets.get("catalog") or _ENV["catalog"]
SCHEMA  = dbutils.widgets.get("schema")

# ---------------------------------------------------------------------------
# Accounting month to process (YYYY-MM). Edit this ONE line to pick the month.
# Deliberately NOT a widget: widget values are sticky per-notebook and were the
# cause of Task 3.1 filtering to an empty month. A plain variable cannot get
# stuck. Must be a month that exists in prediction_ready.accounting_date.
# ---------------------------------------------------------------------------
MONTH = "2025-05"   # months present in the real ML_INPUT export: 2025-04, 2025-05, 2025-06, 2025-07

# Clean up any leftover 'month' widget from earlier runs so it can't confuse you.
try:
    dbutils.widgets.remove("month")
except Exception:
    pass

# ---------------------------------------------------------------------------
# EXTERNAL DEPENDENCY SWITCHES — all default False (no external access needed).
# Flip each one independently as access becomes available; nothing else changes.
#
#   LLM_AVAILABLE        ai_query() / the LLM serving endpoint
#   RAG_AVAILABLE        Databricks Vector Search (rules KB + write-ups KB)
#   EMBEDDINGS_AVAILABLE the 1024-dim gte_embedding column AND the xgboost
#                        serving endpoint that consumes it (they are useless
#                        apart, so one switch covers both)
#
# With all three False the pipeline is fully self-contained: governed rules for
# the deterministic path, and an in-cluster TF-IDF classifier (below) for
# everything the rules miss. No serving endpoints, no vector indexes, no
# embeddings, no network calls.
# ---------------------------------------------------------------------------
LLM_AVAILABLE        = False
RAG_AVAILABLE        = False
EMBEDDINGS_AVAILABLE = False

# ---------------------------------------------------------------------------
# LOCAL NLP CLASSIFIER (Task 3.2 sub-model C) — pure Spark MLlib, no endpoints.
#
# TF-IDF over final_description + vendor_name -> Naive Bayes, TRAINED EACH RUN
# on that month's rule-matched rows (the deterministic rules table is the
# weak-supervision label source). It classifies the lines the rules could not.
#
# This is what carries the pipeline while LLM / RAG / embeddings are off. Leave
# it True even after enabling them: it then acts as a cheap second opinion.
# ---------------------------------------------------------------------------
LOCAL_NLP_CLASSIFIER = True

# ---------------------------------------------------------------------------
# Task 3.4 write-up mode. False (default) = fast deterministic templated
# justifications, NO LLM calls — use this for validation runs and while the
# taxability_matrix is still placeholder. True = generate full Opus audit
# write-ups, but ONLY for rows that need an audit narrative (use-tax reversal,
# COMPLEX disagreement, or ML-decided), not every row.
#
# This is a SEPARATE opt-in from LLM_AVAILABLE: you may have LLM access but
# still want fast templated write-ups. LLM_WRITEUPS_ON below is the effective
# value — write-ups only call the LLM when BOTH flags are True, so turning
# LLM_AVAILABLE off can never leave a stray ai_query() behind.
# ---------------------------------------------------------------------------
GENERATE_LLM_WRITEUPS = False
LLM_WRITEUPS_ON = bool(LLM_AVAILABLE and GENERATE_LLM_WRITEUPS)

# ---------------------------------------------------------------------------
# MLflow tracking + Unity Catalog model registry (version control).
# Every Phase 3 run is logged as one MLflow run (params/metrics/artifacts) and
# registered as a new version of REGISTERED_MODEL in the UC model registry, so
# each monthly release of the pipeline logic is governed and promotable.
# REGISTERED_MODEL uses the 3-level UC name WITHOUT backticks (MLflow handles it).
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# MLflow tracking + Unity Catalog model registry (version control).
# FIX 2 (review comment): the experiment resolves ONLY to the registered
# per-environment experiment (from ENV_CONFIG above). There is NO
# /Users/<current_user> fallback anywhere — if the experiment is not
# registered, Task 3.8 fails loudly instead of scattering runs into
# user folders. REGISTERED_MODEL follows the environment's catalog.
# ---------------------------------------------------------------------------
MLFLOW_REGISTRY_URI = "databricks-uc"
MLFLOW_EXPERIMENT   = _ENV["mlflow_experiment"]
UC_MODEL_NAME       = f"{CATALOG}.{SCHEMA}.xgboost_non_norad"
REGISTERED_MODEL    = UC_MODEL_NAME

# Backtick the catalog (it starts with a digit) -> `31500_atims_dev`.atims_taxability.<t>
FQ_SCHEMA = f"`{CATALOG}`.{SCHEMA}"
def _t(name):
    return f"{FQ_SCHEMA}.{name}"

# ---------------------------------------------------------------------------
# Unity Catalog tables (all under one catalog.schema)
# ---------------------------------------------------------------------------
TABLES = {
    # Input (from Phase 2)
    "prediction_ready":     _t("prediction_ready"),
    # Final output (Task 3.7)
    "predictions_out":      _t("non_norad_predictions"),
    # Governed rules + config (created by classification_rules.sql / create_reference_tables)
    "classification_rules": _t("classification_rules"),
    "pipeline_config":      _t("pipeline_config"),
    # Other reference / lookup
    "taxability_matrix":    _t("taxability_matrix"),
    "tax_writeups":         _t("tax_writeups"),
    "category_definitions": _t("category_definitions"),
    "state_service_rules":  _t("state_service_tax_rules"),
    "historical_stats":     _t("historical_stats"),
    # XGBoost label index map (StringIndexer inverse, from Phase 2)
    "xgb_label_index":      _t("xgboost_non_norad_label_index"),
}

# Intermediate task tables (chained between notebook tasks via Delta; same schema)
STAGE = {
    "rules_matched": _t("t31_rules_matched"),
    "rag_matched":   _t("t31_rag_matched"),
    "unmatched":     _t("t31_unmatched"),
    "classified":    _t("t32_classified"),
    "tax_lookup":    _t("t33_tax_lookup"),
    "use_tax":       _t("t33b_use_tax"),
    "tax_writer":    _t("t34_tax_writer"),
    "qa":            _t("t35_qa"),
    "reroute":       _t("t36_reroute"),
    # Second opinion from the local model on rows a KEYWORD rule decided.
    # Written by Task 3.2, consumed by Task 3.5 (check 7). Advisory only —
    # it never overrides a governed rule, it only raises a review flag.
    "rule_audit":    _t("t32_rule_audit"),
    # Materialised copy of the month's input rows. Task 3.1 scans `src` once per
    # rule branch and once per expression rule (50+ passes). On classic compute
    # a .cache() covers that; SERVERLESS compute rejects PERSIST/CACHE
    # (NOT_SUPPORTED_WITH_SERVERLESS), so 3.1 falls back to writing this table
    # and reading it back, which achieves the same thing on any compute type.
    "month_src":     _t("t31_month_src"),
}

# ---------------------------------------------------------------------------
# Model Serving + Foundation Model endpoints
# ---------------------------------------------------------------------------
ENDPOINTS = {
    "embedding": "databricks-gte-large-en",
    "xgboost":   "xgboost-non-norad",
    "llm":       "databricks-claude-opus-4-8",
}

# ---------------------------------------------------------------------------
# Vector Search indexes (GTE-embedded)
# ---------------------------------------------------------------------------
VS_ENDPOINT = "atims_vs_endpoint"
VS_INDEXES = {
    "rules":    _t("rules_kb_index"),
    "writeups": _t("tax_writeups_index"),
}

# ---------------------------------------------------------------------------
# Feature column — GTE Large 1024-dim dense embedding (NOT TF-IDF)
# ---------------------------------------------------------------------------
FEATURE_COL = "gte_embedding"

# ---------------------------------------------------------------------------
# Thresholds / behaviour — loaded from pipeline_config (defaults as fallback)
# ---------------------------------------------------------------------------
_DEFAULT_PARAMS = {
    "agreement_high_conf": 0.80,
    "rag_match_min_score": 0.75,
    "max_reroute_passes":  2,
    "vs_num_results":      1,
    "amount_z_flag":       3.0,
    # Local NLP classifier (Task 3.2 sub-model C)
    # Weight applied to KEYWORD-rule training labels relative to high-precision
    # (exact_match / vendor / expression) labels. Keyword labels are a substring
    # of the description, so training on them unweighted teaches the model to
    # reproduce the keyword rule rather than to classify spend.
    "nlp_keyword_label_weight": 0.25,
    # Margin above which a model second opinion that CONTRADICTS a keyword rule
    # is worth a human look (Task 3.5 check 7).
    "nlp_audit_min_margin": 0.50,
    "nlp_min_train_rows":  50,     # below this, refuse to train (too little signal)
    "nlp_min_confidence":  0.60,   # min top1-top2 probability MARGIN to trust a call
    "nlp_min_coverage":    0.50,   # min share of row tokens seen in training (OOD guard)
    "nlp_vocab_size":      8192,   # TF hashing space
}


def _load_params(spark):
    p = dict(_DEFAULT_PARAMS)
    try:
        for r in spark.read.table(TABLES["pipeline_config"]).collect():
            k, v, t = r["config_key"], r["config_value"], r["value_type"]
            if k in p and v is not None:
                p[k] = int(v) if t == "int" else float(v) if t == "float" else v
        print("[config] thresholds loaded from pipeline_config")
    except Exception as e:
        print(f"[config] pipeline_config unavailable ({e}); using default thresholds.")
    return p


PARAMS = _load_params(spark)

# ---------------------------------------------------------------------------
# Downstream notification (use a Secret Scope for the real value)
# ---------------------------------------------------------------------------
try:
    WEBHOOK_URL = dbutils.secrets.get(scope="atims", key="phase3_webhook_url")
except Exception:
    WEBHOOK_URL = ""

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper functions

# COMMAND ----------

def load_categories(spark):
    """Label space for the classifier. Prefer category_definitions; if that table
    is missing/empty, FALL BACK to the distinct categories in classification_rules
    so the pipeline still has a valid label set without a separate taxonomy table."""
    try:
        rows = (spark.read.table(TABLES["category_definitions"])
                     .select("cluster").distinct().collect())
        cats = sorted(r["cluster"] for r in rows if r["cluster"])
        if cats:
            return cats
        print("[config] category_definitions empty; deriving labels from classification_rules.")
    except Exception as e:
        print(f"[config] category_definitions unavailable ({e}); deriving from classification_rules.")
    rows = (spark.read.table(TABLES["classification_rules"])
                 .select("category").distinct().collect())
    cats = sorted(r["category"] for r in rows if r["category"])
    if not cats:
        raise ValueError("No categories found in category_definitions or classification_rules.")
    return cats


def sql_label_array(categories):
    escaped = ", ".join("'" + c.replace("'", "''") + "'" for c in categories)
    return f"array({escaped})"


def load_xgb_label_decoder(spark):
    try:
        rows = spark.read.table(TABLES["xgb_label_index"]).collect()
        return {int(r["label_index"]): r["cluster"] for r in rows}
    except Exception as e:
        print(f"[config] xgb_label_index unavailable ({e}); assuming endpoint returns names.")
        return {}


def vs_batch_search(index_name, query_texts, num_results, columns):
    """Batch nearest-neighbour search against a Databricks Vector Search index.

    RAG_AVAILABLE=False short-circuits this to a no-match for every query with no
    import and no network call.

    FAIL-OPEN otherwise: if the `databricks-vectorsearch` library is not installed,
    or the endpoint/index does not exist, return a no-match (score 0.0) for every
    query instead of raising. RAG is an optional enhancement on top of the explicit
    rules table — when it is unavailable, those lines simply fall through to the
    ML classifier (Task 3.1) or get an empty prior-examples block (Task 3.4).

    To ENABLE real Vector Search: `%pip install databricks-vectorsearch` on the
    cluster and create VS_ENDPOINT + the indexes named in VS_INDEXES.
    """
    none_hit = lambda: {c: None for c in columns} | {"score": 0.0}
    if not RAG_AVAILABLE:
        return [none_hit() for _ in query_texts]
    try:
        from databricks.vector_search.client import VectorSearchClient
        vsc = VectorSearchClient(disable_notice=True)
        index = vsc.get_index(endpoint_name=VS_ENDPOINT, index_name=index_name)
    except Exception as e:
        print(f"[config] Vector Search unavailable ({type(e).__name__}); RAG disabled -> no-match.")
        return [none_hit() for _ in query_texts]
    out = []
    for q in query_texts:
        try:
            if q is None or str(q).strip() == "":
                out.append(none_hit()); continue
            res = index.similarity_search(query_text=str(q), columns=columns, num_results=num_results)
            rows = (res.get("result", {}).get("data_array")) or []
            if not rows:
                out.append(none_hit()); continue
            top = rows[0]
            rec = {c: top[i] for i, c in enumerate(columns)}
            rec["score"] = float(top[-1])
            out.append(rec)
        except Exception:
            out.append(none_hit())
    return out


def load_active_rules(spark):
    return (spark.read.table(TABLES["classification_rules"])
                 .filter(col("active") == lit(True))
                 .filter(col("effective_from").isNull() | (col("effective_from") <= F.current_date()))
                 .filter(col("effective_to").isNull() | (col("effective_to") >= F.current_date())))


def table_available(spark, name):
    """Eagerly test that a table exists AND can be read.

    Why this is needed instead of `try: spark.read.table(x) ... except`:
    Spark Connect / serverless compute DEFERS analysis. `spark.read.table()` on
    a missing table does not raise there — it returns a DataFrame whose plan is
    resolved later, and the TABLE_OR_VIEW_NOT_FOUND surfaces at the first
    action. By then the frame has usually been joined into the main DataFrame,
    so the `except` block is never entered and the poisoned plan propagates
    downstream. Forcing an action here makes the check deterministic on every
    compute type.

    Optional reference tables must always be probed with this before use.
    """
    try:
        spark.read.table(name).limit(0).count()
        return True
    except Exception as e:
        print(f"[config] table not available: {name} ({type(e).__name__})")
        return False


def write_stage(df, table):
    (df.write.format("delta").mode("overwrite")
       .option("overwriteSchema", "true").saveAsTable(table))
    print(f"   → wrote {table}")


def read_stage(spark, table):
    return spark.read.table(table)



def normalize_input(df):
    """Map a raw prediction_ready schema onto the canonical column names the
    Phase 3 pipeline expects, so the same notebooks run on either the synthetic
    sample or the real Phase 1/2 export. Idempotent and case-insensitive.

      mic_cln <- mic_cln | mic                     (classification code, e.g. 'SW')
      amount  <- amount  | tran_amount | invoice_amount   (line $ amount, double)

    Any column already present is left untouched. Missing source columns yield
    NULL rather than an error, so partial schemas still flow through.
    """
    # Lowercase ALL column names first. The source export uses UPPERCASE headers
    # (INVOICE_ID, VENDOR_NAME, STATE, ...) but the whole pipeline references
    # lowercase names. Without this, Task 3.7's case-sensitive column check adds
    # duplicate null columns and corrupts the output table.
    df = df.toDF(*[c.lower() for c in df.columns])

    cols = {c.lower() for c in df.columns}

    if "mic_cln" not in cols:
        if "mic" in cols:
            df = df.withColumn("mic_cln", col("mic").cast("string"))
        else:
            df = df.withColumn("mic_cln", lit(None).cast("string"))

    if "amount" not in cols:
        if "tran_amount" in cols:
            src_amt = F.coalesce(col("tran_amount").cast("double"),
                                 col("invoice_amount").cast("double")) \
                      if "invoice_amount" in cols else col("tran_amount").cast("double")
        elif "invoice_amount" in cols:
            src_amt = col("invoice_amount").cast("double")
        else:
            src_amt = lit(None).cast("double")
        df = df.withColumn("amount", src_amt)

    return df

def writeup_case_sql(llm_endpoint, generate_llm):
    """FIX 3 (review comment): single source of truth for the write-up
    generation CASE expression, used by BOTH Task 3.4 (tax_writer) and
    Task 3.6 (reroute regeneration) so the two can never drift apart.
    Expects columns: taxability, Reverse_UseTax, processing_path, match_type,
    final_category, state, use_tax_amount, ensemble_confidence,
    retrieved_writeups. Returns the SQL for a `full_writeup` value.

    NO-LLM MODE: when generate_llm is False the returned SQL contains NO
    ai_query() call at all — the branch is omitted from the generated text
    rather than disabled with a literal false. This matters because Spark
    resolves function names at ANALYSIS time: a dead `WHEN false THEN
    ai_query(...)` branch still fails with UNRESOLVED_ROUTINE on any workspace
    where AI Functions are not enabled. Omitting the text makes the templated
    path runnable with no LLM entitlement whatsoever.
    """
    templated = """
            concat_ws(' ',
                concat('This ', COALESCE(final_category, 'uncategorized'), ' purchase'),
                concat('in ', COALESCE(state, 'n/a'), ' is treated as ',
                       COALESCE(taxability, 'n/a'), '.'),
                concat('Determination source: ', COALESCE(match_type, 'n/a'), ' match',
                       CASE WHEN ensemble_confidence IS NOT NULL
                            THEN concat(' (', ensemble_confidence, ')') ELSE '' END, '.'),
                CASE WHEN Reverse_UseTax = 'Yes'
                     THEN concat('A use tax reversal of ',
                                 COALESCE(CAST(use_tax_amount AS STRING), '0'), ' is required.')
                     ELSE '' END
            )
    """

    if not generate_llm:
        return f"""
        CASE
            WHEN taxability IS NULL OR final_category IS NULL THEN NULL
            ELSE {templated}
        END
        """

    return f"""
        CASE
            WHEN taxability IS NULL OR final_category IS NULL THEN NULL
            WHEN (Reverse_UseTax = 'Yes'
                  OR processing_path = 'COMPLEX'
                  OR match_type = 'ml')
            THEN ai_query(
                '{llm_endpoint}',
                concat_ws(' ',
                    'Generate an audit-ready taxability justification for an AP invoice line.',
                    'Category:', COALESCE(final_category, 'n/a'),
                    '. State:', COALESCE(state, 'n/a'),
                    '. Taxability:', COALESCE(taxability, 'n/a'),
                    '. Reverse_UseTax:', COALESCE(Reverse_UseTax, 'n/a'),
                    '. UseTaxAmount:', COALESCE(CAST(use_tax_amount AS STRING), '0'),
                    CASE WHEN Reverse_UseTax = 'Yes'
                         THEN '. IMPORTANT: explicitly state that a use tax reversal is required and include the use tax amount.'
                         ELSE '' END,
                    '. Ground your answer in these prior examples:',
                    COALESCE(retrieved_writeups, '(none)')
                )
            )
            ELSE {templated}
        END
    """


print(f"config_notebook loaded — env={ENV}  namespace=`{CATALOG}`.{SCHEMA}  month={MONTH}")
print(f"[config] LLM={LLM_AVAILABLE}  RAG={RAG_AVAILABLE}  "
      f"EMBEDDINGS/XGBoost={EMBEDDINGS_AVAILABLE}  LOCAL_NLP={LOCAL_NLP_CLASSIFIER}  "
      f"write-ups={'LLM' if LLM_WRITEUPS_ON else 'templated'}")
if not any([LLM_AVAILABLE, RAG_AVAILABLE, EMBEDDINGS_AVAILABLE]):
    print("[config] fully self-contained mode: governed rules + in-cluster TF-IDF "
          "classifier only. No serving endpoints, vector indexes or network calls.")