# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.7 — Write Final Output + Notify
# MAGIC
# MAGIC Selects the canonical output schema from the re-routed DataFrame, writes to
# MAGIC `atims_prod.ml_output.non_norad_predictions`.
# MAGIC
# MAGIC By the time we get here every record already carries `final_category`,
# MAGIC `taxability`, `Reverse_UseTax`, write-up and QA columns (the unification in
# MAGIC Task 3.3 means rule/RAG/ML rows share one schema — AUDIT B1/B2), so this task
# MAGIC is a pure projection + write.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql.functions import col, lit, when, concat_ws

df = read_stage(spark, STAGE["reroute"])
# Normalize case so the canonical FINAL_COLS resolve exactly (no case-duplicate cols).
df = df.toDF(*[c.lower() for c in df.columns])

# COMMAND ----------

# Derive provenance columns expected by the output schema.
df = (df
      .withColumn("rule_applied",
                  when(col("match_type") == "det", lit(True)).otherwise(lit(False)))
      .withColumn("components_used",
                  concat_ws("+",
                            when(col("match_type").isin("det", "rag"), lit("rules")),
                            when(col("match_type") == "ml", lit("classifier")),
                            when(col("ensemble_confidence") == "RESOLVE", lit("llm_resolve")),
                            lit("tax_lookup"), lit("tax_writer"), lit("qa"))))

if "reviewed_by" not in df.columns:
    df = df.withColumn("reviewed_by", lit(None).cast("string"))

# COMMAND ----------

# ---------------------------------------------------------------------------
# SOURCE PASSTHROUGH — every column from the ML_INPUT feed, emitted under its
# ORIGINAL uppercase name. normalize_input() lowercases everything on the way in
# (the pipeline works in lowercase), so each is resolved case-insensitively and
# aliased back. A column absent from the feed is emitted as NULL rather than
# failing, so a partial feed still produces a complete schema.
# ---------------------------------------------------------------------------
SOURCE_COLS = [
    "PO_NUMBER", "INVOICE_ID", "INVOICE_NUM", "SOURCE", "INV_LINE_NUMBER",
    "ACCOUNT_CODE", "COMPANY_CODE", "MIC", "INVOICE_DATE", "INVOICE_AMOUNT",
    "TRAN_AMOUNT", "EXTC", "STATE", "VENDOR_NAME", "INVOICE_FR",
    "FINAL_DESCRIPTION", "PROJ_NUM", "TAX_AMOUNT", "TAX_TYPE",
    "ACCOUNTING_DATE", "NORAD_FLAG", "DRIVERID", "LINE_UID",
]

# Everything the pipeline derives. Deliberately excludes the lowercase twins of
# the source columns above (invoice_id, state, vendor_name, final_description,
# inv_line_number) — emitting both would duplicate the same value under two
# names and, because Spark is case-insensitive by default, make `select`
# ambiguous.
ML_COLS = [
    "amount",                      # line amount actually used, from TRAN_AMOUNT
    "final_category",              # the cluster label
    "taxability",                  # from the taxability_matrix join
    "use_tax_amount", "Reverse_UseTax",
    "confidence", "ensemble_confidence", "rule_applied", "match_type",
    "model_second_opinion", "model_second_opinion_margin",
    "short_justification", "full_writeup", "audit_ready", "reviewer_note",
    "anomalies", "anomaly_score", "review_priority",
    "components_used", "reviewed_by", "processing_path", "month",
]

FINAL_COLS = SOURCE_COLS + ML_COLS

# Stamp the pipeline month so the output is partitioned by period.
df = df.withColumn("month", lit(MONTH))

# Add any missing optional columns so the projection never fails.
_have = {x.lower(): x for x in df.columns}

_missing = [c for c in FINAL_COLS if c.lower() not in _have]
if _missing:
    print(f"[3.7] columns absent from the pipeline, emitted as NULL: {_missing}")

# Build the projection explicitly, aliasing each source column back to its
# original uppercase name. Using df.select("PO_NUMBER") directly would resolve
# case-insensitively but emit the column under its lowercase internal name.
_proj = []
for c in FINAL_COLS:
    if c.lower() in _have:
        _proj.append(col(_have[c.lower()]).alias(c))
    else:
        _proj.append(lit(None).cast("string").alias(c))

final = df.select(*_proj)
print(f"[3.7] output schema: {len(SOURCE_COLS)} source + {len(ML_COLS)} derived "
      f"= {len(FINAL_COLS)} columns")

total   = final.count()
flagged = final.filter(col("review_priority").isin("HIGH", "CRITICAL")).count()

# ZERO-ROW OUTPUT GUARD. Mirrors the zero-row INPUT guard in Task 3.1. Writing an
# empty predictions table is never a valid outcome: 3.1 already refuses to run on
# an empty month, so by the time we reach 3.7 there must be rows. An empty result
# here means rows were lost somewhere in 3.2-3.6 — a null-valued filter, a join
# that matched nothing, or a stage table left over from a different month. Fail
# rather than overwrite a good table with nothing.
if total == 0:
    _stage_counts = []
    for _k in ("rules_matched", "rag_matched", "unmatched", "classified",
               "tax_lookup", "use_tax", "tax_writer", "qa", "reroute"):
        try:
            _stage_counts.append(f"{_k}={spark.read.table(STAGE[_k]).count():,}")
        except Exception:
            _stage_counts.append(f"{_k}=<missing>")
    raise ValueError(
        f"[3.7] REFUSING to write an empty {TABLES['predictions_out']} for MONTH="
        f"'{MONTH}'. Rows were lost upstream. Stage table counts: "
        + ", ".join(_stage_counts)
        + ". The last stage with a non-zero count is where to look."
    )

(final.write.format("delta").mode("overwrite")
      .option("replaceWhere", f"month = '{MONTH}'")
      .option("overwriteSchema", "true")
      .saveAsTable(TABLES["predictions_out"]))

print(f"[3.7] wrote {total:,} rows → {TABLES['predictions_out']}  (flagged: {flagged:,})")


dbutils.notebook.exit("3.7 OK")