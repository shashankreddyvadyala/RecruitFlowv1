# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.3 — Tax Lookup
# MAGIC
# MAGIC **Unifies** the three Task-3.1/3.2 outputs into one DataFrame *before* the
# MAGIC matrix join, so every record — rule-matched, RAG-matched and ML-classified —
# MAGIC receives a taxability (AUDIT B1). The canonical category column is
# MAGIC `final_category` everywhere (AUDIT B2).
# MAGIC
# MAGIC `LEFT JOIN taxability_matrix ON final_category = cluster AND state = state`
# MAGIC → `taxability` ("Taxable" | "Exempt" | null), `tax_source` ("matrix" | "no_match").
# MAGIC Null taxability is escalated to HIGH review in Task 3.5 (Tax Reasoning agent removed).

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql.functions import col, lit, when

rules_matched = read_stage(spark, STAGE["rules_matched"])
rag_matched   = read_stage(spark, STAGE["rag_matched"])
classified    = read_stage(spark, STAGE["classified"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Unify all paths (rule + rag + ml) on `final_category`

# COMMAND ----------

unified = (rules_matched
           .withColumn("processing_path", lit("FAST"))
           .unionByName(rag_matched.withColumn("processing_path", lit("FAST")),
                        allowMissingColumns=True)
           # COMPLEX = anything not routinely decided: model disagreement
           # (RESOLVE / RESOLVE_LOCAL), no category at all (UNRESOLVED), or a
           # local-NLP call below the confidence floor (NLP_LOW). These are the
           # rows a reviewer should look at first.
           .unionByName(classified.withColumn(
                            "processing_path",
                            when(col("ensemble_confidence").isin(
                                     "RESOLVE", "RESOLVE_LOCAL", "UNRESOLVED", "NLP_LOW"),
                                 lit("COMPLEX"))
                            .otherwise(lit("STANDARD"))),
                        allowMissingColumns=True))

print(f"[3.3] unified records: {unified.count():,}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Matrix join

# COMMAND ----------

# Taxability matrix is OPTIONAL and keyed on (cluster, state).
# Missing/empty -> leave taxability NULL so rows route to human review (B6).
# The value column may be 1/0, Y/N, true/false, or the words; it is normalized
# to 'Taxable'/'Exempt' so downstream (use_tax, reroute) keeps working.
try:
    raw_matrix = spark.read.table(TABLES["taxability_matrix"])
    _has_matrix = raw_matrix.limit(1).count() > 0
except Exception as e:
    print(f"[3.3] taxability_matrix unavailable ({type(e).__name__}); taxability left NULL.")
    _has_matrix = False

if _has_matrix:
    _lc = [c.lower() for c in raw_matrix.columns]
    _valcol = next((c for c in raw_matrix.columns
                    if c.lower() in ("taxability", "taxable", "is_taxable", "tax")), None)
    _clscol = next((c for c in raw_matrix.columns
                    if c.lower() in ("cluster", "category", "final_category")), None)
    if _valcol is None:
        print("[3.3] matrix has no taxability/taxable column; taxability left NULL.")
        _has_matrix = False
    elif _clscol is None:
        print("[3.3] matrix has no cluster/category column; taxability left NULL.")
        _has_matrix = False

if _has_matrix:
    _v = F.lower(F.trim(col(_valcol).cast("string")))
    matrix = (raw_matrix
              .withColumn("_m_tax",
                          when(_v.isin("1", "y", "yes", "true", "t", "taxable"), lit("Taxable"))
                          .when(_v.isin("0", "n", "no", "false", "f", "exempt"), lit("Exempt"))
                          .otherwise(col(_valcol).cast("string")))
              .select(col(_clscol).alias("_m_cluster"),
                      col("state").alias("_m_state"), "_m_tax"))

    out = (unified.join(F.broadcast(matrix),
                        (col("final_category") == col("_m_cluster")) &
                        (col("state") == col("_m_state")), "left")
           .withColumn("taxability", col("_m_tax"))
           .drop("_m_cluster", "_m_state", "_m_tax")
           .withColumn("tax_source",
                       when(col("taxability").isNotNull(), lit("matrix")).otherwise(lit("no_match"))))
else:
    out = (unified
           .withColumn("taxability", lit(None).cast("string"))
           .withColumn("tax_source", lit("no_matrix")))

no_match = out.filter(col("taxability").isNull()).count()
print(f"[3.3] no matrix match (→ HIGH review): {no_match:,}")

# COMMAND ----------

write_stage(out, STAGE["tax_lookup"])
dbutils.notebook.exit("3.3 OK")