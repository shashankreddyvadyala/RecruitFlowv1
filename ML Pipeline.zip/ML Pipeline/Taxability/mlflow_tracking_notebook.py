# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.8 — MLflow Tracking + UC Model Versioning
# MAGIC
# MAGIC Run this LAST (after 3.7). It does NOT change any pipeline data — it only:
# MAGIC
# MAGIC 1. Logs one consolidated **MLflow run** for the month: params (month, endpoints,
# MAGIC    thresholds, rule counts, rules snapshot hash), metrics (row counts, match-type
# MAGIC    split, review priorities, audit-ready %, taxability split), and artifacts
# MAGIC    (active rules snapshot, pipeline_config, a sample of the output).
# MAGIC 2. Registers a new **version** of the pipeline model in the Unity Catalog model
# MAGIC    registry (`REGISTERED_MODEL`), bundling the exact rules + config + prompt
# MAGIC    manifest that produced this run — i.e. real version control of the logic.
# MAGIC 3. Tags the version and points the `latest` alias at it.
# MAGIC
# MAGIC Everything here is FAIL-SOFT: if registry permissions or MLflow are unavailable,
# MAGIC the run is still logged and the notebook does not crash the job.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

import mlflow, hashlib, json, os
import pandas as pd
from mlflow.tracking import MlflowClient

# MLFLOW_REGISTRY_URI / REGISTERED_MODEL / MLFLOW_EXPERIMENT come from config_notebook
mlflow.set_registry_uri(MLFLOW_REGISTRY_URI)

# FIX 2 (review comment): resolve ONLY the registered per-environment
# experiment. No current_user(), no /Users/<user> fallback — the experiment
# path must be identical no matter which identity (user or job service
# principal) runs the pipeline. If it is not registered, fail loudly HERE,
# at the top, instead of scattering runs into user folders.
# Canonical experiment names use the '/Shared/...' form. MLflow has a
# documented Databricks bug where a '/Workspace/...'-prefixed name passes on
# the FIRST run (it creates the experiment) and then fails on every re-run
# because the existence check misses it (mlflow #11077). Resolve robustly:
# try the configured name, then the same name with the '/Workspace' prefix
# added/stripped. Still deterministic; still NO user-folder fallback.
def _resolve_registered_experiment(name):
    exp = mlflow.get_experiment_by_name(name)
    if exp is not None:
        return exp
    if name.startswith("/Workspace/"):
        alt = name[len("/Workspace"):]
    else:
        alt = "/Workspace" + name
    return mlflow.get_experiment_by_name(alt)

_exp = _resolve_registered_experiment(MLFLOW_EXPERIMENT)
if _exp is None:
    raise RuntimeError(
        f"[3.8] MLflow experiment '{MLFLOW_EXPERIMENT}' is not registered for "
        f"env='{ENV}'. Create it once (admin/Terraform) and grant the job "
        "service principal CAN_MANAGE, then re-run. Refusing to fall back to "
        "a user folder."
    )
mlflow.set_experiment(experiment_id=_exp.experiment_id)
EXPERIMENT_PATH = _exp.name
print(f"[3.8] env={ENV}  experiment={EXPERIMENT_PATH} (id={_exp.experiment_id})  "
      f"registry={MLFLOW_REGISTRY_URI}  model={REGISTERED_MODEL}")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Gather run params, metrics, and artifacts from the output + rule tables

# COMMAND ----------

preds = spark.read.table(TABLES["predictions_out"])
total = preds.count()

def _counts(colname):
    rows = (preds.groupBy(colname).count()
                 .withColumnRenamed("count", "n").collect())
    return {("null" if r[colname] is None else str(r[colname])): int(r["n"]) for r in rows}

mt    = _counts("match_type")
rp    = _counts("review_priority")
tx    = _counts("taxability")
ec    = _counts("ensemble_confidence")
audit = _counts("audit_ready")

# Active rules snapshot + a stable hash for the version.
rules = spark.read.table(TABLES["classification_rules"]).filter("active = true")
rules_pd = rules.toPandas().sort_values("rule_id")
rule_total = len(rules_pd)
rules_by_type = {k: int(v) for k, v in rules_pd["rule_type"].value_counts().items()}
rule_hash = hashlib.sha256(rules_pd.to_csv(index=False).encode()).hexdigest()[:16]

# pipeline_config as a dict (best-effort).
try:
    cfg_pd = spark.read.table(TABLES["pipeline_config"]).toPandas()
    config_dict = dict(zip(cfg_pd["config_key"], cfg_pd["config_value"]))
except Exception as e:
    config_dict = {"_error": str(e)}

print(f"[3.8] rows={total:,}  match_type={mt}  rules_active={rule_total} hash={rule_hash}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Log the MLflow run (params + metrics + artifacts)

# COMMAND ----------

# NO driver temp directory. Serverless compute has no durable local disk, files
# written there leaked whenever the run failed part-way, and the cleanup never
# ran on the error path. Everything is held in memory and logged with
# mlflow.log_dict(), which serialises and uploads straight to the tracking store.
rules_records  = json.loads(rules_pd.to_json(orient="records", date_format="iso"))
sample_records = json.loads(
    preds.limit(200).toPandas().to_json(orient="records", date_format="iso"))

manifest = {
    "pipeline_version_month": MONTH,
    "rule_snapshot_sha": rule_hash,
    "rule_total_active": rule_total,
    "rules_by_type": rules_by_type,
    "llm_endpoint": ENDPOINTS["llm"],
    "embedding_endpoint": ENDPOINTS["embedding"],
    "xgboost_endpoint": ENDPOINTS["xgboost"],
    "thresholds": PARAMS,
    "llm_available": bool(LLM_AVAILABLE),
    "rag_available": bool(RAG_AVAILABLE),
    "embeddings_available": bool(EMBEDDINGS_AVAILABLE),
    "local_nlp_classifier": bool(LOCAL_NLP_CLASSIFIER),
    "generate_llm_writeups": bool(GENERATE_LLM_WRITEUPS),
    "llm_writeups_effective": bool(LLM_WRITEUPS_ON),
    "config": config_dict,
    "output_table": TABLES["predictions_out"],
}
# manifest stays in memory; logged via mlflow.log_dict() below.

params = {
    "month": MONTH, "catalog": CATALOG, "schema": SCHEMA,
    "llm_endpoint": ENDPOINTS["llm"], "embedding_endpoint": ENDPOINTS["embedding"],
    "xgboost_endpoint": ENDPOINTS["xgboost"],
    "llm_available": bool(LLM_AVAILABLE),
    "rag_available": bool(RAG_AVAILABLE),
    "embeddings_available": bool(EMBEDDINGS_AVAILABLE),
    "local_nlp_classifier": bool(LOCAL_NLP_CLASSIFIER),
    "generate_llm_writeups": bool(GENERATE_LLM_WRITEUPS),
    "llm_writeups_effective": bool(LLM_WRITEUPS_ON),
    "rule_total_active": rule_total, "rule_snapshot_sha": rule_hash,
}
params.update({f"thr_{k}": v for k, v in PARAMS.items()})
params.update({f"rules_{k}": v for k, v in rules_by_type.items()})

metrics = {
    "rows_total": total,
    "match_det": mt.get("det", 0), "match_rag": mt.get("rag", 0), "match_ml": mt.get("ml", 0),
    "review_low": rp.get("LOW", 0), "review_med": rp.get("MED", 0),
    "review_high": rp.get("HIGH", 0), "review_critical": rp.get("CRITICAL", 0),
    "audit_ready_true": audit.get("true", 0) + audit.get("True", 0),
    "audit_pending": audit.get("false", 0) + audit.get("False", 0),
    "ensemble_llm_only": ec.get("LLM_ONLY", 0), "ensemble_resolve": ec.get("RESOLVE", 0),
    "taxable": tx.get("Taxable", 0), "exempt": tx.get("Exempt", 0),
    "taxability_null": tx.get("null", 0),
}

with mlflow.start_run(run_name=f"phase3_{MONTH}") as run:
    RUN_ID = run.info.run_id
    mlflow.set_tags({"phase": "3", "month": MONTH, "rule_snapshot_sha": rule_hash})
    mlflow.log_params(params)
    mlflow.log_metrics({k: float(v) for k, v in metrics.items()})
    mlflow.log_dict(manifest, "manifest.json")
    mlflow.log_dict({"match_type": mt, "review_priority": rp,
                     "taxability": tx, "ensemble": ec, "audit_ready": audit},
                    "run_profile.json")
    # NO local temp files. Everything is logged from memory via log_dict /
    # log_text, which MLflow uploads straight to the tracking store. Writing
    # CSVs to a driver temp directory first was fragile (serverless has no
    # durable local disk, and the files leaked if the run failed part-way)
    # and needed cleanup that never ran on the error path.
    mlflow.log_dict(rules_records, "rules/rules_snapshot.json")
    mlflow.log_dict(sample_records, "sample/output_sample.json")

print(f"[3.8] logged MLflow run {RUN_ID}")
print(f"[3.8] metrics: {metrics}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Register a versioned pipeline model in the UC registry (fail-soft)

# COMMAND ----------

class ATIMSPipelineModel(mlflow.pyfunc.PythonModel):
    """Version stamp for the Phase 3 pipeline. The heavy scoring runs in the
    Spark notebooks; this registered model captures and versions the exact
    rules snapshot + config + prompt manifest that produced a given run, so the
    UC registry holds one governed, promotable version per release."""
    def __init__(self, manifest):
        # Manifest is carried IN the model object rather than read from a local
        # artifact file, so no temp directory is needed at log time or at load
        # time. It is pickled with the model and versioned alongside it.
        self.manifest = manifest

    def load_context(self, context):
        # No-op: this model is a version stamp only; all heavy scoring runs in
        # the Spark notebooks. The manifest is pickled with the model object.
        pass
    def predict(self, context, model_input):
        import pandas as pd
        v = self.manifest.get("pipeline_version_month")
        h = self.manifest.get("rule_snapshot_sha")
        return pd.Series([f"{v}:{h}"] * len(model_input))

try:
    from mlflow.models.signature import infer_signature
    example = pd.DataFrame({"ping": ["status"]})
    sig = infer_signature(example, pd.Series(["2022-12:abc"]))
    with mlflow.start_run(run_id=RUN_ID):
        info = mlflow.pyfunc.log_model(
            artifact_path="model",
            python_model=ATIMSPipelineModel(manifest),
            # The manifest, rule snapshot and config are already logged on this
            # run via log_dict(); referencing them here would require local
            # files again. The registered model carries them as metadata instead.
            artifacts=None,
            signature=sig,
            input_example=example,
            registered_model_name=REGISTERED_MODEL,
            pip_requirements=["mlflow", "pandas"],
        )
    # Tag the new version + point the 'latest' alias at it.
    client = MlflowClient()
    mv = None
    for rmv in client.search_model_versions(f"name='{REGISTERED_MODEL}'"):
        if rmv.run_id == RUN_ID:
            mv = rmv.version; break
    if mv:
        client.set_model_version_tag(REGISTERED_MODEL, mv, "month", MONTH)
        client.set_model_version_tag(REGISTERED_MODEL, mv, "rows_total", str(total))
        client.set_model_version_tag(REGISTERED_MODEL, mv, "rule_snapshot_sha", rule_hash)
        client.set_registered_model_alias(REGISTERED_MODEL, "latest", mv)
        print(f"[3.8] registered {REGISTERED_MODEL} version {mv} (alias 'latest')")
    else:
        print("[3.8] model logged but version lookup failed; check the registry UI.")
except Exception as e:
    print(f"[3.8] UC model registration skipped ({type(e).__name__}: {e}).")
    print("      The run + metrics + artifacts are still logged. To enable "
          "registration: ensure the cluster can CREATE MODEL in "
          f"{CATALOG}.{SCHEMA} and that UC model registry is enabled.")

dbutils.notebook.exit("3.8 OK")