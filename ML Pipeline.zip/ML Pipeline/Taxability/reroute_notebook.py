# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.6 — Re-route
# MAGIC
# MAGIC Iterates on QA-flagged records up to `PARAMS['max_reroute_passes']` passes.
# MAGIC Only **ML-classified** rows (`match_type = 'ml'`, `override_suggested = true`)
# MAGIC are eligible (AUDIT B7) — deterministic rule hits are never re-classified;
# MAGIC flagged rule/RAG rows escalate straight to human review.
# MAGIC
# MAGIC Each pass re-runs the LLM **classifier resolution with the QA anomalies
# MAGIC injected into the prompt** (the embeddings are unchanged, so the new signal
# MAGIC is the QA hint), then re-applies matrix lookup → use-tax → write-up → QA on
# MAGIC the flagged subset. Records still flagged after the cap → `CRITICAL`.
# MAGIC
# MAGIC Output: `STAGE['reroute']` (clean rows ∪ re-processed rows).
# MAGIC
# MAGIC **No-LLM mode (`LLM_AVAILABLE = False` in config_notebook):** re-classification
# MAGIC is an LLM call with no deterministic substitute, so this task performs none.
# MAGIC Flagged rows are escalated to `CRITICAL` with a reviewer note and passed through.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql.functions import col, lit, when, array_join

max_passes = PARAMS["max_reroute_passes"]
categories = load_categories(spark)
llm        = ENDPOINTS["llm"]
label_list = ", ".join(c.replace("'", "") for c in categories)

df      = read_stage(spark, STAGE["qa"])
# NULL-SAFE SPLIT. `filter(~col(x))` and `filter(col(x))` BOTH reject NULL, so a
# NULL override_suggested makes a row disappear from the pipeline entirely — no
# error, no warning, and if it is NULL for every row the final output is empty
# while every task still reports success. QA derives it as
# (anomaly_score >= 0.33) AND (match_type == 'ml'), and in Spark
# `True AND NULL` is NULL, so a NULL match_type is enough to trigger this.
# Coalescing to False means an undetermined row is treated as "not flagged"
# and still flows through to the output.
_ovr = F.coalesce(col("override_suggested"), lit(False))
clean   = df.filter(~_ovr)
flagged = df.filter(_ovr).withColumn("iteration", lit(0))

_n_in, _n_clean, _n_flag = df.count(), clean.count(), flagged.count()
if _n_clean + _n_flag != _n_in:
    raise ValueError(f"[3.6] row loss in the clean/flagged split: {_n_in:,} in, "
                     f"{_n_clean:,} + {_n_flag:,} out. Check override_suggested for NULLs.")
print(f"[3.6] initial flagged (ML, override): {flagged.count():,}")

# ---------------------------------------------------------------------------
# NO-LLM MODE: re-classification IS an LLM call — there is no deterministic
# substitute for it, and re-running the same rules/XGBoost would return the same
# answer QA just flagged. So when LLM_AVAILABLE is False this task performs no
# re-classification at all; flagged rows are escalated to CRITICAL human review
# with an explicit reviewer_note, and the stage table is written unchanged
# otherwise. Downstream (3.7) sees exactly the schema it expects.
# ---------------------------------------------------------------------------
if not LLM_AVAILABLE:
    n_flagged = flagged.count()
    escalated = (flagged
                 .withColumn("review_priority", lit("CRITICAL"))
                 .withColumn("reviewer_note",
                             lit("PENDING: QA-flagged and re-route unavailable "
                                 "(no LLM access) — awaiting human review"))
                 .withColumn("classification_changed", lit(False))
                 .withColumn("writeup_regenerated",    lit(False))
                 .withColumn("override_suggested",     lit(False)))
    out = clean.unionByName(escalated, allowMissingColumns=True)
    write_stage(out, STAGE["reroute"])
    print(f"[3.6] LLM_AVAILABLE=False -> no re-classification. "
          f"{n_flagged:,} flagged row(s) escalated to CRITICAL; {out.count():,} rows written.")
    dbutils.notebook.exit("3.6 OK (no-LLM: escalated)")

# COMMAND ----------

def reclassify_with_hint(frame, pass_no=1):
    """Re-run LLM resolution with the QA anomalies as a hint, then re-derive category.

    Renames the prior `final_category` → `prev_category` so the new column from
    ai_query() does not collide with `SELECT *`. FIX 3: `prev_category` is KEPT
    so downstream can detect whether the classification actually changed and
    regenerate the write-up accordingly.
    """
    frame = (frame
             .withColumnRenamed("final_category", "prev_category")
             .withColumn("_qa_hint", array_join(col("anomalies"), ", ")))
    frame.createOrReplaceTempView("reroute_temp")
    return spark.sql(f"""
        SELECT *,
            ai_query(
                '{llm}',
                concat_ws(' ',
                    'Re-classify this AP invoice line. A prior automated pass was flagged by QA.',
                    'QA anomalies:', COALESCE(_qa_hint, 'none'),
                    '. Attempt number:', '{pass_no}',
                    CASE WHEN {pass_no} > 1 THEN
                        '. A previous attempt returned the same category and was rejected; consider an alternative.'
                        ELSE '' END,
                    '. Description:', COALESCE(final_description, ''),
                    '. Vendor:', COALESCE(vendor_name, ''),
                    '. Previous category:', COALESCE(prev_category, 'n/a'),
                    '. Choose the single best label from:', '{label_list}'
                )
            ) AS final_category
        FROM reroute_temp
    """).drop("_qa_hint")


def matrix_join(frame):
    frame = frame.drop("taxability", "tax_source")
    raw_matrix = spark.read.table(TABLES["taxability_matrix"])
    # Auto-detect cluster and value columns (matches tax_lookup_notebook).
    _clscol = next((c for c in raw_matrix.columns
                    if c.lower() in ("cluster", "category", "final_category")), None)
    _valcol = next((c for c in raw_matrix.columns
                    if c.lower() in ("taxability", "taxable", "is_taxable", "tax")), None)
    if _clscol is None or _valcol is None:
        print("[3.6] matrix missing cluster/taxability column; taxability left NULL.")
        return (frame
                .withColumn("taxability", lit(None).cast("string"))
                .withColumn("tax_source", lit("no_matrix")))
    # Normalize value column (1/0, Y/N, true/false → Taxable/Exempt).
    _v = F.lower(F.trim(col(_valcol).cast("string")))
    matrix = (raw_matrix
              .withColumn("_m_tax",
                          when(_v.isin("1", "y", "yes", "true", "t", "taxable"), lit("Taxable"))
                          .when(_v.isin("0", "n", "no", "false", "f", "exempt"), lit("Exempt"))
                          .otherwise(col(_valcol).cast("string")))
              .select(col(_clscol).alias("_c"), col("state").alias("_s"), "_m_tax"))
    return (frame.join(F.broadcast(matrix),
                       (col("final_category") == col("_c")) & (col("state") == col("_s")), "left")
                 .withColumn("taxability", col("_m_tax"))
                 .drop("_c", "_s", "_m_tax")
                 .withColumn("tax_source",
                             when(col("taxability").isNotNull(), lit("matrix"))
                             .otherwise(lit("no_match"))))


def use_tax(frame):
    # Defensive: derive use_tax_amount from tax_amount/tax_type when the
    # column is absent (matches use_tax_lookup_notebook normalization).
    if "use_tax_amount" not in frame.columns:
        if "tax_amount" in frame.columns and "tax_type" in frame.columns:
            frame = frame.withColumn(
                "use_tax_amount",
                when(col("tax_type").rlike("(?i)use"), col("tax_amount").cast("double"))
                .otherwise(lit(0.0)))
        else:
            frame = frame.withColumn("use_tax_amount", lit(None).cast("double"))
    return frame.withColumn(
        "Reverse_UseTax",
        when((col("use_tax_amount") > 0) & (col("taxability") == "Exempt"),  lit("Yes"))
        .when((col("use_tax_amount") > 0) & (col("taxability") == "Taxable"), lit("No"))
        .when(col("use_tax_amount") == 0, lit("No"))
        .otherwise(lit(None).cast("string")))

# COMMAND ----------

def regenerate_writeup(frame):
    """FIX 3 (review comment): after re-classification, the write-up produced by
    Task 3.4 describes the OLD category/taxability and must be regenerated when
    the classification changed. Uses the SAME generation logic as Task 3.4 via
    the shared `writeup_case_sql` helper in config_notebook, so the two paths
    cannot drift. Rows whose category did NOT change keep their original
    write-up untouched (same category + state -> same matrix row -> same
    taxability -> the original write-up is still accurate).
    """
    changed   = frame.filter(~col("final_category").eqNullSafe(col("prev_category")))
    unchanged = frame.filter(col("final_category").eqNullSafe(col("prev_category")))
    n_changed = changed.count()
    print(f"[3.6] classification changed for {n_changed:,} rerouted rows -> regenerating write-ups")

    if n_changed == 0:
        return frame.withColumn("classification_changed", lit(False)) \
                    .withColumn("writeup_regenerated",  lit(False))

    # The shared CASE expects `retrieved_writeups`; in templated mode it is
    # unused (same behaviour as Task 3.4's templated path).
    regen = changed.drop("full_writeup", "short_justification",
                         "reviewer_note", "audit_ready")
    if "retrieved_writeups" not in regen.columns:
        regen = regen.withColumn("retrieved_writeups", lit("").cast("string"))

    regen.createOrReplaceTempView("reroute_writer_temp")
    regen = spark.sql(f"""
        SELECT *, {writeup_case_sql(llm, LLM_WRITEUPS_ON)} AS full_writeup
        FROM reroute_writer_temp
    """)
    regen = (regen
             .withColumn("short_justification",
                         when(col("full_writeup").isNotNull(),
                              col("full_writeup").substr(1, 280))
                         .otherwise(lit(None).cast("string")))
             .withColumn("reviewer_note",
                         when(col("final_category").isNull(),
                              lit("PENDING: no category after re-route — awaiting human review"))
                         .when(col("taxability").isNull(),
                              lit("PENDING: no taxability match after re-route — awaiting human review"))
                         .otherwise(lit(None).cast("string")))
             .withColumn("audit_ready",
                         col("taxability").isNotNull()
                         & col("final_category").isNotNull()
                         & col("full_writeup").isNotNull())
             .withColumn("classification_changed", lit(True))
             .withColumn("writeup_regenerated",  lit(True))
             .drop("retrieved_writeups"))

    unchanged = unchanged.withColumn("classification_changed", lit(False)) \
                         .withColumn("writeup_regenerated",  lit(False))
    return unchanged.unionByName(regen, allowMissingColumns=True)

# COMMAND ----------

for p in range(1, max_passes + 1):
    n = flagged.count()
    if n == 0:
        break
    print(f"[3.6] pass {p}/{max_passes} on {n:,} flagged ML records...")

    # Re-classify (with QA hint) → matrix → use-tax → regenerate write-up (FIX 3).
    re = reclassify_with_hint(flagged, p)
    re = matrix_join(re)
    re = use_tax(re)
    re = regenerate_writeup(re)
    # keep a copy so an unresolved row can be re-offered next pass
    re = re.withColumnRenamed("prev_category", "prev_category_kept")
    re = re.withColumn("iteration", lit(p)) \
           .withColumn("override_suggested", lit(False))  # re-QA in 3.5 on next full run

    # FIX 3 guard: no re-classified row may leave 3.6 with a write-up that was
    # not regenerated, or with a fully determined row (category AND taxability)
    # that has no write-up. Rows deliberately left without a write-up because
    # they lack a category or a taxability are pending review, not stale.
    _stale = re.filter(col("classification_changed") &
                       (~col("writeup_regenerated") |
                        (col("taxability").isNotNull()
                         & col("final_category").isNotNull()
                         & col("full_writeup").isNull()))).count()
    assert _stale == 0, f"[3.6] {_stale} re-classified row(s) would carry a stale write-up"

    # REAL MULTI-PASS LOOP. Previously this did `flagged = flagged.limit(0)`,
    # which ended the loop after one iteration regardless of max_reroute_passes
    # and left the CRITICAL escalation below permanently unreachable.
    #
    # A row is RESOLVED when re-classification actually changed the category —
    # the anomaly that flagged it has been acted on, and it moves to `clean`.
    # A row whose category came back UNCHANGED was not resolved by this pass, so
    # it carries into the next one with the pass number in the hint (without
    # that, re-sending an identical prompt returns an identical answer and the
    # extra pass is wasted). Whatever is still unresolved after max_passes falls
    # through to the CRITICAL escalation, which is now reachable.
    _resolved   = re.filter(col("classification_changed"))
    _unresolved = re.filter(~col("classification_changed"))
    _n_res, _n_unres = _resolved.count(), _unresolved.count()
    print(f"[3.6] pass {p}: {_n_res:,} resolved, {_n_unres:,} still unresolved")

    clean   = clean.unionByName(_resolved, allowMissingColumns=True)
    # Restore the pre-pass shape so the next iteration can re-classify them.
    # FIX: drop stale _rejected_category from previous passes before renaming,
    # otherwise pass 2+ produces two columns with the same name, leading to
    # ambiguous references in downstream Spark operations.
    flagged = (_unresolved
               .drop("_rejected_category")
               .withColumnRenamed("final_category", "_rejected_category")
               .withColumnRenamed("prev_category_kept", "final_category")
               if "prev_category_kept" in _unresolved.columns else _unresolved)
    # Truncate the growing Spark lineage so subsequent passes don't accumulate
    # an ever-deeper logical plan (each pass stacks reclassify → matrix →
    # use-tax → writeup transformations on the previous plan).  Without this,
    # pass 3+ can trigger StackOverflowError during planning or very slow
    # catalyst optimisation.  localCheckpoint materialises to executor storage
    # (no HDFS/DBFS write) and is cleaned up when the SparkContext ends.
    flagged = flagged.localCheckpoint(eager=True)

# Anything still unresolved after max_passes → CRITICAL escalation. Now
# REACHABLE: the loop above no longer empties `flagged` on the first iteration.
_n_escalated = flagged.count()
if _n_escalated > 0:
    clean = clean.unionByName(
        flagged.withColumn("review_priority", lit("CRITICAL"))
               .withColumn("reviewer_note",
                           lit(f"ESCALATED: still anomalous after {max_passes} "
                               "re-route pass(es) — needs human review"))
               .withColumn("override_suggested", lit(False)),
        allowMissingColumns=True)
print(f"[3.6] escalated to CRITICAL after {max_passes} pass(es): {_n_escalated:,}")

write_stage(clean, STAGE["reroute"])
print(f"[3.6] re-route complete: {clean.count():,} rows")
dbutils.notebook.exit("3.6 OK")