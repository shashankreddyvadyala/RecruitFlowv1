# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.5 — QA
# MAGIC
# MAGIC Six statistical / consistency checks via Spark window functions + JOINs,
# MAGIC computed over the **full month's unified records** (AUDIT B8) so vendor /
# MAGIC category / amount distributions are not biased to the ML subset.
# MAGIC
# MAGIC 1. Vendor-category consistency  2. Amount z-score  3. State-category history
# MAGIC 4. Rule-vs-classifier conflict  5. Taxability sanity  6. Batch-level outlier
# MAGIC
# MAGIC Output: `anomalies`, `anomaly_score`, `review_priority`, `override_suggested`.
# MAGIC Re-route (3.6) is only suggested for ML rows; rule/RAG anomalies escalate.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql import Window
from pyspark.sql.functions import col, lit, when, count, array, array_compact
from pyspark.sql.functions import avg, stddev, abs as sabs

df = read_stage(spark, STAGE["tax_writer"])
zflag = PARAMS["amount_z_flag"]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check 1 — vendor-category consistency  &  Check 6 — batch outlier

# COMMAND ----------

# Vendor-consistency flags. Use vendor_id if present, else fall back to
# vendor_name (the legacy rule data keys vendors by name, not id).
_vendor_key = "vendor_id" if "vendor_id" in df.columns else "vendor_name"
_FULL = (Window.unboundedPreceding, Window.unboundedFollowing)
w_vendor      = Window.partitionBy(_vendor_key).rowsBetween(*_FULL)
w_vendor_cat  = Window.partitionBy(_vendor_key, "final_category").rowsBetween(*_FULL)

df = (df
      .withColumn("_vendor_cat_freq", count("*").over(w_vendor_cat))
      .withColumn("_vendor_total",    count("*").over(w_vendor))
      .withColumn("_vendor_cat_ratio", col("_vendor_cat_freq") / col("_vendor_total"))
      .withColumn("flag_vendor_inconsistent", col("_vendor_cat_ratio") < lit(0.5))
      .withColumn("flag_batch_outlier",       col("_vendor_cat_ratio") < lit(0.05)))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check 2 — amount z-score within category

# COMMAND ----------

w_cat = Window.partitionBy("final_category").rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
df = (df
      .withColumn("_amt_mean", avg("amount").over(w_cat))
      .withColumn("_amt_std",  stddev("amount").over(w_cat))
      .withColumn("amount_z",
                  when(col("_amt_std") > 0,
                       sabs((col("amount") - col("_amt_mean")) / col("_amt_std")))
                  .otherwise(lit(0.0)))
      .withColumn("flag_amount_outlier", col("amount_z") > lit(zflag)))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check 3 — state-category history (unseen combo)

# COMMAND ----------

# FAIL-SOFT. table_available() forces an eager check first: on serverless the
# read alone would not raise, df would already be joined to a missing table, and
# the except block would never run. _df_in preserves the pre-join frame so a
# late failure can never leave a poisoned plan behind.
_df_in = df
if table_available(spark, TABLES["historical_stats"]):
    try:
        hist = (spark.read.table(TABLES["historical_stats"])
                     .select(col("final_category").alias("_h_cat"),
                             col("state").alias("_h_state")).distinct())
        df = (_df_in.join(F.broadcast(hist),
                          (col("final_category") == col("_h_cat"))
                          & (col("state") == col("_h_state")), "left")
                    .withColumn("flag_new_state_combo", col("_h_cat").isNull())
                    .drop("_h_cat", "_h_state"))
        df.limit(0).count()          # force analysis while we can still recover
    except Exception as e:
        print(f"[3.5] historical_stats join failed ({type(e).__name__}); check 3 skipped.")
        df = _df_in.withColumn("flag_new_state_combo", lit(False))
else:
    print("[3.5] historical_stats unavailable; check 3 (new state/category combo) skipped.")
    df = _df_in.withColumn("flag_new_state_combo", lit(False))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check 4 — rule decision contradicted by an independent model
# MAGIC
# MAGIC **Rewritten.** The previous version tested
# MAGIC `match_type IN ('det','rag') AND xgboost_pred IS NOT NULL`, which can never
# MAGIC be true: `xgboost_pred` is only populated on the ML branch and is NULL on
# MAGIC every rule/RAG row after `unionByName(..., allowMissingColumns=True)`. The
# MAGIC check was dead, so the cross-validation the architecture calls for was not
# MAGIC actually happening.
# MAGIC
# MAGIC It now uses `t32_rule_audit`, written by Task 3.2, which DOES score a model
# MAGIC on rule-matched rows. The scoring model is trained **only on high-precision
# MAGIC labels** (exact_match / vendor / expression) and is applied to the
# MAGIC keyword-tier rows, so it has never seen the labels it is checking — its
# MAGIC disagreement is independent evidence rather than an echo. Scoring the
# MAGIC decision model on its own training rows would reproduce the original
# MAGIC problem in a subtler form: it agrees with those labels ~100% of the time.
# MAGIC
# MAGIC The rule always wins. This only raises the row for human review.

# COMMAND ----------

_df_in = df
_audit_cols = lambda frame: (frame
    .withColumn("flag_rule_model_conflict", lit(False))
    .withColumn("model_second_opinion", lit(None).cast("string"))
    .withColumn("model_second_opinion_margin", lit(None).cast("double")))

if table_available(spark, STAGE["rule_audit"]):
    try:
        _audit = (spark.read.table(STAGE["rule_audit"])
                       .filter(col("second_opinion_conflict"))
                       .select(col("invoice_id").alias("_a_inv"),
                               col("inv_line_number").alias("_a_line"),
                               col("second_opinion").alias("model_second_opinion"),
                               col("second_opinion_margin").alias("model_second_opinion_margin"))
                       .dropDuplicates(["_a_inv", "_a_line"]))
        df = (_df_in.join(F.broadcast(_audit),
                          (col("invoice_id") == col("_a_inv"))
                          & (col("inv_line_number") == col("_a_line")), "left")
                    .withColumn("flag_rule_model_conflict", col("_a_inv").isNotNull())
                    .drop("_a_inv", "_a_line"))
        print(f"[3.5] check 4 — rule decisions contradicted by the independent model: "
              f"{df.filter(col('flag_rule_model_conflict')).count():,}")
    except Exception as e:
        print(f"[3.5] rule_audit join failed ({type(e).__name__}); check 4 skipped.")
        df = _audit_cols(_df_in)
else:
    print("[3.5] rule_audit not present (Task 3.2 produced no audit); check 4 skipped.")
    df = _audit_cols(_df_in)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check 5 — taxability sanity (service taxable in a no-service-tax state)

# COMMAND ----------

# FAIL-SOFT, same eager-check pattern as check 3.
_df_in = df
if table_available(spark, TABLES["state_service_rules"]):
    try:
        state_rules = (spark.read.table(TABLES["state_service_rules"])
                            .select(col("state").alias("_s_state"),
                                    col("service_taxable").alias("_s_taxable")))
        df = (_df_in.join(F.broadcast(state_rules), col("state") == col("_s_state"), "left")
                    .withColumn("flag_tax_sanity",
                                (col("taxability") == "Taxable") & (col("_s_taxable") == lit(False)))
                    .drop("_s_state", "_s_taxable"))
        df.limit(0).count()
    except Exception as e:
        print(f"[3.5] state_service_tax_rules join failed ({type(e).__name__}); check 5 skipped.")
        df = _df_in.withColumn("flag_tax_sanity", lit(False))
else:
    print("[3.5] state_service_tax_rules unavailable; check 5 (taxability sanity) skipped.")
    df = _df_in.withColumn("flag_tax_sanity", lit(False))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Aggregate → anomaly score, review priority, override suggestion

# COMMAND ----------



# COMMAND ----------

flag_cols = ["flag_vendor_inconsistent", "flag_amount_outlier", "flag_new_state_combo",
             "flag_rule_model_conflict", "flag_tax_sanity", "flag_batch_outlier"]

# Treat null flags as False so missing reference tables don't poison the score.
for c in flag_cols:
    df = df.withColumn(c, F.coalesce(col(c), lit(False)))

score_expr = sum(when(col(c), 1).otherwise(0) for c in flag_cols) / lit(float(len(flag_cols)))
df = (df
      .withColumn("anomaly_score", score_expr)
      .withColumn("anomalies",
                  array_compact(array(*[when(col(c), lit(c)) for c in flag_cols])))
      .withColumn("review_priority",
                  # No taxability OR no category at all (UNRESOLVED in no-LLM
                  # mode) -> always human review, regardless of anomaly score.
                  when(col("taxability").isNull() | col("final_category").isNull(),
                       lit("HIGH"))
                  .when(col("anomaly_score") >= 0.5,  lit("CRITICAL"))
                  .when(col("anomaly_score") >= 0.33, lit("HIGH"))
                  .when(col("anomaly_score") > 0,     lit("MED"))
                  .otherwise(lit("LOW")))
      # Only ML rows are eligible for re-classification (AUDIT B7).
      .withColumn("override_suggested",
                  (col("anomaly_score") >= 0.33) & (col("match_type") == "ml"))
      .withColumn("recommendation", lit(None).cast("string")))

out = df.drop("_vendor_cat_freq", "_vendor_total", "_vendor_cat_ratio",
              "_amt_mean", "_amt_std")

write_stage(out, STAGE["qa"])
print("[3.5] review_priority distribution:")
out.groupBy("review_priority").count().show()
dbutils.notebook.exit("3.5 OK")