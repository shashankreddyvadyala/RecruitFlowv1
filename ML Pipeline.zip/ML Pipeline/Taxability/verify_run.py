# Databricks notebook source
# MAGIC %md
# MAGIC # VERIFY RUN — did the pipeline actually do the work?
# MAGIC
# MAGIC A task can finish fast and report success while doing nothing useful:
# MAGIC
# MAGIC 1. **Stale stage tables.** Every task writes with `mode("overwrite")`, but
# MAGIC    the tables persist between runs. If a task was skipped, or ran for a
# MAGIC    different `MONTH`, the next task happily reads the PREVIOUS run's data
# MAGIC    and succeeds.
# MAGIC 2. **Empty inputs.** A join that matches nothing still writes a table and
# MAGIC    still exits `OK`.
# MAGIC 3. **Fail-soft paths.** Several components degrade silently by design
# MAGIC    (Vector Search, XGBoost, the local model, the taxability matrix). A run
# MAGIC    with all of them off is a valid run that decided very little.
# MAGIC
# MAGIC This notebook checks Delta history (`numOutputRows` + write timestamps) and
# MAGIC reconciles row counts across the chain. Run it right after the pipeline.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from datetime import datetime, timezone

def _hist(tbl):
    """Latest write to a Delta table: when, how, and how many rows."""
    try:
        h = spark.sql(f"DESCRIBE HISTORY {tbl} LIMIT 1").collect()[0]
        m = h["operationMetrics"] or {}
        return {"exists": True,
                "ts": h["timestamp"],
                "op": h["operation"],
                "rows_written": int(m.get("numOutputRows", -1))}
    except Exception as e:
        return {"exists": False, "ts": None, "op": None, "rows_written": -1,
                "err": type(e).__name__}

def _count(tbl):
    try:
        return spark.read.table(tbl).count()
    except Exception:
        return -1

CHAIN = [
    ("input   prediction_ready", TABLES["prediction_ready"]),
    ("3.1     t31_month_src",    STAGE.get("month_src")),
    ("3.1     t31_rules_matched", STAGE["rules_matched"]),
    ("3.1     t31_rag_matched",   STAGE["rag_matched"]),
    ("3.1     t31_unmatched",     STAGE["unmatched"]),
    ("3.2     t32_classified",    STAGE["classified"]),
    ("3.2     t32_rule_audit",    STAGE.get("rule_audit")),
    ("3.3     t33_tax_lookup",    STAGE["tax_lookup"]),
    ("3.3b    t33b_use_tax",      STAGE["use_tax"]),
    ("3.4     t34_tax_writer",    STAGE["tax_writer"]),
    ("3.5     t35_qa",            STAGE["qa"]),
    ("3.6     t36_reroute",       STAGE["reroute"]),
    ("3.7     OUTPUT",            TABLES["predictions_out"]),
]

now = datetime.now(timezone.utc)
print(f"MONTH under test: {MONTH}\n")
print(f"{'stage':28} {'rows':>10} {'written':>10} {'age':>12}  last write")
print("-" * 92)
rows = {}
for label, tbl in CHAIN:
    if tbl is None:
        print(f"{label:28} {'n/a':>10}   (not defined in this config version)")
        continue
    h = _hist(tbl)
    n = _count(tbl)
    rows[label.split()[-1]] = n
    if not h["exists"]:
        print(f"{label:28} {'MISSING':>10}  <-- table does not exist")
        continue
    age_min = (now - h["ts"].replace(tzinfo=timezone.utc)).total_seconds() / 60
    warn = "  <-- STALE?" if age_min > 60 else ""
    print(f"{label:28} {n:>10,} {h['rows_written']:>10,} {age_min:>10.1f}m  "
          f"{h['ts']:%Y-%m-%d %H:%M:%S}{warn}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reconciliation — the numbers that must agree

# COMMAND ----------

src_month = (spark.read.table(TABLES["prediction_ready"])
             .filter(F.date_format(F.to_date(col("accounting_date")), "yyyy-MM") == MONTH))
n_src = src_month.count()

n_rules = rows.get("t31_rules_matched", -1)
n_rag   = rows.get("t31_rag_matched", -1)
n_unm   = rows.get("t31_unmatched", -1)
n_cls   = rows.get("t32_classified", -1)
n_out   = rows.get("OUTPUT", -1)

checks = []
checks.append(("source rows for MONTH == 3.1 input",
               n_src, n_rules + n_rag + n_unm,
               "3.1 must partition every input row into exactly one of the three tables"))
checks.append(("3.1 unmatched == 3.2 classified",
               n_unm, n_cls, "3.2 must classify every unmatched row"))
checks.append(("source rows == final output rows",
               n_src, n_out, "no row may be lost or duplicated end to end"))

print(f"{'check':46} {'expected':>10} {'actual':>10}   verdict")
print("-" * 92)
ok_all = True
for name, exp, act, why in checks:
    ok = (exp == act and exp >= 0)
    ok_all &= ok
    print(f"{name:46} {exp:>10,} {act:>10,}   {'PASS' if ok else 'FAIL  <-- ' + why}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Did it actually decide anything?
# MAGIC Row counts can reconcile perfectly while every determination is NULL.

# COMMAND ----------

out = spark.read.table(TABLES["predictions_out"])
tot = out.count()

def pct(n):
    return f"{n:,} ({n/max(tot,1)*100:.1f}%)"

print(f"output rows: {tot:,}\n")
print("determination coverage")
print(f"  category assigned        {pct(out.filter(col('final_category').isNotNull()).count())}")
print(f"  taxability determined    {pct(out.filter(col('taxability').isNotNull()).count())}")
print(f"  use-tax decided          {pct(out.filter(col('Reverse_UseTax').isNotNull()).count())}")
print(f"  audit-ready write-up     {pct(out.filter(col('audit_ready') == True).count())}")
print()
print("how each line was decided")
out.groupBy("match_type").count().orderBy(F.desc("count")).show()
out.groupBy("review_priority").count().orderBy(F.desc("count")).show()

print("\nIf 'taxability determined' is 0%, the pipeline ran correctly but decided")
print("nothing — taxability_matrix is empty. That is the expected state today.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Freshness — were all stages written by the SAME run?
# MAGIC Stage tables written minutes/hours apart mean you are mixing runs.

# COMMAND ----------

ts = []
for label, tbl in CHAIN[1:]:
    if tbl is None:
        continue
    h = _hist(tbl)
    if h["exists"] and h["ts"]:
        ts.append((label.strip(), h["ts"]))
if ts:
    newest = max(t for _, t in ts)
    oldest = min(t for _, t in ts)
    spread = (newest - oldest).total_seconds() / 60
    print(f"oldest stage write : {oldest:%Y-%m-%d %H:%M:%S}")
    print(f"newest stage write : {newest:%Y-%m-%d %H:%M:%S}")
    print(f"spread             : {spread:.1f} minutes")
    if spread > 30:
        print("\nWARNING: stage tables span more than 30 minutes. Some of them are")
        print("probably left over from an earlier run. Re-run the full chain before")
        print("trusting the output.")
    else:
        print("\nAll stage tables written within one window — consistent with a single run.")

# COMMAND ----------

print("VERDICT:", "reconciliation PASSED" if ok_all else "reconciliation FAILED — see above")