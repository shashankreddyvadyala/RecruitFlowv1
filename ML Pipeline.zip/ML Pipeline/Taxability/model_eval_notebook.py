# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.9 — Model Evaluation
# MAGIC
# MAGIC **Read this before trusting any number this notebook prints.**
# MAGIC
# MAGIC Every label the pipeline produces comes from `classification_rules`. The
# MAGIC local classifier is trained on rule-matched rows, so measuring it against
# MAGIC rule labels measures *agreement with the rules*, not correctness. On the
# MAGIC sample data that comes out at 0.995–1.000 precision, which is not a quality
# MAGIC signal — it is the model reproducing its own training source.
# MAGIC
# MAGIC Therefore this notebook has two modes:
# MAGIC
# MAGIC | ground-truth table | what is reported |
# MAGIC |---|---|
# MAGIC | **present** | REAL accuracy vs human labels: overall, per class, and split by how each line was decided |
# MAGIC | **absent** | rule-agreement only, clearly labelled as NOT accuracy, plus the sampling plan to fix that |
# MAGIC
# MAGIC Ground truth table (create it yourself, one row per reviewed line):
# MAGIC
# MAGIC ```sql
# MAGIC CREATE TABLE <catalog>.atims_taxability.ground_truth (
# MAGIC     line_uid         STRING,   -- canonical per-line key (preferred join key)
# MAGIC     invoice_id       STRING,
# MAGIC     inv_line_number  INT,
# MAGIC     true_category    STRING,   -- reviewer's category
# MAGIC     true_taxability  STRING,   -- 'Taxable' | 'Exempt' | NULL if undecided
# MAGIC     reviewer         STRING,
# MAGIC     reviewed_at      TIMESTAMP,
# MAGIC     notes            STRING
# MAGIC );
# MAGIC ```

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

GROUND_TRUTH = _t("ground_truth")
preds = spark.read.table(TABLES["predictions_out"])
n_pred = preds.count()
print(f"predictions under evaluation: {n_pred:,}  (month {MONTH})")

has_gt = table_available(spark, GROUND_TRUTH)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Mode A — real accuracy (ground truth present)

# COMMAND ----------

metrics = {}

if has_gt:
    _gt_raw = spark.read.table(GROUND_TRUTH)
    _gt_cols = {c.lower() for c in _gt_raw.columns}
    _pred_cols = {c.lower() for c in preds.columns}
    # Use the canonical per-line key when both sides carry it;
    # fall back to the legacy pair only for older ground-truth tables.
    _use_uid = "line_uid" in _gt_cols and "line_uid" in _pred_cols

    if _use_uid:
        gt = (_gt_raw
                   .select(col("line_uid").alias("_g_uid"),
                           "true_category", "true_taxability")
                   .filter(col("true_category").isNotNull())
                   .dropDuplicates(["_g_uid"]))
    else:
        gt = (_gt_raw
                   .select(col("invoice_id").alias("_g_inv"),
                           col("inv_line_number").alias("_g_line"),
                           "true_category", "true_taxability")
                   .filter(col("true_category").isNotNull())
                   .dropDuplicates(["_g_inv", "_g_line"]))
        print("[3.9] WARNING: ground-truth table has no line_uid; falling back to "
              "(invoice_id, inv_line_number) which is NOT unique and may inflate metrics.")
    n_gt = gt.count()

    _join_cond = (col("line_uid") == col("_g_uid")) if _use_uid else (
        (col("invoice_id") == col("_g_inv")) & (col("inv_line_number") == col("_g_line")))
    ev = (preds.join(gt, _join_cond, "inner")
               .withColumn("is_correct", col("final_category") == col("true_category")))
    n_ev = ev.count()
    print(f"ground-truth rows: {n_gt:,}   matched to this month's predictions: {n_ev:,}")

    if n_ev == 0:
        print("No overlap between ground truth and this month's output — "
              "check that the labelled lines belong to MONTH.")
    else:
        n_correct = ev.filter(col("is_correct")).count()
        acc = n_correct / n_ev
        # Wald 95% interval — wide at small n, which is the point.
        import math
        se = math.sqrt(acc * (1 - acc) / n_ev)
        lo, hi = max(0.0, acc - 1.96 * se), min(1.0, acc + 1.96 * se)
        metrics["accuracy"] = acc
        metrics["n_evaluated"] = n_ev
        print(f"\n*** REAL ACCURACY: {acc:.3f}  (95% CI {lo:.3f}–{hi:.3f}, n={n_ev:,}) ***\n")

        print("accuracy by how the line was decided:")
        (ev.groupBy("match_type")
           .agg(F.count("*").alias("n"),
                F.avg(col("is_correct").cast("double")).alias("accuracy"))
           .orderBy(F.desc("n")).show(truncate=False))

        print("accuracy by ensemble confidence (does the confidence signal mean anything?):")
        (ev.groupBy("ensemble_confidence")
           .agg(F.count("*").alias("n"),
                F.avg(col("is_correct").cast("double")).alias("accuracy"))
           .orderBy(F.desc("n")).show(truncate=False))

        print("worst categories (where the pipeline is getting it wrong):")
        (ev.groupBy("final_category")
           .agg(F.count("*").alias("n"),
                F.avg(col("is_correct").cast("double")).alias("accuracy"))
           .filter(col("n") >= 5).orderBy("accuracy").show(15, truncate=False))

        print("most common confusions (predicted -> actual):")
        (ev.filter(~col("is_correct"))
           .groupBy("final_category", "true_category")
           .count().orderBy(F.desc("count")).show(15, truncate=False))

        # Does the keyword-tier audit actually catch rule errors?
        if "model_second_opinion" in preds.columns:
            fl = ev.filter(col("model_second_opinion").isNotNull())
            if fl.count() > 0:
                print("\nOn lines where the independent auditor CONTRADICTED the rule:")
                (fl.agg(F.count("*").alias("n_flagged"),
                        F.avg(col("is_correct").cast("double")).alias("rule_was_right"),
                        F.avg((col("model_second_opinion") == col("true_category"))
                              .cast("double")).alias("model_was_right")).show(truncate=False))
                print("If 'model_was_right' > 'rule_was_right', the auditor is finding real "
                      "rule errors and the flagged rules should be fixed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Mode B — no ground truth: what CAN and CANNOT be said

# COMMAND ----------

if not has_gt:
    print("=" * 78)
    print("NO GROUND TRUTH TABLE FOUND — ACCURACY IS UNKNOWN AND UNMEASURABLE")
    print("=" * 78)
    print(f"Expected at: {GROUND_TRUTH}")
    print()
    print("What can be reported without human labels:")
    print("  - rule COVERAGE (how many lines a rule decided)")
    print("  - rule/model AGREEMENT (how often they say the same thing)")
    print("Neither is accuracy. The classifier is trained on rule output, so high")
    print("agreement is expected regardless of whether the rules are correct.")
    print()

    n_rule = preds.filter(col("match_type") == "det").count()
    n_ml   = preds.filter(col("match_type") == "ml").count()
    n_cat  = preds.filter(col("final_category").isNotNull()).count()
    n_tax  = preds.filter(col("taxability").isNotNull()).count()
    print(f"  lines decided by rules      {n_rule:>8,}  ({n_rule/max(n_pred,1)*100:5.1f}%)")
    print(f"  lines decided by the model  {n_ml:>8,}  ({n_ml/max(n_pred,1)*100:5.1f}%)")
    print(f"  lines with a category       {n_cat:>8,}  ({n_cat/max(n_pred,1)*100:5.1f}%)")
    print(f"  lines with a taxability     {n_tax:>8,}  ({n_tax/max(n_pred,1)*100:5.1f}%)")

    if "model_second_opinion" in preds.columns:
        n_conf = preds.filter(col("model_second_opinion").isNotNull()).count()
        print(f"  rule decisions contradicted {n_conf:>8,}  <- highest-value lines to label first")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Build the labelling sample
# MAGIC A stratified sample sized for a usable confidence interval, weighted toward
# MAGIC the lines where being wrong costs the most.

# COMMAND ----------

TARGET_N = 400        # ~+/-5% at 95% confidence on overall accuracy

base = preds.filter(col("final_category").isNotNull())
strata = []

# 1. proportional across categories (the bulk of the sample)
cats = [r["final_category"] for r in base.select("final_category").distinct().collect()]
frac = min(1.0, (TARGET_N * 0.6) / max(base.count(), 1))
strata.append(base.sampleBy("final_category", {c: frac for c in cats}, seed=42)
                  .withColumn("sample_reason", lit("proportional")))

# 2. every line where the auditor contradicted a keyword rule (highest value)
if "model_second_opinion" in preds.columns:
    strata.append(preds.filter(col("model_second_opinion").isNotNull())
                       .limit(int(TARGET_N * 0.2))
                       .withColumn("sample_reason", lit("rule_vs_model_conflict")))

# 3. model-decided lines (no rule ever saw these)
strata.append(preds.filter(col("match_type") == "ml")
                   .orderBy(F.desc("amount")).limit(int(TARGET_N * 0.2))
                   .withColumn("sample_reason", lit("model_decided")))

sample = strata[0]
for s in strata[1:]:
    sample = sample.unionByName(s, allowMissingColumns=True)
# Deduplicate on the stable per-line key; (invoice_id, inv_line_number) is
# NOT unique in the source and silently discards distinct AP lines.
_dedup_key = ["line_uid"] if "line_uid" in sample.columns else ["invoice_id", "inv_line_number"]
sample = sample.dropDuplicates(_dedup_key)

out_cols = ["line_uid", "invoice_id", "inv_line_number", "vendor_name", "state", "amount",
            "final_description", "final_category", "taxability", "match_type",
            "ensemble_confidence", "sample_reason"]
out_cols = [c for c in out_cols if c in sample.columns]
sample = (sample.select(*out_cols)
                .withColumn("true_category", lit(None).cast("string"))
                .withColumn("true_taxability", lit(None).cast("string"))
                .withColumn("reviewer", lit(None).cast("string"))
                .withColumn("notes", lit(None).cast("string")))

write_stage(sample, _t("labeling_queue"))
print(f"labelling queue written: {sample.count():,} lines -> {_t('labeling_queue')}")
print("\nHand this to a tax reviewer. They fill true_category / true_taxability,")
print("then INSERT the completed rows into ground_truth and re-run this notebook.")
sample.groupBy("sample_reason").count().show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Log to MLflow so accuracy is tracked over time, not just today

# COMMAND ----------

if metrics:
    try:
        import mlflow
        exp = mlflow.get_experiment_by_name(MLFLOW_EXPERIMENT)
        if exp:
            mlflow.set_experiment(experiment_id=exp.experiment_id)
            with mlflow.start_run(run_name=f"eval_{MONTH}"):
                mlflow.set_tags({"phase": "3.9", "month": MONTH, "eval": "ground_truth"})
                mlflow.log_metrics({k: float(v) for k, v in metrics.items()})
            print(f"[3.9] logged {metrics} to MLflow.")
        else:
            print("[3.9] MLflow experiment not registered; metrics not logged.")
    except Exception as e:
        print(f"[3.9] MLflow logging skipped ({type(e).__name__}).")

dbutils.notebook.exit("3.9 OK" if has_gt else "3.9 OK (no ground truth — accuracy unknown)")