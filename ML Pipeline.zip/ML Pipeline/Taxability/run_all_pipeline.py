# Databricks notebook source
# MAGIC %md
# MAGIC # ATIMS - Run Whole Pipeline (orchestrator)
# MAGIC
# MAGIC Runs every Phase 3 task in order from one place using `dbutils.notebook.run`.
# MAGIC Each task reads the previous task's Delta stage table and writes its own, so the
# MAGIC order matters. Keep this notebook in the SAME workspace folder as all the task
# MAGIC notebooks (so the `./name` paths resolve).
# MAGIC
# MAGIC **The month** is set in `config_notebook` (`MONTH = "2022-12"`). Change it there.
# MAGIC
# MAGIC **Prerequisites (one-time setup):** the input + rules + config tables must exist.
# MAGIC Run the SETUP cell once (set `RUN_SETUP = True`), or run those notebooks manually:
# MAGIC `load_prediction_ready` and `create_reference_tables` (notebooks, run via
# MAGIC SETUP cell), plus `classification_rules.sql` and `load_taxability_matrix.sql`
# MAGIC (SQL files — run once from a SQL editor or `%sql` cell).

# COMMAND ----------

import time

TIMEOUT = 0

def run_step(label, nb):
    t0 = time.time()
    print(f">> {label}  ({nb}) ...")
    try:
        result = dbutils.notebook.run(f"./{nb}", TIMEOUT)
    except Exception as e:
        print(f"   [FAILED] {label} ({nb}): {e}")
        raise
    print(f"   [OK] {label}: {result}   [{time.time()-t0:0.1f}s]")
    return result

# COMMAND ----------

# MAGIC %md
# MAGIC ## (One-time) setup — input, rules, config tables

# COMMAND ----------

RUN_SETUP = False   # set True the first time, or whenever you reload data/rules

SETUP_STEPS = [
    ("Load prediction_ready (ADLS -> table)", "load_prediction_ready"),
    ("Create pipeline_config + verify rules",   "create_reference_tables"),
]

# NOTE: `classification_rules.sql` and `load_taxability_matrix.sql` are .sql
# files, not notebooks, so `dbutils.notebook.run` cannot execute them. Run
# them once from a SQL editor or a %sql cell before the first pipeline run
# (and again whenever rules or the mapping workbook are reissued).

if RUN_SETUP:
    for label, nb in SETUP_STEPS:
        run_step(label, nb)
    print("SETUP COMPLETE")
else:
    print("RUN_SETUP=False -> skipping setup (assuming tables already exist).")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Run the pipeline chain (3.1 -> 3.8)

# COMMAND ----------

PIPELINE_STEPS = [
    ("3.1  Rules Expert",      "rules_expert_notebook"),
    ("3.2  Classifier",        "classifier_notebook"),
    ("3.3  Tax Lookup",        "tax_lookup_notebook"),
    ("3.3b Use Tax Lookup",    "use_tax_lookup_notebook"),
    ("3.4  Tax Writer",        "tax_writer_notebook"),
    ("3.5  QA",                "qa_notebook"),
    ("3.6  Reroute",           "reroute_notebook"),
    ("3.7  Write Output",      "write_output_notebook"),
    ("3.8  MLflow Tracking",   "mlflow_tracking_notebook"),
]

t_all = time.time()
for label, nb in PIPELINE_STEPS:
    run_step(label, nb)

print(f"\nPIPELINE COMPLETE in {time.time()-t_all:0.1f}s")
print("Final table: <env catalog>.atims_taxability.taxability_predictions (catalog from config_notebook ENV_CONFIG)")

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC   *
# MAGIC from `31500_atims_dev`.atims_taxability.taxability_predictions;

# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC   distinct final_category
# MAGIC from `31500_atims_dev`.atims_taxability.taxability_predictions;

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC select 
# MAGIC   distinct ACCOUNTING_DATE
# MAGIC
# MAGIC from `31500_atims_dev`.atims_taxability.taxability_predictions;

# COMMAND ----------

