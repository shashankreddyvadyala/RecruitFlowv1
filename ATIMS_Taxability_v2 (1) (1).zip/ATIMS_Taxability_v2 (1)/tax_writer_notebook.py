# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.4 — Tax Writer
# MAGIC
# MAGIC Audit-ready taxability justification via `ai_query()` → GPT-4o, grounded by
# MAGIC **Vector Search** RAG over the Prior Write-ups KB (AUDIT A2).
# MAGIC
# MAGIC **Short-circuit (AUDIT B6):** when `taxability IS NULL` the record is pending
# MAGIC human review — we do **not** fabricate an audit-ready write-up or spend a
# MAGIC GPT-4o call. We emit a `reviewer_note` and `audit_ready = false`.
# MAGIC
# MAGIC When `Reverse_UseTax = 'Yes'` the prompt requires the write-up to state that a
# MAGIC use-tax reversal is required and to include `use_tax_amount`.
# MAGIC
# MAGIC Output: `short_justification`, `full_writeup`, `reviewer_note`, `audit_ready`.

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql.functions import col, lit, when, pandas_udf
import pandas as pd

df = read_stage(spark, STAGE["use_tax"])

# COMMAND ----------

# MAGIC %md
# MAGIC ### Batch RAG over Prior Write-ups KB (Vector Search)

# COMMAND ----------

_wu_index = VS_INDEXES["writeups"]
_num      = PARAMS["vs_num_results"]


@pandas_udf("string")
def writeups_search(text: pd.Series) -> pd.Series:
    hits = vs_batch_search(_wu_index, text.tolist(), _num, columns=["full_writeup"])
    return pd.Series([(h.get("full_writeup") or "") for h in hits])


# Only run RAG over the prior write-ups KB when we will actually call the LLM.
# In templated mode the retrieved text is unused, so skip the vector searches.
if GENERATE_LLM_WRITEUPS:
    df = df.withColumn("retrieved_writeups", writeups_search(col("final_description")))
else:
    df = df.withColumn("retrieved_writeups", lit("").cast("string"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write-up generation (skip null-taxability rows)

# COMMAND ----------

df.createOrReplaceTempView("writer_temp")
llm = ENDPOINTS["llm"]

# Write-up policy:
#   * taxability IS NULL                  -> no write-up (pending human review)
#   * needs audit narrative AND flag on   -> full Opus write-up (RAG-grounded)
#   * otherwise (known taxability)        -> instant templated justification
# "Needs audit narrative" = use-tax reversal, COMPLEX disagreement, or ML-decided.
# FIX 3 (review comment): the CASE expression now comes from the shared
# `writeup_case_sql` helper in config_notebook — the SAME logic Task 3.6 uses
# when it regenerates write-ups after re-classification, so the two paths
# cannot drift apart.
gen = spark.sql(f"""
    SELECT *, {writeup_case_sql(llm, GENERATE_LLM_WRITEUPS)} AS full_writeup
    FROM writer_temp
""")

out = (gen
       .withColumn("short_justification",
                   when(col("full_writeup").isNotNull(), col("full_writeup").substr(1, 280))
                   .otherwise(lit(None).cast("string")))
       .withColumn("reviewer_note",
                   when(col("taxability").isNull(),
                        lit("PENDING: no taxability match — awaiting human review"))
                   .otherwise(lit(None).cast("string")))
       # audit_ready when we have a known taxability + a justification (templated or LLM)
       .withColumn("audit_ready", col("taxability").isNotNull() & col("full_writeup").isNotNull())
       .drop("retrieved_writeups"))

write_stage(out, STAGE["tax_writer"])
print(f"[3.4] mode={'LLM-audit' if GENERATE_LLM_WRITEUPS else 'templated'}  "
      f"write-ups: {out.filter(col('audit_ready')).count():,}  "
      f"pending (null taxability): {out.filter(~col('audit_ready')).count():,}")
dbutils.notebook.exit("3.4 OK")