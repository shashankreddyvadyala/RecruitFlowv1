# Databricks notebook source
# MAGIC %md
# MAGIC # Load ML input -> prediction_ready
# MAGIC
# MAGIC One-off loader: read the Phase 1/2 ML input from ADLS and write it to the
# MAGIC Delta table that Task 3.1 reads. Phase 3 normalizes the schema automatically
# MAGIC (see `normalize_input` in config_notebook), so keep the raw column names
# MAGIC (MIC, TRAN_AMOUNT, INVOICE_AMOUNT, ...) — they map to mic_cln / amount at read.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Confirm `source_path` + `source_format` below.
# MAGIC 2. Run. It prints the months present so you can pick the right widget value.
# MAGIC 3. In every Task notebook, set the **month** widget to match the data
# MAGIC    (e.g. **2023-01**), or Task 3.1 will match zero rows.

# COMMAND ----------

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

# FIX 1 (review comment): the storage account, container and catalog are no
# longer hardcoded here. They resolve per environment from config_notebook
# (ENV_CONFIG / the 'env' widget): BASE_PATH = abfss://<container>@<account>...
catalog = CATALOG
schema  = SCHEMA

# Real ML input location (ADLS Gen2), derived from the environment:
source_path   = SOURCE_PATH
source_format = "delta"   # change to "parquet" or "csv" if ML_INPUT is not Delta
print(f"[load] env={ENV}  source={source_path}  target=`{catalog}`.{schema}.prediction_ready")

# COMMAND ----------

if source_format == "csv":
    raw = (spark.read.option("header", True).option("inferSchema", True).csv(source_path))
else:
    raw = spark.read.format(source_format).load(source_path)

print(f"loaded {raw.count():,} rows, {len(raw.columns)} columns from {source_path}")
print("columns:", raw.columns)
print("months present:")
raw.selectExpr("date_format(to_date(ACCOUNTING_DATE), 'yyyy-MM') AS m").groupBy("m").count().orderBy("m").show()

# COMMAND ----------

# Option A (default): copy into a managed prediction_ready Delta table.
(raw.write.format("delta").mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"`{catalog}`.{schema}.prediction_ready"))

# Option B: skip the copy and register the ADLS data in place as an external table
# (uncomment to use instead of Option A; avoids duplicating the data):
# spark.sql(f"""
#   CREATE TABLE IF NOT EXISTS `{catalog}`.{schema}.prediction_ready
#   USING {source_format} LOCATION '{source_path}'
# """)

print("prediction_ready rows:",
      spark.table(f"`{catalog}`.{schema}.prediction_ready").count())