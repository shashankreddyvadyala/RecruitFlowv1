# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.6 — Re-route
# MAGIC
# MAGIC Iterates on QA-flagged records up to `PARAMS['max_reroute_passes']` passes.
# MAGIC Only **ML-classified** rows (`match_type = 'ml'`, `override_suggested = true`)
# MAGIC are eligible (AUDIT B7) — deterministic rule hits are never re-classified;
# MAGIC flagged rule/RAG rows escalate straight to human review.
# MAGIC
# MAGIC Each pass re-runs the LLM **classifier resolution with the QA anomalies
# MAGIC injected into the prompt** (the embeddings are unchanged, so the new signal
# MAGIC is the QA hint), then re-applies matrix lookup → use-tax → write-up → QA on
# MAGIC the flagged subset. Records still flagged after the cap → `CRITICAL`.
# MAGIC
# MAGIC Output: `STAGE['reroute']` (clean rows ∪ re-processed rows).

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql.functions import col, lit, when, array_join

max_passes = PARAMS["max_reroute_passes"]
categories = load_categories(spark)
llm        = ENDPOINTS["llm"]
label_list = ", ".join(c.replace("'", "") for c in categories)

df      = read_stage(spark, STAGE["qa"])
clean   = df.filter(~col("override_suggested"))
flagged = df.filter(col("override_suggested")).withColumn("iteration", lit(0))
print(f"[3.6] initial flagged (ML, override): {flagged.count():,}")

# COMMAND ----------

def reclassify_with_hint(frame):
    """Re-run LLM resolution with the QA anomalies as a hint, then re-derive category.

    Renames the prior `final_category` → `prev_category` so the new column from
    ai_query() does not collide with `SELECT *`. FIX 3: `prev_category` is KEPT
    so downstream can detect whether the classification actually changed and
    regenerate the write-up accordingly.
    """
    frame = (frame
             .withColumnRenamed("final_category", "prev_category")
             .withColumn("_qa_hint", array_join(col("anomalies"), ", ")))
    frame.createOrReplaceTempView("reroute_temp")
    return spark.sql(f"""
        SELECT *,
            ai_query(
                '{llm}',
                concat_ws(' ',
                    'Re-classify this AP invoice line. A prior automated pass was flagged by QA.',
                    'QA anomalies:', COALESCE(_qa_hint, 'none'),
                    '. Description:', COALESCE(final_description, ''),
                    '. Vendor:', COALESCE(vendor_name, ''),
                    '. Previous category:', COALESCE(prev_category, 'n/a'),
                    '. Choose the single best label from:', '{label_list}'
                )
            ) AS final_category
        FROM reroute_temp
    """).drop("_qa_hint")


def matrix_join(frame):
    frame = frame.drop("taxability", "tax_source")
    matrix = (spark.read.table(TABLES["taxability_matrix"])
                   .select(col("cluster").alias("_c"), col("state").alias("_s"),
                           col("taxability")))
    return (frame.join(F.broadcast(matrix),
                       (col("final_category") == col("_c")) & (col("state") == col("_s")), "left")
                 .drop("_c", "_s")
                 .withColumn("tax_source",
                             when(col("taxability").isNotNull(), lit("matrix"))
                             .otherwise(lit("no_match"))))


def use_tax(frame):
    return frame.withColumn(
        "Reverse_UseTax",
        when((col("use_tax_amount") > 0) & (col("taxability") == "Exempt"),  lit("Yes"))
        .when((col("use_tax_amount") > 0) & (col("taxability") == "Taxable"), lit("No"))
        .when(col("use_tax_amount") == 0, lit("No"))
        .otherwise(lit(None).cast("string")))

# COMMAND ----------

def regenerate_writeup(frame):
    """FIX 3 (review comment): after re-classification, the write-up produced by
    Task 3.4 describes the OLD category/taxability and must be regenerated when
    the classification changed. Uses the SAME generation logic as Task 3.4 via
    the shared `writeup_case_sql` helper in config_notebook, so the two paths
    cannot drift. Rows whose category did NOT change keep their original
    write-up untouched (same category + state -> same matrix row -> same
    taxability -> the original write-up is still accurate).
    """
    changed   = frame.filter(~col("final_category").eqNullSafe(col("prev_category")))
    unchanged = frame.filter(col("final_category").eqNullSafe(col("prev_category")))
    n_changed = changed.count()
    print(f"[3.6] classification changed for {n_changed:,} rerouted rows -> regenerating write-ups")

    if n_changed == 0:
        return frame.withColumn("classification_changed", lit(False)) \
                    .withColumn("writeup_regenerated",  lit(False))

    # The shared CASE expects `retrieved_writeups`; in templated mode it is
    # unused (same behaviour as Task 3.4's templated path).
    regen = changed.drop("full_writeup", "short_justification",
                         "reviewer_note", "audit_ready")
    if "retrieved_writeups" not in regen.columns:
        regen = regen.withColumn("retrieved_writeups", lit("").cast("string"))

    regen.createOrReplaceTempView("reroute_writer_temp")
    regen = spark.sql(f"""
        SELECT *, {writeup_case_sql(llm, GENERATE_LLM_WRITEUPS)} AS full_writeup
        FROM reroute_writer_temp
    """)
    regen = (regen
             .withColumn("short_justification",
                         when(col("full_writeup").isNotNull(),
                              col("full_writeup").substr(1, 280))
                         .otherwise(lit(None).cast("string")))
             .withColumn("reviewer_note",
                         when(col("taxability").isNull(),
                              lit("PENDING: no taxability match after re-route — awaiting human review"))
                         .otherwise(lit(None).cast("string")))
             .withColumn("audit_ready",
                         col("taxability").isNotNull() & col("full_writeup").isNotNull())
             .withColumn("classification_changed", lit(True))
             .withColumn("writeup_regenerated",  lit(True))
             .drop("retrieved_writeups"))

    unchanged = unchanged.withColumn("classification_changed", lit(False)) \
                         .withColumn("writeup_regenerated",  lit(False))
    return unchanged.unionByName(regen, allowMissingColumns=True)

# COMMAND ----------

for p in range(1, max_passes + 1):
    n = flagged.count()
    if n == 0:
        break
    print(f"[3.6] pass {p}/{max_passes} on {n:,} flagged ML records...")

    # Re-classify (with QA hint) → matrix → use-tax → regenerate write-up (FIX 3).
    re = reclassify_with_hint(flagged)
    re = matrix_join(re)
    re = use_tax(re)
    re = regenerate_writeup(re)
    re = re.drop("prev_category")
    re = re.withColumn("iteration", lit(p)) \
           .withColumn("override_suggested", lit(False))  # re-QA in 3.5 on next full run

    # FIX 3 guard: no re-classified row may leave 3.6 with a write-up that was
    # not regenerated, or with a known taxability but no write-up.
    _stale = re.filter(col("classification_changed") &
                       (~col("writeup_regenerated") |
                        (col("taxability").isNotNull() & col("full_writeup").isNull()))).count()
    assert _stale == 0, f"[3.6] {_stale} re-classified row(s) would carry a stale write-up"

    clean   = clean.unionByName(re, allowMissingColumns=True)
    flagged = flagged.limit(0)   # single resolution pass per record; loop guard

# Anything still flagged after the cap → CRITICAL escalation.
if flagged.count() > 0:
    clean = clean.unionByName(
        flagged.withColumn("review_priority", lit("CRITICAL")), allowMissingColumns=True)

write_stage(clean, STAGE["reroute"])
print(f"[3.6] re-route complete: {clean.count():,} rows")
dbutils.notebook.exit("3.6 OK")