# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.6 — Re-route
# MAGIC
# MAGIC Iterates on QA-flagged records up to `PARAMS['max_reroute_passes']` passes.
# MAGIC Only **ML-classified** rows (`match_type = 'ml'`, `override_suggested = true`)
# MAGIC are eligible (AUDIT B7) — deterministic rule hits are never re-classified;
# MAGIC flagged rule/RAG rows escalate straight to human review.
# MAGIC
# MAGIC Each pass re-runs the LLM **classifier resolution with the QA anomalies
# MAGIC injected into the prompt** (the embeddings are unchanged, so the new signal
# MAGIC is the QA hint), then re-applies matrix lookup → use-tax → write-up → QA on
# MAGIC the flagged subset. Records still flagged after the cap → `CRITICAL`.
# MAGIC
# MAGIC Output: `STAGE['reroute']` (clean rows ∪ re-processed rows).

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql.functions import col, lit, when, array_join

max_passes = PARAMS["max_reroute_passes"]
categories = load_categories(spark)
llm        = ENDPOINTS["llm"]
label_list = ", ".join(c.replace("'", "") for c in categories)

df      = read_stage(spark, STAGE["qa"])
clean   = df.filter(~col("override_suggested"))
flagged = df.filter(col("override_suggested")).withColumn("iteration", lit(0))
print(f"[3.6] initial flagged (ML, override): {flagged.count():,}")

# COMMAND ----------

def reclassify_with_hint(frame):
    """Re-run LLM resolution with the QA anomalies as a hint, then re-derive category.

    Renames the prior `final_category` → `prev_category` so the new column from
    ai_query() does not collide with `SELECT *`.
    """
    frame = (frame
             .withColumnRenamed("final_category", "prev_category")
             .withColumn("_qa_hint", array_join(col("anomalies"), ", ")))
    frame.createOrReplaceTempView("reroute_temp")
    return spark.sql(f"""
        SELECT *,
            ai_query(
                '{llm}',
                concat_ws(' ',
                    'Re-classify this AP invoice line. A prior automated pass was flagged by QA.',
                    'QA anomalies:', COALESCE(_qa_hint, 'none'),
                    '. Description:', COALESCE(final_description, ''),
                    '. Vendor:', COALESCE(vendor_name, ''),
                    '. Previous category:', COALESCE(prev_category, 'n/a'),
                    '. Choose the single best label from:', '{label_list}'
                )
            ) AS final_category
        FROM reroute_temp
    """).drop("_qa_hint", "prev_category")


def matrix_join(frame):
    frame = frame.drop("taxability", "tax_source")
    matrix = (spark.read.table(TABLES["taxability_matrix"])
                   .select(col("cluster").alias("_c"), col("state").alias("_s"),
                           col("taxability")))
    return (frame.join(F.broadcast(matrix),
                       (col("final_category") == col("_c")) & (col("state") == col("_s")), "left")
                 .drop("_c", "_s")
                 .withColumn("tax_source",
                             when(col("taxability").isNotNull(), lit("matrix"))
                             .otherwise(lit("no_match"))))


def use_tax(frame):
    return frame.withColumn(
        "Reverse_UseTax",
        when((col("use_tax_amount") > 0) & (col("taxability") == "Exempt"),  lit("Yes"))
        .when((col("use_tax_amount") > 0) & (col("taxability") == "Taxable"), lit("No"))
        .when(col("use_tax_amount") == 0, lit("No"))
        .otherwise(lit(None).cast("string")))

# COMMAND ----------

for p in range(1, max_passes + 1):
    n = flagged.count()
    if n == 0:
        break
    print(f"[3.6] pass {p}/{max_passes} on {n:,} flagged ML records...")

    # Re-classify (with QA hint) → matrix → use-tax.
    re = reclassify_with_hint(flagged)
    re = matrix_join(re)
    re = use_tax(re)
    re = re.withColumn("iteration", lit(p)) \
           .withColumn("override_suggested", lit(False))  # re-QA in 3.5 on next full run

    clean   = clean.unionByName(re, allowMissingColumns=True)
    flagged = flagged.limit(0)   # single resolution pass per record; loop guard

# Anything still flagged after the cap → CRITICAL escalation.
if flagged.count() > 0:
    clean = clean.unionByName(
        flagged.withColumn("review_priority", lit("CRITICAL")), allowMissingColumns=True)

write_stage(clean, STAGE["reroute"])
print(f"[3.6] re-route complete: {clean.count():,} rows")
dbutils.notebook.exit("3.6 OK")