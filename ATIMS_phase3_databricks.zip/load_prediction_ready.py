# Databricks notebook source
# MAGIC %md
# MAGIC # Load sample input -> prediction_ready
# MAGIC
# MAGIC One-off loader: ingest the Phase 1/2 export CSV into the Delta table that
# MAGIC Task 3.1 reads. Phase 3 normalizes the schema automatically (see
# MAGIC `normalize_input` in config_notebook), so you can keep the raw column names
# MAGIC (MIC, TRAN_AMOUNT, INVOICE_AMOUNT, ...) — they are mapped to mic_cln / amount
# MAGIC at read time.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Upload the CSV to a UC Volume, e.g.
# MAGIC    `/Volumes/31500_atims_dev/atims_taxability/landing/`
# MAGIC 2. Set `csv_path` below to that location and run.
# MAGIC 3. In every Task notebook, set the **month** widget to match the data
# MAGIC    (this sample is **2023-01**), or Task 3.1 will match zero rows.

# COMMAND ----------

catalog = "31500_atims_dev"
schema  = "atims_taxability"
csv_path = f"/Volumes/{catalog}/{schema}/landing/New_Notebook_2026_04_15_09_29_46.csv"

raw = (spark.read
            .option("header", True)
            .option("inferSchema", True)
            .csv(csv_path))

print(f"loaded {raw.count():,} rows, {len(raw.columns)} columns")
print("months present:")
raw.selectExpr("date_format(to_date(ACCOUNTING_DATE), 'yyyy-MM') AS m").groupBy("m").count().show()

# COMMAND ----------

(raw.write.format("delta").mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"`{catalog}`.{schema}.prediction_ready"))

print("prediction_ready written:",
      spark.table(f"`{catalog}`.{schema}.prediction_ready").count(), "rows")
