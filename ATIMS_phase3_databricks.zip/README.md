# Phase 3 — Databricks notebooks (.ipynb)

Import these into a Databricks workspace (keep them in one folder so
`%run ./config_notebook` resolves). Markdown renders natively; the
`ai_classify` / `ai_query` SQL functions and Vector Search run on a cluster.

## Run order

1. **`create_reference_tables`** — run **once** (and whenever rules/thresholds
   change). Creates two governed Delta tables so the pipeline is data-driven, not
   hard-coded:
   - `classification_rules` — full rules engine (exact-match, account-range,
     vendor, keyword) with `priority` (lowest wins) + effective-date windows.
   - `pipeline_config` — thresholds (agreement, RAG floor, re-route passes, …).
2. The monthly job (chained tasks, see `workflow.json`):
   `rules_expert → classifier → tax_lookup → use_tax_lookup → tax_writer → qa → reroute → write_output`

Create the job from `workflow.json` (Jobs UI → *Create from JSON*, or
`databricks jobs create --json @workflow.json`).

## Editing rules without code

`classification_rules` is a normal Delta table — `INSERT`/`UPDATE`/toggle
`active` to change classifications. `rules_expert` evaluates all active,
in-window rules across four `rule_type`s and the lowest `priority` wins per line;
unmatched lines fall through to Vector Search RAG, then the ML classifier.

## Prerequisites

- `prediction_ready` carries the 1024-dim `gte_embedding` column (Phase 2).
- Serving endpoints `xgboost-non-norad`, `databricks-gte-large-en`, `databricks-gpt-4o`.
- Vector Search endpoint + `rules_kb_index` / `tax_writeups_index`.
- Reference tables in `atims_shared.reference` (taxability_matrix, tax_writeups,
  category_definitions, state_service_tax_rules, historical_stats) and
  `atims_shared.models.xgboost_non_norad_label_index`.
- Secret scope `atims` with key `phase3_webhook_url` (Task 3.7 notify).
