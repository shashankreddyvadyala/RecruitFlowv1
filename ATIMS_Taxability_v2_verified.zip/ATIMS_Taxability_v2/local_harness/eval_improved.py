"""Non-circular evaluation + feature ablation.

Circularity problem: the model's text is description + vendor.
  * keyword rules label from a substring of the DESCRIPTION  -> circular
  * vendor rules and most expression rules label from VENDOR  -> circular
  * exact_match rules label from ACCOUNT_CODE / EXTC / MIC    -> NOT in the text
So exact_match-labelled rows are the only clean generalisation test available
without human ground truth.

Ablation: does adding the structured codes (account_code, extc, mic,
company_code) as features improve the model, or is description text enough?
Those codes are what the high-precision rules key on, so they carry signal the
description does not.
"""
import re, sys, json
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.preprocessing import FunctionTransformer
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import accuracy_score, f1_score

sys.path.insert(0, "/home/claude/harness")
exec(open("/home/claude/harness/eval_classifier.py").read().split("kw_map =")[0])  # reuse rule replay

matched["codes"] = (
    "acct_" + data.ACCOUNT_CODE.fillna("na") + " " +
    "extc_" + data.EXTC.fillna("na") + " " +
    "mic_"  + data.MIC.fillna("na") + " " +
    "cc_"   + data.COMPANY_CODE.fillna("na") + " " +
    "st_"   + data.STATE.fillna("na")
).loc[matched.index]
matched["combo"] = matched.text + " " + matched.codes

def word_tfidf():
    return TfidfVectorizer(sublinear_tf=True, min_df=2, ngram_range=(1, 2), max_features=60000)

def make(kind):
    if kind == "logreg":
        return LogisticRegression(max_iter=2000, C=4.0, class_weight="balanced")
    if kind == "svm":
        return CalibratedClassifierCV(LinearSVC(C=0.5, class_weight="balanced"), cv=3)
    raise ValueError(kind)

def cv_score(X, y, kind="logreg", folds=5):
    vc = y.value_counts()
    keep = y.map(vc) >= folds
    X, y = X[keep], y[keep]
    if y.nunique() < 2 or len(y) < 50:
        return None, None, len(y)
    pipe = Pipeline([("tf", word_tfidf()), ("clf", make(kind))])
    skf = StratifiedKFold(n_splits=folds, shuffle=True, random_state=0)
    pred = cross_val_predict(pipe, X, y, cv=skf, n_jobs=1)
    return accuracy_score(y, pred), f1_score(y, pred, average="macro", zero_division=0), len(y)

print("\n" + "=" * 78)
print("E5  NON-CIRCULAR TEST — exact_match-labelled rows only")
print("    (labels come from account_code/extc/mic, which are NOT in the text)")
print("=" * 78)
em = matched[matched.rule_type == "exact_match"]
print(f"    rows={len(em):,}  labels={em.category.nunique()}")
for feat, col_ in [("description+vendor text only", "text"),
                   ("codes only", "codes"),
                   ("text + codes", "combo")]:
    a, f, n = cv_score(em[col_], em.category)
    if a is None:
        print(f"    {feat:32} insufficient")
    else:
        print(f"    {feat:32} n={n:5}  acc={a:.3f}  macroF1={f:.3f}")

print("\n" + "=" * 78)
print("E6  ABLATION on all rule-matched rows (5-fold CV)")
print("=" * 78)
for feat, col_ in [("text only  (current model)", "text"),
                   ("text + structured codes", "combo")]:
    for kind in ("logreg", "svm"):
        a, f, n = cv_score(matched[col_], matched.category, kind)
        print(f"    {feat:28} {kind:7} n={n:5}  acc={a:.3f}  macroF1={f:.3f}")

print("\n" + "=" * 78)
print("E7  HOW MUCH CAN THE ENSEMBLE ACTUALLY LIFT?")
print("=" * 78)
tot = len(data)
unm = data.category.isna().sum()
kw = (data.rule_type == "keyword").sum()
hp = data.rule_type.isin(["exact_match", "vendor", "expression"]).sum()
print(f"    total lines                         {tot:6,}")
print(f"    decided by HIGH-PRECISION rules     {hp:6,}  ({hp/tot*100:4.1f}%)  <- leave alone")
print(f"    decided by KEYWORD fallback rules   {kw:6,}  ({kw/tot*100:4.1f}%)  <- reviewable")
print(f"    no rule matched (ensemble today)    {unm:6,}  ({unm/tot*100:4.1f}%)")
print(f"    => ensemble scope today             {unm/tot*100:4.1f}% of lines")
print(f"    => ensemble scope if it also audits keyword tier "
      f"{(unm+kw)/tot*100:4.1f}% of lines")

print("\n    keyword-tier concentration (the risk):")
top = data[data.rule_type == "keyword"].rule_id.value_counts().head(5)
for rid, n in top.items():
    print(f"      {rid}  {n:5,} lines  ({n/tot*100:4.1f}% of file)")

json.dump({"note": "see stdout"}, open("/tmp/eval_improved.json", "w"))
