"""Measure what the local classifier actually knows.

The model is trained on rule-matched rows. For KEYWORD rules the label is a
direct function of a token that is still present in the training text -- KW-006
labels every description containing "cable" as Distribution Equipment, so the
model can score ~99% by learning "cable -> Distribution Equipment". That is
re-deriving the rule, not classifying spend.

Four evaluations, increasingly honest:

  E1 BASELINE      train/test on all rule-matched rows, text untouched.
  E2 MASKED        same, but the matched keyword is REMOVED from the test text.
                   A model that generalises barely moves; a lookup table falls over.
  E3 HIGH-PRECISION train and test ONLY on rows labelled by exact_match / vendor /
                   expression rules (Parker-Volpe + Generic tiers). These labels
                   do not come from a substring of the description, so accuracy
                   here is a real generalisation number.
  E4 CROSS-SOURCE  train on high-precision rows only, test on keyword-labelled
                   rows. Measures whether the two rule families even agree.
"""
import re, sys, json
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score

sys.path.insert(0, "/home/claude/harness")
from rules_loader import load_rules

CSV = "/mnt/user-data/uploads/New_Notebook_2026_08_31_09_05_22.csv"
RULES = "/mnt/user-data/outputs/ATIMS_Taxability_v2/classification_rules.sql"

df = pd.read_csv(CSV, dtype=str, keep_default_na=False)
for c in df.columns:
    df[c] = df[c].replace({"null": None, "": None})
rules = [r for r in load_rules(RULES) if r["active"]]

# ---- replicate Task 3.1 rule matching (priority order, lowest wins) ---------
desc = df.FINAL_DESCRIPTION.fillna("").str.lower()
vend = df.VENDOR_NAME.fillna("")
acct = df.ACCOUNT_CODE.fillna("")
extc = df.EXTC.fillna("")

best = [None] * len(df)          # (priority, rule_id, rule_type, category)
def offer(mask, r):
    pr, rid, rt, cat = r["priority"], r["rule_id"], r["rule_type"], r["category"]
    for i in np.flatnonzero(mask.values if hasattr(mask, "values") else mask):
        cur = best[i]
        if cur is None or (pr, rid) < (cur[0], cur[1]):
            best[i] = (pr, rid, rt, cat)

for r in rules:
    t = r["rule_type"]
    if t == "keyword" and r["keyword"]:
        offer(desc.str.contains(re.escape(r["keyword"].lower()), regex=True), r)
    elif t == "vendor" and r["vendor_name"]:
        offer(vend.str.upper() == r["vendor_name"].upper(), r)
    elif t == "exact_match":
        m = pd.Series(True, index=df.index)
        if r["account_code"]: m &= (acct == r["account_code"])
        if r["extc"]:        m &= (extc == r["extc"])
        if r["mic_cln"]:     m &= (df.MIC.fillna("") == r["mic_cln"])
        if not (r["account_code"] or r["extc"] or r["mic_cln"]): continue
        offer(m, r)
    elif t == "expression" and r["match_expression"]:
        e = r["match_expression"]
        m = pd.Series(True, index=df.index)
        ok = True
        for col_, op, val in re.findall(
                r"(\w+)\s*(=|LIKE)\s*'([^']*)'", e):
            series = {"final_description": desc, "vendor_name": vend,
                      "account_code": acct, "extc": extc,
                      "mic": df.MIC.fillna(""), "mic_cln": df.MIC.fillna(""),
                      "company_code": df.COMPANY_CODE.fillna("")}.get(col_)
            if series is None: ok = False; break
            if op == "=":
                m &= (series.str.lower() == val.lower()) if col_ == "final_description" else (series == val)
            else:
                pat = re.escape(val).replace("%", ".*").replace("_", ".")
                m &= series.str.lower().str.match("^" + pat.lower() + "$", na=False)
        if ok and " OR " not in e.upper():
            offer(m, r)

lab = pd.DataFrame([b if b else (None,)*4 for b in best],
                   columns=["priority", "rule_id", "rule_type", "category"])
data = pd.concat([df.reset_index(drop=True), lab], axis=1)
data["text"] = (data.FINAL_DESCRIPTION.fillna("") + " " + data.VENDOR_NAME.fillna("")).str.lower()
matched = data[data.category.notna()].copy()
print(f"rows={len(data):,}  rule-matched={len(matched):,} "
      f"({len(matched)/len(data)*100:.1f}%)  distinct labels={matched.category.nunique()}")
print("label source:\n" + matched.rule_type.value_counts().to_string())

kw_map = {r["rule_id"]: (r["keyword"] or "").lower() for r in rules if r["rule_type"] == "keyword"}

def build(): return make_pipeline(
    TfidfVectorizer(sublinear_tf=True, min_df=2, ngram_range=(1, 2), max_features=60000),
    LogisticRegression(max_iter=1000, C=4.0, class_weight="balanced"))

def run(name, tr_X, tr_y, te_X, te_y):
    keep = tr_y.value_counts()[lambda s: s >= 2].index
    m = tr_y.isin(keep)
    if m.sum() < 50 or tr_y[m].nunique() < 2:
        print(f"{name:38} insufficient data"); return None
    clf = build().fit(tr_X[m], tr_y[m])
    p = clf.predict(te_X)
    a = accuracy_score(te_y, p)
    f = f1_score(te_y, p, average="macro", zero_division=0)
    print(f"{name:38} n_train={m.sum():5}  n_test={len(te_y):5}  acc={a:.3f}  macroF1={f:.3f}")
    return a

print("\n=== E1 BASELINE — all rule-matched rows, text untouched ===")
tr, te = train_test_split(matched, test_size=0.25, random_state=0,
                          stratify=matched.category.where(
                              matched.category.map(matched.category.value_counts()) >= 2, "RARE"))
e1 = run("E1 all rules, unmasked", tr.text, tr.category, te.text, te.category)

print("\n=== E2 MASKED — matched keyword removed from TEST text ===")
def mask_row(row):
    kw = kw_map.get(row.rule_id)
    if not kw: return row.text
    return re.sub(re.escape(kw), " ", row.text)
te_masked = te.apply(mask_row, axis=1)
e2 = run("E2 all rules, keyword masked", tr.text, tr.category, te_masked, te.category)
kwonly = te.rule_type == "keyword"
if kwonly.sum():
    e2b = run("E2b keyword-labelled rows only, masked",
              tr.text, tr.category, te_masked[kwonly], te.category[kwonly])

print("\n=== E3 HIGH-PRECISION labels only (no keyword rules) ===")
hp = matched[matched.rule_type.isin(["exact_match", "vendor", "expression"])]
print(f"   high-precision rows: {len(hp):,}  labels: {hp.category.nunique()}")
vc = hp.category.value_counts()
hp2 = hp[hp.category.map(vc) >= 2]
tr2, te2 = train_test_split(hp2, test_size=0.25, random_state=0, stratify=hp2.category)
e3 = run("E3 high-precision train+test", tr2.text, tr2.category, te2.text, te2.category)

print("\n=== E4 CROSS-SOURCE — train high-precision, test on keyword-labelled ===")
kw_rows = matched[matched.rule_type == "keyword"]
shared = set(hp.category) & set(kw_rows.category)
kw_sh = kw_rows[kw_rows.category.isin(shared)]
print(f"   categories shared by both rule families: {len(shared)}")
print(f"   keyword rows in those categories: {len(kw_sh):,}")
e4 = run("E4 HP-trained -> keyword-labelled", hp.text, hp.category, kw_sh.text, kw_sh.category)

json.dump({"E1": e1, "E2": e2, "E3": e3, "E4": e4}, open("/tmp/eval_baseline.json", "w"))
print("\nInterpretation:")
print("  E1 high + E2 collapse  => the model is memorising the keyword rules.")
print("  E3 is the only number that reflects generalisation to unseen spend.")
