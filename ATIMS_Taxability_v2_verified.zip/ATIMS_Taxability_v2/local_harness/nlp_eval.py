from pyspark.sql import SparkSession, functions as F
from pyspark.sql.functions import col, lit
spark=(SparkSession.builder.master("local[2]").appName("honest")
       .config("spark.ui.enabled","false").getOrCreate())
spark.sparkContext.setLogLevel("FATAL")
import sys; sys.path.insert(0,"/home/claude/harness")
from rules_loader import load_rules
CSV="/mnt/user-data/uploads/New_Notebook_2026_08_31_09_05_22.csv"
raw=(spark.read.option("header",True).option("inferSchema",True).option("nullValue","null")
     .option("quote",'"').option("escape",'"').option("multiLine",True).csv(CSV))
raw=raw.toDF(*[c.lower() for c in raw.columns])
m=raw.filter(F.date_format(F.to_date("accounting_date"),"yyyy-MM")=="2025-05")
rules=[r for r in load_rules("/mnt/user-data/outputs/ATIMS_Taxability_v2/classification_rules.sql") if r["active"]]
kw=sorted([(r["keyword"].lower(),r["category"],r["priority"],r["rule_id"]) for r in rules
    if r["rule_type"]=="keyword" and r["keyword"]], key=lambda x:(x[2],x[3]), reverse=True)
e=F.lit(None).cast("string"); k_hit=F.lit(None).cast("string")
for k,c,p,rid in kw:
    cond=F.lower(col("final_description")).contains(k)
    e=F.when(cond,F.lit(c)).otherwise(e); k_hit=F.when(cond,F.lit(k)).otherwise(k_hit)
lab=m.withColumn("y",e).withColumn("kw",k_hit).filter(col("y").isNotNull())

txt=F.lower(F.concat_ws(" ",F.coalesce(col("final_description"),lit("")),
                        F.coalesce(col("vendor_name"),lit(""))))
# LEAKAGE-MASKED text: blank out the very keyword that produced the label
masked=F.regexp_replace(txt, F.concat(lit("(?i)"),col("kw")), lit(" "))
data=lab.select(txt.alias("_raw"), masked.alias("_msk"), col("y"))

from pyspark.ml.feature import RegexTokenizer,StopWordsRemover,HashingTF,IDF,StringIndexer
from pyspark.ml.classification import NaiveBayes,LogisticRegression
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml.functions import vector_to_array
tr,te=data.randomSplit([0.8,0.2],seed=42)
ev=MulticlassClassificationEvaluator(labelCol="_l",predictionCol="prediction",metricName="accuracy")

def run(colname,label,clf):
    tok=RegexTokenizer(inputCol=colname,outputCol="_t",pattern=r"[^a-z0-9]+",minTokenLength=2)
    stop=StopWordsRemover(inputCol="_t",outputCol="_c")
    tf=HashingTF(inputCol="_c",outputCol="_tf",numFeatures=8192)
    idf=IDF(inputCol="_tf",outputCol="_f",minDocFreq=2)
    prep=lambda d: tf.transform(stop.transform(tok.transform(d)))
    im=idf.fit(prep(tr)); trf=im.transform(prep(tr)); tef=im.transform(prep(te))
    li=StringIndexer(inputCol="y",outputCol="_l").fit(trf)
    mdl=clf.fit(li.transform(trf)); pr=mdl.transform(li.transform(tef))
    acc=ev.evaluate(pr)
    p2=pr.withColumn("a",vector_to_array(col("probability")))
    p2=p2.withColumn("top1",F.array_max("a")).withColumn(
        "top2",F.element_at(F.array_sort("a"),-2))
    p2=p2.withColumn("margin",col("top1")-col("top2"))
    s=p2.select(F.mean("top1").alias("mean_top1"),F.mean("margin").alias("mean_margin")).first()
    print(f"  {label:38} acc={acc:.3f}  mean_maxprob={s['mean_top1']:.3f}  mean_margin={s['mean_margin']:.3f}")
    return acc

print("WITH the trigger keyword present (circular — what I measured before):")
run("_raw","NaiveBayes",NaiveBayes(featuresCol="_f",labelCol="_l",modelType="multinomial"))
run("_raw","LogisticRegression",LogisticRegression(featuresCol="_f",labelCol="_l",maxIter=30,regParam=0.01))
print("\nWITH the trigger keyword MASKED (honest generalisation estimate):")
run("_msk","NaiveBayes",NaiveBayes(featuresCol="_f",labelCol="_l",modelType="multinomial"))
run("_msk","LogisticRegression",LogisticRegression(featuresCol="_f",labelCol="_l",maxIter=30,regParam=0.01))
print("\nmajority-class baseline:")
tot=te.count(); mx=te.groupBy("y").count().orderBy(F.desc("count")).first()
print(f"  always predict '{mx['y']}' -> acc={mx['count']/tot:.3f}")
spark.stop()
