"""FINAL RUN — execute the full pipeline for every month in the real ML_INPUT
export and write the actual output table out for inspection.

One Spark session, one load, then the 8-task chain per month (the stage tables
are overwritten each pass, exactly as the Databricks job would do on a monthly
schedule). Per-month outputs are collected and written to CSV.
"""
import os, sys, shutil, json
import pandas as pd

CSV = "/mnt/user-data/uploads/New_Notebook_2026_08_31_09_05_22.csv"
PROJ = "/mnt/user-data/outputs/ATIMS_Taxability_v2"
OUT = "/mnt/user-data/outputs"
NS = "atims_final"
WAREHOUSE = "/tmp/spark_wh_final"
shutil.rmtree(WAREHOUSE, ignore_errors=True)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rules_loader import load_rules, rules_schema

from pyspark.sql import SparkSession, DataFrame, functions as F

spark = (SparkSession.builder.appName("atims-final").master("local[2]")
         .config("spark.sql.warehouse.dir", WAREHOUSE)
         .config("spark.sql.shuffle.partitions", "8")
         .config("spark.ui.enabled", "false").getOrCreate())
spark.sparkContext.setLogLevel("FATAL")

from pyspark.sql.readwriter import DataFrameWriter
_of = DataFrameWriter.format
DataFrameWriter.format = lambda self, src: _of(self, "parquet" if src == "delta" else src)
DataFrame.display = lambda self, **kw: self.show(truncate=False)


class NotebookExit(Exception): pass
class _W:
    def __init__(self): self._v = {}
    def text(self, n, d="", l=""): self._v.setdefault(n, d)
    def get(self, n): return self._v.get(n, "")
    def remove(self, n): self._v.pop(n, None)
class _S:
    def get(self, s, k): raise Exception("no secret scope")
class _N:
    def exit(self, m): raise NotebookExit(m)
class _D:
    widgets = _W(); secrets = _S(); notebook = _N()


dbutils = _D()
import builtins
builtins.spark = spark; builtins.dbutils = dbutils
builtins.display = lambda df, **kw: df.show(truncate=False)

spark.sql(f"CREATE DATABASE IF NOT EXISTS {NS}")

# ---- load with the HARDENED reader (escape='"' is the critical option) -------
raw = (spark.read.option("header", True).option("inferSchema", True)
       .option("nullValue", "null").option("quote", '"').option("escape", '"')
       .option("multiLine", True).option("encoding", "UTF-8")
       .option("mode", "PERMISSIVE").option("columnNameOfCorruptRecord", "_corrupt_record")
       .csv(CSV))
if "_corrupt_record" in raw.columns:
    nb = raw.filter(F.col("_corrupt_record").isNotNull()).count()
    assert nb == 0, f"{nb} corrupt records"
    raw = raw.drop("_corrupt_record")
raw.write.mode("overwrite").saveAsTable(f"{NS}.prediction_ready")
TOTAL = spark.table(f"{NS}.prediction_ready").count()
BAD_DATE = raw.filter(F.to_date("ACCOUNTING_DATE").isNull()).count()
print(f"[load] {TOTAL:,} rows  unparseable dates={BAD_DATE}")

rules = load_rules(f"{PROJ}/classification_rules.sql")
spark.createDataFrame([tuple(r[c] for c in [f.name for f in rules_schema().fields]) for r in rules],
                      schema=rules_schema()).write.mode("overwrite").saveAsTable(f"{NS}.classification_rules")
spark.createDataFrame(
    [("agreement_high_conf", "0.80", "float"), ("rag_match_min_score", "0.75", "float"),
     ("max_reroute_passes", "2", "int"), ("vs_num_results", "1", "int"),
     ("amount_z_flag", "3.0", "float"),
     ("nlp_min_confidence", "0.35", "float"), ("nlp_min_coverage", "0.30", "float"),
     ("nlp_min_train_rows", "50", "int"), ("nlp_vocab_size", "8192", "int"),
     ("nlp_keyword_label_weight", "0.25", "float"),
     ("nlp_audit_min_margin", "0.50", "float")],
    ["config_key", "config_value", "value_type"]
).write.mode("overwrite").saveAsTable(f"{NS}.pipeline_config")

G = {"__name__": "config_notebook", "spark": spark, "dbutils": dbutils, "display": builtins.display}
exec(compile(open(f"{PROJ}/config_notebook.py").read(), "config_notebook.py", "exec"), G)
for k in ("TABLES", "STAGE", "VS_INDEXES"):
    G[k] = {a: f"{NS}.{b.split('.')[-1]}" for a, b in G[k].items()}
G["PARAMS"] = G["_load_params"](spark)

MONTHS = [r["m"] for r in raw.selectExpr(
    "date_format(to_date(ACCOUNTING_DATE),'yyyy-MM') m").distinct().orderBy("m").collect() if r["m"]]
print(f"[run] months to process: {MONTHS}")

TASKS = [("3.1 rules_expert", "rules_expert_notebook.py"),
         ("3.2 classifier", "classifier_notebook.py"),
         ("3.3 tax_lookup", "tax_lookup_notebook.py"),
         ("3.3b use_tax", "use_tax_lookup_notebook.py"),
         ("3.4 tax_writer", "tax_writer_notebook.py"),
         ("3.5 qa", "qa_notebook.py"),
         ("3.6 reroute", "reroute_notebook.py"),
         ("3.7 write_output", "write_output_notebook.py")]

frames, report = [], []
for month in MONTHS:
    G["MONTH"] = month
    statuses = []
    for label, fname in TASKS:
        g = dict(G); g["__name__"] = fname
        try:
            exec(compile(open(f"{PROJ}/{fname}").read(), fname, "exec"), g)
            statuses.append((label, "OK"))
        except NotebookExit as e:
            statuses.append((label, "OK"))
        except Exception as e:
            statuses.append((label, f"FAIL {type(e).__name__}: {str(e).splitlines()[0][:120]}"))
            break
    ok = all(s == "OK" for _, s in statuses)
    if ok:
        pdf = spark.table(f"{NS}.non_norad_predictions").toPandas()
        pdf.insert(0, "accounting_month", month)
        frames.append(pdf)
        n = len(pdf)
    else:
        n = 0
    report.append({"month": month, "all_tasks_passed": ok, "rows": n,
                   "statuses": statuses})
    print(f"[run] {month}: {'PASS 8/8' if ok else 'FAILED'}  rows={n:,}")

final = pd.concat(frames, ignore_index=True)
# arrays -> readable strings for CSV
for c in final.columns:
    if final[c].apply(lambda v: isinstance(v, (list, tuple))).any():
        final[c] = final[c].apply(lambda v: "|".join(map(str, v)) if isinstance(v, (list, tuple)) else v)

final.to_csv(f"{OUT}/atims_predictions_all_months.csv", index=False)
print(f"\n[out] wrote {len(final):,} rows x {len(final.columns)} cols -> atims_predictions_all_months.csv")
print(f"[out] input rows {TOTAL:,}  output rows {len(final):,}  delta {TOTAL-len(final):,}")

json.dump(report, open("/tmp/run_report.json", "w"), indent=2, default=str)
final.to_pickle("/tmp/final_predictions.pkl")

# rule-firing detail for the last month processed, plus overall stats
rm = spark.table(f"{NS}.t31_rules_matched").groupBy("rule_id", "final_category").count().toPandas()
rm.to_pickle("/tmp/rules_fired_lastmonth.pkl")
spark.stop()
print("[done]")
