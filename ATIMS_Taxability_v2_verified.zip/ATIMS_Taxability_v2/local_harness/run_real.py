"""Run the ATIMS notebooks against the REAL ML_INPUT export.

Loads the uploaded CSV into prediction_ready with the exact column names the
ADLS Delta source uses (UPPERCASE), so normalize_input() gets the same job it
would get in Databricks. Literal 'null' strings from the CSV export are turned
back into real NULLs.

Reference tables are DELIBERATELY not seeded with invented values -- there is no
real taxability_matrix / historical_stats / state_service_tax_rules here, and
fabricating them would produce meaningless tax answers. This run therefore shows
what the pipeline does today on real data with the reference tables absent.

Usage: python3 run_real.py [MONTH]     default MONTH = 2025-05
"""
import os, sys, shutil, traceback

MONTH = sys.argv[1] if len(sys.argv) > 1 else "2025-05"
CSV = "/mnt/user-data/uploads/New_Notebook_2026_08_31_09_05_22.csv"
PROJ = "/mnt/user-data/outputs/ATIMS_Taxability_v2"
NS = "atims_real"
WAREHOUSE = "/tmp/spark_wh_real"
shutil.rmtree(WAREHOUSE, ignore_errors=True)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rules_loader import load_rules, rules_schema

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType

spark = (SparkSession.builder.appName("atims-real").master("local[2]")
         .config("spark.sql.warehouse.dir", WAREHOUSE)
         .config("spark.sql.shuffle.partitions", "8")
         .config("spark.ui.enabled", "false").getOrCreate())
spark.sparkContext.setLogLevel("FATAL")

from pyspark.sql.readwriter import DataFrameWriter
_of = DataFrameWriter.format
DataFrameWriter.format = lambda self, src: _of(self, "parquet" if src == "delta" else src)
DataFrame.display = lambda self, **kw: self.show(truncate=False)


class NotebookExit(Exception): pass
class _W:
    def __init__(self): self._v = {}
    def text(self, n, d="", l=""): self._v.setdefault(n, d)
    def get(self, n): return self._v.get(n, "")
    def remove(self, n): self._v.pop(n, None)
class _S:
    def get(self, scope, key): raise Exception("no secret scope")
class _N:
    def exit(self, m): raise NotebookExit(m)
class _D:
    widgets = _W(); secrets = _S(); notebook = _N()


dbutils = _D()
import builtins
builtins.spark = spark; builtins.dbutils = dbutils
builtins.display = lambda df, **kw: df.show(truncate=False)

spark.sql(f"CREATE DATABASE IF NOT EXISTS {NS}")

# --- real input, UPPERCASE names, 'null' -> NULL -----------------------------
# Same hardened options as the fixed load_prediction_ready: escape='"' is the
# critical one (Spark's default escape is backslash, which corrupts any field
# containing RFC-4180 doubled quotes).
raw = (spark.read
       .option("header", True).option("inferSchema", True)
       .option("nullValue", "null")
       .option("quote", '"').option("escape", '"')
       .option("multiLine", True).option("encoding", "UTF-8")
       .option("mode", "PERMISSIVE").option("columnNameOfCorruptRecord", "_corrupt_record")
       .csv(CSV))
if "_corrupt_record" in raw.columns:
    _nb = raw.filter(F.col("_corrupt_record").isNotNull()).count()
    print(f"[real] corrupt records: {_nb}")
    raw = raw.drop("_corrupt_record")
_bad_date = raw.filter(F.to_date(F.col("ACCOUNTING_DATE")).isNull()).count()
print(f"[real] unparseable accounting_date: {_bad_date}")
print(f"[real] descriptions with stray leading quote: "
      f"{raw.filter(F.col('FINAL_DESCRIPTION').startswith(chr(34))).count()}")
for c in raw.columns:                       # inferSchema leaves 'null' text in string cols
    if dict(raw.dtypes)[c] == "string":
        raw = raw.withColumn(c, F.when(F.col(c) == "null", None).otherwise(F.col(c)))
raw.write.mode("overwrite").saveAsTable(f"{NS}.prediction_ready")
print(f"[real] loaded {spark.table(f'{NS}.prediction_ready').count():,} rows, "
      f"{len(raw.columns)} columns")
print("[real] columns:", raw.columns)
print("[real] has gte_embedding:", "gte_embedding" in [c.lower() for c in raw.columns])
print("[real] has use_tax_amount:", "use_tax_amount" in [c.lower() for c in raw.columns])

rules = load_rules(f"{PROJ}/classification_rules.sql")
spark.createDataFrame([tuple(r[c] for c in [f.name for f in rules_schema().fields]) for r in rules],
                      schema=rules_schema()).write.mode("overwrite").saveAsTable(f"{NS}.classification_rules")
spark.createDataFrame(
    [("agreement_high_conf", "0.80", "float"), ("rag_match_min_score", "0.75", "float"),
     ("max_reroute_passes", "2", "int"), ("vs_num_results", "1", "int"),
     ("amount_z_flag", "3.0", "float"),
     ("nlp_min_train_rows", "50", "int"), ("nlp_min_confidence", "0.60", "float"),
     ("nlp_vocab_size", "8192", "int"), ("nlp_min_coverage", "0.50", "float")],
    ["config_key", "config_value", "value_type"]).write.mode("overwrite").saveAsTable(f"{NS}.pipeline_config")
# taxability_matrix / historical_stats / state_service_tax_rules intentionally absent.

G = {"__name__": "config_notebook", "spark": spark, "dbutils": dbutils, "display": builtins.display}
exec(compile(open(f"{PROJ}/config_notebook.py").read(), "config_notebook.py", "exec"), G)
for k in ("TABLES", "STAGE", "VS_INDEXES"):
    G[k] = {a: f"{NS}.{b.split('.')[-1]}" for a, b in G[k].items()}
G["PARAMS"] = G["_load_params"](spark)
G["MONTH"] = MONTH
print(f"\n### REAL DATA RUN  month={MONTH}  LLM={G['LLM_AVAILABLE']}  "
      f"RAG={G['RAG_AVAILABLE']}  EMB={G['EMBEDDINGS_AVAILABLE']}  "
      f"LOCAL_NLP={G['LOCAL_NLP_CLASSIFIER']}\n")

TASKS = [("3.1 rules_expert", "rules_expert_notebook.py"),
         ("3.2 classifier", "classifier_notebook.py"),
         ("3.3 tax_lookup", "tax_lookup_notebook.py"),
         ("3.3b use_tax", "use_tax_lookup_notebook.py"),
         ("3.4 tax_writer", "tax_writer_notebook.py"),
         ("3.5 qa", "qa_notebook.py"),
         ("3.6 reroute", "reroute_notebook.py"),
         ("3.7 write_output", "write_output_notebook.py")]

results = []
for label, fname in TASKS:
    g = dict(G); g["__name__"] = fname
    print(f"\n{'='*70}\n>>> {label}\n{'='*70}")
    try:
        exec(compile(open(f"{PROJ}/{fname}").read(), fname, "exec"), g)
        results.append((label, "OK"))
    except NotebookExit as e:
        results.append((label, f"OK — {e}"))
    except Exception as e:
        print("EXC:", type(e).__name__, str(e).splitlines()[0][:300])
        results.append((label, f"FAILED — {type(e).__name__}: {str(e).splitlines()[0][:150]}"))
        break

print(f"\n\n{'#'*70}\n# REAL DATA RESULT ({MONTH})\n{'#'*70}")
for l, s in results:
    print(f"  {'PASS' if s.startswith('OK') else 'FAIL'}  {l:22} {s}")

if all(s.startswith("OK") for _, s in results):
    out = spark.table(f"{NS}.non_norad_predictions")
    print(f"\nrows: {out.count():,}  cols: {len(out.columns)}")
    print("\nmatch_type:"); out.groupBy("match_type").count().orderBy(F.desc("count")).show()
    print("top categories:")
    out.groupBy("final_category").count().orderBy(F.desc("count")).show(12, False)
    print("review_priority:"); out.groupBy("review_priority").count().show()
    print("ensemble_confidence (ML rows only):")
    out.filter(F.col("match_type")=="ml").groupBy("ensemble_confidence").count() \
       .orderBy(F.desc("count")).show()
    print("TRUSTED local-NLP calls (NLP_HIGH):")
    out.filter(F.col("ensemble_confidence")=="NLP_HIGH").select(
        "final_description","vendor_name","final_category").distinct().show(10, 68, False)
    print("categories assigned by the local model:")
    out.filter(F.col("match_type")=="ml").groupBy("final_category","ensemble_confidence") \
       .count().orderBy(F.desc("count")).show(12, False)
    print("taxability / audit_ready:"); out.groupBy("taxability", "audit_ready").count().show()
    print("Reverse_UseTax:"); out.groupBy("Reverse_UseTax").count().show()

    # --- reconciliation: did every input row for the month reach the output? ---
    pr = spark.table(f"{NS}.prediction_ready")
    src_m = pr.filter(F.date_format(F.to_date("ACCOUNTING_DATE"), "yyyy-MM") == MONTH)
    n_src = src_m.count()
    print(f"\n--- RECONCILIATION ---")
    print(f"source rows for {MONTH}      : {n_src:,}")
    print(f"output rows                  : {out.count():,}")
    print(f"delta                        : {n_src - out.count():,}")
    print(f"source distinct keys         : {src_m.select('INVOICE_ID','INV_LINE_NUMBER').distinct().count():,}")
    print(f"output distinct keys         : {out.select('invoice_id','inv_line_number').distinct().count():,}")
    print(f"source null INVOICE_ID       : {src_m.filter(F.col('INVOICE_ID').isNull()).count():,}")
    print(f"source null INV_LINE_NUMBER  : {src_m.filter(F.col('INV_LINE_NUMBER').isNull()).count():,}")
    print("NORAD_FLAG in month (pipeline does NOT filter it):")
    src_m.groupBy("NORAD_FLAG").count().show()

    print("--- which rules actually fired ---")
    rm = spark.table(f"{NS}.t31_rules_matched")
    rm.groupBy("rule_type").count().orderBy(F.desc("count")).show()
    rm.groupBy("rule_id", "final_category").count().orderBy(F.desc("count")).show(15, False)
    fired = {r["rule_id"] for r in rm.select("rule_id").distinct().collect()}
    total_active = spark.table(f"{NS}.classification_rules").filter("active = true").count()
    print(f"rules that fired: {len(fired)} of {total_active} active "
          f"({len(fired)/total_active*100:.0f}%)")

spark.stop()
