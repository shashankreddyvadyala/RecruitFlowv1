"""Parse the real classification_rules.sql INSERT ... VALUES into rows.

We test the pipeline against the ACTUAL 147 migrated rules, not toy rules, so
the expression-rule probe loop in Task 3.1 gets a realistic workout.
"""
import re
from datetime import date, datetime

COLUMNS = [
    "rule_id", "rule_type", "priority", "priority_tier", "active", "needs_review",
    "effective_from", "effective_to", "source_sheet", "source_rule", "extc",
    "mic_cln", "account_code", "account_code_from", "account_code_to", "vendor_id",
    "vendor_name", "keyword", "match_expression", "category", "confidence",
    "description", "created_by", "created_at", "updated_at",
]


def _split_rows(values_blob):
    """Yield the text inside each top-level (...) row, quote- and escape-aware."""
    rows, depth, buf, in_str = [], 0, [], False
    i = 0
    while i < len(values_blob):
        ch = values_blob[i]
        if in_str:
            if ch == "'":
                if i + 1 < len(values_blob) and values_blob[i + 1] == "'":
                    buf.append("''"); i += 2; continue
                in_str = False
            buf.append(ch)
        elif ch == "'":
            in_str = True; buf.append(ch)
        elif ch == "(":
            depth += 1
            if depth == 1:
                buf = []
            else:
                buf.append(ch)
        elif ch == ")":
            depth -= 1
            if depth == 0:
                rows.append("".join(buf))
            else:
                buf.append(ch)
        elif depth >= 1:
            buf.append(ch)
        i += 1
    return rows


def _split_fields(row_text):
    fields, buf, in_str, depth = [], [], False, 0
    i = 0
    while i < len(row_text):
        ch = row_text[i]
        if in_str:
            if ch == "'":
                if i + 1 < len(row_text) and row_text[i + 1] == "'":
                    buf.append("'"); i += 2; continue
                in_str = False; buf.append(ch)
            else:
                buf.append(ch)
        elif ch == "'":
            in_str = True; buf.append(ch)
        elif ch == "(":
            depth += 1; buf.append(ch)
        elif ch == ")":
            depth -= 1; buf.append(ch)
        elif ch == "," and depth == 0:
            fields.append("".join(buf).strip()); buf = []
        else:
            buf.append(ch)
        i += 1
    fields.append("".join(buf).strip())
    return fields


def _coerce(tok):
    t = tok.strip()
    if t.upper() == "NULL":
        return None
    if t.lower() == "true":
        return True
    if t.lower() == "false":
        return False
    if t.lower().startswith("current_timestamp"):
        return None
    if t.startswith("'") and t.endswith("'"):
        return t[1:-1]
    try:
        return float(t) if "." in t else int(t)
    except ValueError:
        return t


def load_rules(sql_path):
    sql = open(sql_path, encoding="utf-8").read()
    start = sql.index("VALUES", sql.index("INSERT INTO"))
    blob = sql[start + len("VALUES"):]
    blob = blob[: blob.index("\n\n-- precedence check")] if "-- precedence check" in blob else blob
    out = []
    for raw in _split_rows(blob):
        vals = [_coerce(f) for f in _split_fields(raw)]
        if len(vals) != len(COLUMNS):
            raise ValueError(f"expected {len(COLUMNS)} fields, got {len(vals)}: {vals[:3]}")
        rec = dict(zip(COLUMNS, vals))
        rec["priority"] = int(rec["priority"]) if rec["priority"] is not None else None
        rec["confidence"] = float(rec["confidence"]) if rec["confidence"] is not None else None
        rec["active"] = bool(rec["active"])
        out.append(rec)
    return out


def rules_schema():
    from pyspark.sql.types import (StructType, StructField, StringType, IntegerType,
                                   BooleanType, DoubleType, DateType, TimestampType)
    f = StructField
    return StructType([
        f("rule_id", StringType()), f("rule_type", StringType()), f("priority", IntegerType()),
        f("priority_tier", StringType()), f("active", BooleanType()), f("needs_review", StringType()),
        f("effective_from", DateType()), f("effective_to", DateType()),
        f("source_sheet", StringType()), f("source_rule", StringType()),
        f("extc", StringType()), f("mic_cln", StringType()), f("account_code", StringType()),
        f("account_code_from", StringType()), f("account_code_to", StringType()),
        f("vendor_id", StringType()), f("vendor_name", StringType()), f("keyword", StringType()),
        f("match_expression", StringType()), f("category", StringType()),
        f("confidence", DoubleType()), f("description", StringType()),
        f("created_by", StringType()), f("created_at", TimestampType()), f("updated_at", TimestampType()),
    ])


if __name__ == "__main__":
    import sys, collections
    rules = load_rules(sys.argv[1])
    print("parsed rules:", len(rules))
    print("by type:", dict(collections.Counter(r["rule_type"] for r in rules)))
    print("inactive:", sum(1 for r in rules if not r["active"]))
    print("needs_review:", sum(1 for r in rules if r["needs_review"]))
