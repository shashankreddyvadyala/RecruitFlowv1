"""Cell-by-cell equality check: Spark's hardened read vs Python's csv module."""
import csv, io, hashlib
from pyspark.sql import SparkSession, functions as F
CSV = "/mnt/user-data/uploads/New_Notebook_2026_08_31_09_05_22.csv"

# reference parse
with open(CSV, encoding="utf-8") as f:
    ref = list(csv.reader(f))
hdr, ref_rows = ref[0], ref[1:]
print(f"reference: {len(ref_rows):,} rows x {len(hdr)} cols")

spark = (SparkSession.builder.master("local[2]").appName("verify")
         .config("spark.ui.enabled","false").getOrCreate())
spark.sparkContext.setLogLevel("FATAL")

def read(hardened):
    r = spark.read.option("header", True).option("inferSchema", False)   # all strings
    if hardened:
        r = (r.option("quote", '"').option("escape", '"')
              .option("multiLine", True).option("encoding", "UTF-8"))
    return r.csv(CSV)

def compare(label, df):
    got = [[("" if v is None else v) for v in row] for row in df.collect()]
    # align on (INVOICE_ID, INV_LINE_NUMBER, FINAL_DESCRIPTION) position-independently
    if len(got) != len(ref_rows):
        print(f"{label}: ROW COUNT MISMATCH {len(got)} vs {len(ref_rows)}")
    mism = 0; first = None
    for i, (a, b) in enumerate(zip(got, ref_rows)):
        b = [("" if v == "null" else v) for v in b]
        a = [("" if v == "null" else v) for v in a]
        if a != b:
            mism += 1
            if first is None: first = (i, a, b)
    print(f"{label}: rows={len(got):,}  mismatched rows={mism:,}")
    if first:
        i, a, b = first
        for j,(x,y) in enumerate(zip(a,b)):
            if x != y:
                print(f"   first diff row {i} col '{hdr[j]}':")
                print(f"     spark : {x[:110]!r}")
                print(f"     python: {y[:110]!r}")
                break
    return mism

compare("DEFAULT  reader", read(False))
n = compare("HARDENED reader", read(True))
print("\nRESULT:", "EXACT MATCH — read is byte-for-byte correct" if n == 0 else f"{n} rows still differ")
spark.stop()
