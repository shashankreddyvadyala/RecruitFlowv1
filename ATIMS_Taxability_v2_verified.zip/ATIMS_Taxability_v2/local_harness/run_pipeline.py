"""Execute the real ATIMS notebooks end-to-end on local Spark.

What this proves and what it does not:

  * PROVES the no-LLM path is genuinely LLM-free. Open-source Spark has NO
    ai_query() function. If any gated branch leaked, the run would die with
    UNRESOLVED_ROUTINE_ERROR. A clean run is the proof.
  * PROVES the DataFrame logic, joins, window functions, schema unification and
    column projections actually execute and produce the expected columns.
  * SUBSTITUTES parquet for Delta (Delta JARs need Maven, which is unreachable
    here) and a local database for the Unity Catalog namespace. Neither changes
    the pipeline logic under test.
  * DOES NOT test Vector Search, Model Serving, MLflow/UC registry, ADLS or the
    webhook. Those are exercised via their documented fail-soft paths instead.

Usage:  python3 run_pipeline.py <scenario>      scenario = A | B
  A = no LLM, no XGBoost endpoint  -> expect UNRESOLVED rows -> human review
  B = no LLM, XGBoost available    -> expect XGB_ONLY rows   -> categories assigned
"""
import os, sys, shutil, random, traceback
from datetime import date

SCENARIO = (sys.argv[1] if len(sys.argv) > 1 else "A").upper()
PROJ = "/mnt/user-data/outputs/ATIMS_Taxability_v2"
NS = "atims_test"
WAREHOUSE = f"/tmp/spark_wh_{SCENARIO}"
shutil.rmtree(WAREHOUSE, ignore_errors=True)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rules_loader import load_rules, rules_schema

# --- fake mlflow for scenario B (executor-visible via PYTHONPATH, set by caller)
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (StructType, StructField, StringType, DoubleType,
                               IntegerType, BooleanType, ArrayType, DateType)

spark = (SparkSession.builder
         .appName(f"atims-harness-{SCENARIO}")
         .master("local[2]")
         .config("spark.sql.warehouse.dir", WAREHOUSE)
         .config("spark.sql.shuffle.partitions", "4")
         .config("spark.ui.enabled", "false")
         .getOrCreate())
spark.sparkContext.setLogLevel("FATAL")

# --- Delta -> parquet shim (environment substitution, not a code change) ------
from pyspark.sql.readwriter import DataFrameWriter
_orig_format = DataFrameWriter.format
DataFrameWriter.format = lambda self, src: _orig_format(self, "parquet" if src == "delta" else src)

# --- Databricks-only surfaces -------------------------------------------------
from pyspark.sql import DataFrame
DataFrame.display = lambda self, **kw: self.show(truncate=False)


class NotebookExit(Exception):
    pass


class _Widgets:
    def __init__(self): self._v = {}
    def text(self, name, default="", label=""): self._v.setdefault(name, default)
    def get(self, name): return self._v.get(name, "")
    def remove(self, name): self._v.pop(name, None)
    def removeAll(self): self._v.clear()


class _Secrets:
    def get(self, scope, key): raise Exception("no secret scope in harness")


class _Notebook:
    def exit(self, msg): raise NotebookExit(msg)
    def run(self, path, timeout, args=None): raise Exception("nested run not used")


class _DBUtils:
    widgets = _Widgets(); secrets = _Secrets(); notebook = _Notebook()


dbutils = _DBUtils()
import builtins
builtins.spark = spark
builtins.dbutils = dbutils
builtins.display = lambda df, **kw: df.show(truncate=False)

# --- seed the reference + input tables ---------------------------------------
spark.sql(f"CREATE DATABASE IF NOT EXISTS {NS}")

rules = load_rules(f"{PROJ}/classification_rules.sql")
spark.createDataFrame(
    [tuple(r[c] for c in [f.name for f in rules_schema().fields]) for r in rules],
    schema=rules_schema()).write.mode("overwrite").saveAsTable(f"{NS}.classification_rules")

spark.createDataFrame(
    [("agreement_high_conf", "0.80", "float", "", None),
     ("rag_match_min_score", "0.75", "float", "", None),
     ("max_reroute_passes", "2", "int", "", None),
     ("vs_num_results", "1", "int", "", None),
     ("amount_z_flag", "3.0", "float", "", None)],
    schema=StructType([StructField("config_key", StringType()),
                       StructField("config_value", StringType()),
                       StructField("value_type", StringType()),
                       StructField("description", StringType()),
                       StructField("updated_at", StringType())])
).write.mode("overwrite").saveAsTable(f"{NS}.pipeline_config")

STATES = ["NC", "TX", "CA", "NY", "GA"]
# Descriptions chosen to hit each rule type: keyword, exact_match account code,
# vendor name, and an expression rule.
LINES = [
    ("fiber optic cable spool", "DIVERSIFIED WIRE & CABLE INC", "6114.1", "520", "MFG"),
    ("janitor supplies restock", "ACME SUPPLY CO", "7010", "455", "SUP"),
    ("annual maintenance contract", "TEKSYSTEMS INC>9M", "6200", "520", "SVC"),
    ("armored car pickup", "BRINKS INCORPORATED", "7300", "9M", "SVC"),
    ("insulated gloves bulk", "SAF T GARD INTERNATIONAL INC", "6114.1", "9B", "SUP"),
    ("unclassifiable widget xyzzy", "UNKNOWN VENDOR LLC", "9999", "77", "MSC"),
    ("propane tank refill", "HIGHTOWERS PETROLEUM CO", "6150", "12", "MAT"),
    ("professional consulting hours", "THE MORNING CONSULT LLC", "6400", "9I", "SVC"),
    ("gpon optical network unit", "KGPCO SERVICES LLC", "6118", "450", "MFG"),
    ("mystery line item no keywords", "ZZ HOLDINGS", "8888", "66", "MSC"),
]
random.seed(7)
rows = []
for i in range(40):
    desc, vend, acct, extc, mic = LINES[i % len(LINES)]
    rows.append((
        f"INV{1000+i//2}", i % 2 + 1, desc, vend, STATES[i % len(STATES)],
        date(2026, 5, (i % 27) + 1), extc, mic, acct,
        float(random.choice([120.0, 4500.0, 88.5, 250000.0])),
        float(random.choice([0.0, 0.0, 15.75])),
        [random.random() for _ in range(1024)],
    ))
pr_schema = StructType([
    StructField("INVOICE_ID", StringType()), StructField("INV_LINE_NUMBER", IntegerType()),
    StructField("FINAL_DESCRIPTION", StringType()), StructField("VENDOR_NAME", StringType()),
    StructField("STATE", StringType()), StructField("ACCOUNTING_DATE", DateType()),
    StructField("EXTC", StringType()), StructField("MIC", StringType()),
    StructField("ACCOUNT_CODE", StringType()), StructField("TRAN_AMOUNT", DoubleType()),
    StructField("USE_TAX_AMOUNT", DoubleType()),
    StructField("GTE_EMBEDDING", ArrayType(DoubleType())),
])
spark.createDataFrame(rows, schema=pr_schema) \
     .write.mode("overwrite").saveAsTable(f"{NS}.prediction_ready")

# taxability_matrix: state-keyed, deliberately mixed value encodings (1/0/Y/N)
spark.createDataFrame(
    [("NC", "1"), ("TX", "0"), ("CA", "Y"), ("NY", "no")],   # GA missing on purpose
    ["state", "taxable"]).write.mode("overwrite").saveAsTable(f"{NS}.taxability_matrix")

spark.createDataFrame([("Repair Services", "NC"), ("Permits", "TX")],
                      ["final_category", "state"]) \
     .write.mode("overwrite").saveAsTable(f"{NS}.historical_stats")

spark.createDataFrame([("NC", True), ("TX", False), ("CA", True), ("NY", True), ("GA", False)],
                      ["state", "service_taxable"]) \
     .write.mode("overwrite").saveAsTable(f"{NS}.state_service_tax_rules")

if SCENARIO == "B":
    cats = sorted({r["category"] for r in rules if r["category"]})
    spark.createDataFrame([(c,) for c in cats], ["cluster"]) \
         .write.mode("overwrite").saveAsTable(f"{NS}.category_definitions")
# Scenario A omits category_definitions on purpose -> exercises the fallback to
# distinct categories in classification_rules.

# --- exec config_notebook, then relocate the namespace ------------------------
G = {"__name__": "config_notebook", "spark": spark, "dbutils": dbutils,
     "display": builtins.display}
exec(compile(open(f"{PROJ}/config_notebook.py").read(), "config_notebook.py", "exec"), G)

G["TABLES"] = {k: f"{NS}.{v.split('.')[-1]}" for k, v in G["TABLES"].items()}
G["STAGE"] = {k: f"{NS}.{v.split('.')[-1]}" for k, v in G["STAGE"].items()}
G["VS_INDEXES"] = {k: f"{NS}.{v.split('.')[-1]}" for k, v in G["VS_INDEXES"].items()}
G["PARAMS"] = G["_load_params"](spark)
G["MONTH"] = "2026-05"

print(f"\n### scenario {SCENARIO}: LLM_AVAILABLE={G['LLM_AVAILABLE']}  "
      f"LLM_WRITEUPS_ON={G['LLM_WRITEUPS_ON']}  "
      f"xgboost={'fake-available' if SCENARIO == 'B' else 'unavailable'}\n")

TASKS = [
    ("3.1 rules_expert", "rules_expert_notebook.py"),
    ("3.2 classifier", "classifier_notebook.py"),
    ("3.3 tax_lookup", "tax_lookup_notebook.py"),
    ("3.3b use_tax", "use_tax_lookup_notebook.py"),
    ("3.4 tax_writer", "tax_writer_notebook.py"),
    ("3.5 qa", "qa_notebook.py"),
    ("3.6 reroute", "reroute_notebook.py"),
    ("3.7 write_output", "write_output_notebook.py"),
]

results = []
for label, fname in TASKS:
    g = dict(G)
    g["__name__"] = fname
    print(f"\n{'='*70}\n>>> {label}\n{'='*70}")
    try:
        exec(compile(open(f"{PROJ}/{fname}").read(), fname, "exec"), g)
        results.append((label, "OK (no exit call)"))
    except NotebookExit as e:
        results.append((label, f"OK — {e}"))
    except Exception as e:
        print("EXC:", type(e).__name__, str(e).splitlines()[0][:200])
        results.append((label, f"FAILED — {type(e).__name__}: {e}"))
        break

print(f"\n\n{'#'*70}\n# SCENARIO {SCENARIO} RESULT\n{'#'*70}")
for label, status in results:
    print(f"  {'PASS' if status.startswith('OK') else 'FAIL'}  {label:22} {status}")

if all(s.startswith("OK") for _, s in results):
    out = spark.table(f"{NS}.non_norad_predictions")
    print(f"\nfinal output rows: {out.count()}   columns: {len(out.columns)}")
    print("\nmatch_type x ensemble_confidence:")
    out.groupBy("match_type", "ensemble_confidence").count().orderBy("match_type").show(50, False)
    print("review_priority:")
    out.groupBy("review_priority").count().show()
    print("taxability / audit_ready:")
    out.groupBy("taxability", "audit_ready").count().show()
    print("sample write-ups:")
    out.select("final_category", "state", "taxability", "short_justification") \
       .filter(F.col("short_justification").isNotNull()).show(3, False)

spark.stop()
