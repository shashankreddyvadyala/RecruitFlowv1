"""Stand-in for a live Databricks Model Serving endpoint (scenario B only).

Deterministically maps an embedding to one of a few categories so Task 3.2's
XGBoost-only path can be exercised without a real serving endpoint.
"""
CATS = ["Repair Services", "Maintenance Services", "Miscellaneous Materials",
        "Safety Equipment", "Professional Service"]


class _Client:
    def predict(self, endpoint, inputs):
        vecs = inputs["inputs"]
        out = []
        for v in vecs:
            i = int(abs(sum(v[:8])) * 1000) % len(CATS)
            conf = 0.55 + (i / len(CATS)) * 0.4        # spans the 0.80 threshold
            out.append({"category": CATS[i], "confidence": round(conf, 3)})
        return {"predictions": out}


def get_deploy_client(target):
    return _Client()
