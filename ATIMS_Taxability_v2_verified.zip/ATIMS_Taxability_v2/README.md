# Phase 3 — Databricks notebooks (.ipynb)

Import these into a Databricks workspace (keep them in one folder so
`%run ./config_notebook` resolves). Markdown renders natively; the
`ai_classify` / `ai_query` SQL functions and Vector Search run on a cluster.

## Run order

1. **`create_reference_tables`** — run **once** (and whenever rules/thresholds
   change). Creates two governed Delta tables so the pipeline is data-driven, not
   hard-coded:
   - `classification_rules` — full rules engine (exact-match, account-range,
     vendor, keyword) with `priority` (lowest wins) + effective-date windows.
   - `pipeline_config` — thresholds (agreement, RAG floor, re-route passes, …).
2. The monthly job (chained tasks, see `workflow.json`):
   `rules_expert → classifier → tax_lookup → use_tax_lookup → tax_writer → qa → reroute → write_output`

Create the job from `workflow.json` (Jobs UI → *Create from JSON*, or
`databricks jobs create --json @workflow.json`).

## External dependencies — all OFF by default

`config_notebook` has three independent switches. All default `False`, so the
pipeline runs fully self-contained: no serving endpoints, no vector indexes, no
embeddings, no network calls. Flip each one as access becomes available.

```python
LLM_AVAILABLE        = False   # ai_query() / LLM serving endpoint
RAG_AVAILABLE        = False   # Databricks Vector Search
EMBEDDINGS_AVAILABLE = False   # gte_embedding column + xgboost endpoint
LOCAL_NLP_CLASSIFIER = True    # in-cluster TF-IDF model (no dependencies)
```

| Task | External path | Behaviour when OFF |
|---|---|---|
| 3.1 rules_expert | Vector Search RAG | pass skipped entirely; non-rule rows go straight to 3.2 |
| 3.2 classifier | sub-model A (XGBoost on embeddings) | skipped; no scoring pass run |
| 3.2 classifier | sub-model B (LLM zero-shot) | skipped; local NLP model becomes the decider |
| 3.2 classifier | disagreement arbitration | resolved locally by confidence → `RESOLVE_LOCAL` |
| 3.4 tax_writer | RAG-grounded audit write-up | templated justification |
| 3.6 reroute | re-classify with QA hint | no re-classification; flagged rows → `CRITICAL` |

All four flags are logged as MLflow params in Task 3.8, so runs at different
capability levels stay distinguishable in the experiment history.

## Local NLP classifier (sub-model C)

With the external models off, Task 3.2 would otherwise assign nothing. Sub-model C
fills that gap using only Spark MLlib:

**TF-IDF (CountVectorizer + IDF) → multinomial logistic regression**, retrained
every run on that month's rule-matched rows — the governed rules table is the
weak-supervision label source.

Two numbers decide whether a prediction is trusted:

- **`nlp_conf`** — the top1−top2 probability *margin*, not max probability. Max
  probability saturates near 1.0 on nearly every row and cannot separate good
  calls from bad ones.
- **`nlp_coverage`** — the share of the row's tokens the model saw in training.
  This is the important one. The labels come from the rules, so the model only
  knows rule-shaped spend, while the rows it must classify are exactly those no
  rule matched — often a different kind of spend whose correct category may not
  exist in the label set at all. Low coverage means the prediction is an
  extrapolation.

A row is `NLP_HIGH` only when **both** clear their floors; otherwise `NLP_LOW`,
which routes to the `COMPLEX` path for review. On 2025-05 that split 368 rows
into 107 trusted and 261 held for review.

**Caveat worth knowing:** a holdout on the rule-matched rows scores ~0.99, but
that number is circular — the label is derived from a keyword that is present in
the text. Treat the local model as a *suggestion engine for reviewers*, not an
authority. It cannot invent categories the rules never produce.

## Reading the source data (IMPORTANT)

Spark's **default CSV `escape` character is a backslash**, not the RFC-4180
doubled quote. AP descriptions contain embedded quotes such as
`Construction Services ""Non-Exclusivity""`. With the default escape the parser
loses quote state mid-record and shifts every subsequent column — silently, with
no error. On the real export that corrupted **65 rows** and pushed **23
accounting_dates** into unparseable values, which then disappeared from *every*
monthly run.

`load_prediction_ready` now reads with `escape='"'`, `quote='"'`, `multiLine`,
explicit UTF-8, and `PERMISSIVE` + `_corrupt_record`, and it **refuses to write
prediction_ready** if any row fails to parse. It also validates required columns
and warns about unparseable accounting_dates.

Verified with `local_harness/verify_read.py`, which compares Spark's parse
against Python's `csv` module cell by cell:

| reader | rows | mismatched rows |
|---|---|---|
| default | 7,071 | **65** |
| hardened | 7,071 | **0 (exact match)** |

Note: 2 rows carry a U+FFFD replacement character (invoice 10155480, 10173523) —
that is pre-existing corruption in the source, not a read problem.

## Real input data — known gaps

Verified against the ML_INPUT export (7,071 rows; accounting months 2025-04 → 2025-07).
`MONTH` is now set to `2025-05`. Blockers found in that feed:

| Gap | Effect today |
|---|---|
| No `gte_embedding` column | Task 3.2 sub-model A cannot run — XGBoost is impossible until Phase 2 adds embeddings |
| No `use_tax_amount` column | `Reverse_UseTax` is NULL for 100% of rows (the deferred-NULL open question) |
| `TAX_AMOUNT` / `TAX_TYPE` 100% NULL | no tax signal available from the feed at all |
| `taxability_matrix` not populated | `taxability` NULL for 100% of rows → everything routes to HIGH review |
| `NORAD_FLAG = Y` rows not filtered | 246 NORAD rows in 2025-05 flow into `non_norad_predictions` |
| Rule/feed key mismatch | rules key on `extc` in {9B, 9I, 9L, 9M, 1, 69A}; feed uses {241, 416, 450, 455...}. Rule `mic_cln` {CEQ, SW} vs feed MIC {2FB000025N...} — zero overlap |

Rule coverage on 2025-05: 4,723 of 5,091 lines matched (92.8%), but by only
**36 of 142 active rules** — one keyword rule (`cable`) accounts for 2,312 lines.

## Editing rules without code

`classification_rules` is a normal Delta table — `INSERT`/`UPDATE`/toggle
`active` to change classifications. `rules_expert` evaluates all active,
in-window rules across four `rule_type`s and the lowest `priority` wins per line;
unmatched lines fall through to Vector Search RAG, then the ML classifier.

## Prerequisites

- `prediction_ready` carries the 1024-dim `gte_embedding` column (Phase 2).
- Serving endpoints `xgboost-non-norad`, `databricks-gte-large-en`, `databricks-gpt-4o`.
- Vector Search endpoint + `rules_kb_index` / `tax_writeups_index`.
- Reference tables in `atims_shared.reference` (taxability_matrix, tax_writeups,
  category_definitions, state_service_tax_rules, historical_stats) and
  `atims_shared.models.xgboost_non_norad_label_index`.
- Secret scope `atims` with key `phase3_webhook_url` (Task 3.7 notify).
