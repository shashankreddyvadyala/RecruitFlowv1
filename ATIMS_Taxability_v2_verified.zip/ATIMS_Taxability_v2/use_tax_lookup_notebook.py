# Databricks notebook source
# MAGIC %md
# MAGIC # TASK 3.3b — Use Tax Lookup
# MAGIC
# MAGIC Pure conditional logic (`withColumn`). Determines whether a use-tax reversal
# MAGIC applies, based solely on `use_tax_amount` + `taxability`.
# MAGIC
# MAGIC | use_tax_amount | taxability | Reverse_UseTax |
# MAGIC |---|---|---|
# MAGIC | > 0 | Exempt  | `Yes` (reversal required) |
# MAGIC | > 0 | Taxable | `No` |
# MAGIC | = 0 | any     | `No` |
# MAGIC | NULL | any    | `null` — **DEFERRED**, pending client clarification |
# MAGIC | any | NULL    | `null` — taxability unresolved, cannot determine |
# MAGIC
# MAGIC **OPEN QUESTION (carried forward):** confirm NULL `use_tax_amount` handling
# MAGIC with the client (NULL = no use tax, or a data gap?).

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

from pyspark.sql.functions import col, lit, when

df = read_stage(spark, STAGE["tax_lookup"])

# Defensive: guarantee the input column exists (upstream AP feed may omit it).
if "use_tax_amount" not in df.columns:
    df = df.withColumn("use_tax_amount", lit(None).cast("double"))

out = df.withColumn(
    "Reverse_UseTax",
    when((col("use_tax_amount") > 0) & (col("taxability") == "Exempt"),  lit("Yes"))
    .when((col("use_tax_amount") > 0) & (col("taxability") == "Taxable"), lit("No"))
    .when(col("use_tax_amount") == 0, lit("No"))
    .when(col("use_tax_amount").isNull(), lit(None).cast("string"))   # DEFERRED
    .when(col("taxability").isNull(),     lit(None).cast("string"))
    .otherwise(lit(None).cast("string")))

write_stage(out, STAGE["use_tax"])
print("[3.3b] Reverse_UseTax distribution:")
out.groupBy("Reverse_UseTax").count().show()
dbutils.notebook.exit("3.3b OK")