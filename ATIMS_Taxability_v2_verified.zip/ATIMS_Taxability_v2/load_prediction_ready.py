# Databricks notebook source
# MAGIC %md
# MAGIC # Load ML input -> prediction_ready
# MAGIC
# MAGIC One-off loader: read the Phase 1/2 ML input from ADLS and write it to the
# MAGIC Delta table that Task 3.1 reads. Phase 3 normalizes the schema automatically
# MAGIC (see `normalize_input` in config_notebook), so keep the raw column names
# MAGIC (MIC, TRAN_AMOUNT, INVOICE_AMOUNT, ...) — they map to mic_cln / amount at read.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Confirm `source_path` + `source_format` below.
# MAGIC 2. Run. It prints the months present so you can pick the right widget value.
# MAGIC 3. In every Task notebook, set the **month** widget to match the data
# MAGIC    (e.g. **2023-01**), or Task 3.1 will match zero rows.

# COMMAND ----------

# COMMAND ----------

# MAGIC %run ./config_notebook

# COMMAND ----------

# FIX 1 (review comment): the storage account, container and catalog are no
# longer hardcoded here. They resolve per environment from config_notebook
# (ENV_CONFIG / the 'env' widget): BASE_PATH = abfss://<container>@<account>...
catalog = CATALOG
schema  = SCHEMA

# Real ML input location (ADLS Gen2), derived from the environment:
source_path   = SOURCE_PATH
source_format = "delta"   # change to "parquet" or "csv" if ML_INPUT is not Delta
print(f"[load] env={ENV}  source={source_path}  target=`{catalog}`.{schema}.prediction_ready")

# COMMAND ----------

if source_format == "csv":
    # ------------------------------------------------------------------
    # CSV READ HARDENING — do NOT simplify this back to header+inferSchema.
    #
    # Spark's DEFAULT csv escape character is BACKSLASH, not the RFC-4180
    # double-quote. AP descriptions routinely contain embedded quotes
    # (e.g. Construction Services ""Non-Exclusivity""), and with the default
    # escape the parser loses quote state mid-record, shifts every following
    # column, and corrupts the row WITHOUT raising. On the real ML_INPUT
    # export that silently mangled 65 rows and pushed 23 accounting_dates
    # into unparseable values, which then vanished from every month.
    #
    #   escape='"'      -> RFC-4180 doubled-quote escaping (THE critical one)
    #   multiLine       -> tolerate newlines inside quoted descriptions
    #   quote='"'       -> explicit, so a config change cannot alter it
    #   encoding UTF-8  -> descriptions carry en dashes / curly apostrophes
    #   PERMISSIVE + _corrupt_record -> unparseable rows are CAPTURED and
    #                      counted below instead of being dropped silently
    # ------------------------------------------------------------------
    raw = (spark.read
           .option("header", True)
           .option("inferSchema", True)
           .option("quote", '"')
           .option("escape", '"')
           .option("multiLine", True)
           .option("encoding", "UTF-8")
           .option("mode", "PERMISSIVE")
           .option("columnNameOfCorruptRecord", "_corrupt_record")
           .csv(source_path))
else:
    raw = spark.read.format(source_format).load(source_path)

# ---------------------------------------------------------------------------
# READ INTEGRITY CHECKS — fail loudly here rather than producing a silently
# short/corrupt prediction_ready that every downstream task then trusts.
# ---------------------------------------------------------------------------
_cols = {c.lower() for c in raw.columns}

if "_corrupt_record" in _cols:
    _bad = raw.filter(F.col("_corrupt_record").isNotNull())
    _n_bad = _bad.count()
    if _n_bad:
        print(f"[load] {_n_bad:,} UNPARSEABLE row(s) — sample:")
        _bad.select("_corrupt_record").show(5, truncate=200)
        raise ValueError(
            f"[load] {_n_bad:,} row(s) could not be parsed from {source_path}. "
            "Refusing to write a corrupt prediction_ready. Check the delimiter, "
            "quote/escape characters and encoding of the source file."
        )
    raw = raw.drop("_corrupt_record")
    _cols.discard("_corrupt_record")

# Columns Task 3.1 cannot run without (post-normalize_input names in brackets).
_REQUIRED = ["invoice_id", "inv_line_number", "final_description",
             "vendor_name", "state", "accounting_date"]
_missing = [c for c in _REQUIRED if c not in _cols]
if _missing:
    raise ValueError(f"[load] source is missing required column(s): {_missing}. "
                     f"Present: {sorted(_cols)}")

# Columns that are optional but change what the pipeline can actually decide.
for _c, _why in [("gte_embedding", "Task 3.2 XGBoost sub-model cannot run"),
                 ("use_tax_amount", "Reverse_UseTax will be NULL for every row"),
                 ("mic", "mic_cln rules cannot match"),
                 ("extc", "extc rules cannot match"),
                 ("account_code", "account rules cannot match")]:
    if _c not in _cols:
        print(f"[load] NOTE: no '{_c}' column — {_why}.")

# Every row must carry a parseable accounting_date or it is invisible to the
# monthly filter in Task 3.1 (see the silent-loss guard there).
_n_total = raw.count()
_n_nodate = raw.filter(F.to_date(F.col("accounting_date")).isNull()).count()
print(f"[load] rows={_n_total:,}  columns={len(raw.columns)}  "
      f"unparseable accounting_date={_n_nodate:,}")
if _n_nodate:
    print(f"[load] WARNING: {_n_nodate:,} row(s) have an unparseable accounting_date "
          "and will never appear in ANY monthly run.")

print("columns:", raw.columns)
print("months present:")
raw.selectExpr("date_format(to_date(ACCOUNTING_DATE), 'yyyy-MM') AS m") \
   .groupBy("m").count().orderBy("m").show()

# COMMAND ----------

# Option A (default): copy into a managed prediction_ready Delta table.
(raw.write.format("delta").mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"`{catalog}`.{schema}.prediction_ready"))

# Option B: skip the copy and register the ADLS data in place as an external table
# (uncomment to use instead of Option A; avoids duplicating the data):
# spark.sql(f"""
#   CREATE TABLE IF NOT EXISTS `{catalog}`.{schema}.prediction_ready
#   USING {source_format} LOCATION '{source_path}'
# """)

print("prediction_ready rows:",
      spark.table(f"`{catalog}`.{schema}.prediction_ready").count())