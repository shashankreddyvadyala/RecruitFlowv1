"""Is a gradient-boosted model worth adding, and does ensembling help?

Sub-model A (XGBoost on 1024-dim gte_embedding) cannot run: the feed has no
embedding column and the serving endpoint is Phase 2's, not this codebase's. So
the practical question is whether a gradient-boosted model trained on the
features we DO have would add anything over the current logistic regression,
and whether combining models beats any single one.

Temporal holdout throughout: train Apr+Jun, predict May. Macro-F1 is the metric
that matters — accuracy is carried by the two largest clusters.
"""
import sys, time
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, f1_score
import xgboost as xgb

sys.path.insert(0, "/home/claude/harness")
exec(open("/home/claude/harness/eval_classifier.py").read().split("kw_map =")[0])

data["month"] = pd.to_datetime(data.ACCOUNTING_DATE, errors="coerce").dt.strftime("%Y-%m")
data["codes"] = ("acct_" + data.ACCOUNT_CODE.fillna("na") + " extc_" + data.EXTC.fillna("na")
                 + " mic_" + data.MIC.fillna("na") + " cc_" + data.COMPANY_CODE.fillna("na")
                 + " st_" + data.STATE.fillna("na"))
data["feat"] = (data.text + " " + data.codes).str.lower()
m = data[data.category.notna() & data.month.notna()].copy()
TEST = "2025-05"
tr, te = m[m.month != TEST], m[m.month == TEST]

vec = TfidfVectorizer(sublinear_tf=True, min_df=1, ngram_range=(1, 2), max_features=60000)
Xtr = vec.fit_transform(tr.feat); Xte = vec.transform(te.feat)
# Fit the encoder on TRAIN only: classes absent from training genuinely cannot
# be predicted, and must count as errors rather than being quietly re-indexed.
le = LabelEncoder().fit(tr.category)
ytr = le.transform(tr.category)
yte_lbl = te.category.values                      # compare as strings
print(f"train {Xtr.shape}  test {Xte.shape}  classes={len(le.classes_)}\n")

results = {}

def score(name, proba, t0, classes):
    # proba columns follow the FITTED model's class order, which is not the
    # label-encoder id. Map through classes explicitly.
    p = np.asarray(classes)[proba.argmax(1)]
    p = le.inverse_transform(p) if np.issubdtype(np.asarray(p).dtype, np.number) else p
    a = accuracy_score(yte_lbl, p); f = f1_score(yte_lbl, p, average="macro", zero_division=0)
    results[name] = proba
    print(f"{name:38} acc={a:.3f}  macroF1={f:.3f}   ({time.time()-t0:5.1f}s)")
    return f

t0 = time.time()
lr = LogisticRegression(max_iter=1000, C=4.0, class_weight="balanced").fit(Xtr, ytr)
score("LogisticRegression (current)", lr.predict_proba(Xte), t0, lr.classes_)

t0 = time.time()
nb = MultinomialNB(alpha=0.1).fit(Xtr, ytr)
score("MultinomialNB (sub-model D)", nb.predict_proba(Xte), t0, nb.classes_)

t0 = time.time()
rf = RandomForestClassifier(n_estimators=200, n_jobs=2, random_state=0,
                            class_weight="balanced_subsample").fit(Xtr, ytr)
score("RandomForest", rf.predict_proba(Xte), t0, rf.classes_)

t0 = time.time()
bst = xgb.XGBClassifier(n_estimators=300, max_depth=6, learning_rate=0.3,
                        tree_method="hist", n_jobs=2, verbosity=0)
bst.fit(Xtr, ytr)
score("XGBoost (on the same TF-IDF)", bst.predict_proba(Xte), t0, bst.classes_)

print("\n--- ensembles (soft vote over the probability matrices) ---")
def combo(name, keys, weights=None):
    # every model here was fit on the same ytr, so their class orders align
    ps = [results[k] for k in keys]
    w = weights or [1.0] * len(ps)
    avg = sum(wi * p for wi, p in zip(w, ps)) / sum(w)
    p = le.inverse_transform(avg.argmax(1))
    print(f"{name:38} acc={accuracy_score(yte_lbl,p):.3f}  "
          f"macroF1={f1_score(yte_lbl,p,average='macro',zero_division=0):.3f}")

combo("LR + XGB", ["LogisticRegression (current)", "XGBoost (on the same TF-IDF)"])
combo("LR + NB", ["LogisticRegression (current)", "MultinomialNB (sub-model D)"])
combo("LR + NB + XGB", ["LogisticRegression (current)", "MultinomialNB (sub-model D)",
                        "XGBoost (on the same TF-IDF)"])
combo("LR + NB + RF + XGB", list(results.keys()))

print("\n--- would embeddings help? proxy: dense SVD features ---")
from sklearn.decomposition import TruncatedSVD
sv = TruncatedSVD(n_components=256, random_state=0)
Dtr = sv.fit_transform(Xtr); Dte = sv.transform(Xte)
t0 = time.time()
bst2 = xgb.XGBClassifier(n_estimators=300, max_depth=6, learning_rate=0.3,
                         tree_method="hist", n_jobs=2, verbosity=0)
bst2.fit(Dtr, ytr)
score("XGBoost on 256-dim dense (SVD)", bst2.predict_proba(Dte), t0, bst2.classes_)
print(f"   (explained variance {sv.explained_variance_ratio_.sum():.2f})")
