"""Two questions:

Q1. After sub-model D, where can a NULL still come from?
    A row whose tokens are ENTIRELY out of vocabulary matches nothing, so the
    scoring join produces no candidate class and the left-join leaves nlp_pred
    NULL. Measure how many rows that is.

Q2. Which feature changes actually reduce that, and do they cost accuracy?
    Tested on a TEMPORAL holdout (train Apr+Jun, predict May) so the model has
    not seen the rows it scores.

Caveat unchanged: labels come from the rules, so accuracy here means agreement
with the rules, not tax correctness.
"""
import sys
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline, FeatureUnion
from sklearn.metrics import accuracy_score, f1_score

sys.path.insert(0, "/home/claude/harness")
exec(open("/home/claude/harness/eval_classifier.py").read().split("kw_map =")[0])

data["month"] = pd.to_datetime(data.ACCOUNTING_DATE, errors="coerce").dt.strftime("%Y-%m")
data["codes"] = ("acct_" + data.ACCOUNT_CODE.fillna("na") + " extc_" + data.EXTC.fillna("na")
                 + " mic_" + data.MIC.fillna("na") + " cc_" + data.COMPANY_CODE.fillna("na")
                 + " st_" + data.STATE.fillna("na"))
data["feat"] = (data.text + " " + data.codes).str.lower()
m = data[data.category.notna() & data.month.notna()].copy()
unm = data[data.category.isna()].copy()          # what the model must predict
TEST = "2025-05"
tr, te = m[m.month != TEST], m[m.month == TEST]

# ---------------- Q1: out-of-vocabulary rows -------------------------------
def toks(s):
    import re
    return {t for t in re.split(r"[^a-z0-9]+", s.lower()) if len(t) >= 2}

vocab = set()
for t in tr.feat:
    vocab |= toks(t)
print(f"training vocabulary (word tokens, Apr+Jun): {len(vocab):,}")

for name, frame in [("May rule-matched", te), ("unmatched (real target)", unm)]:
    ov = frame.feat.apply(lambda s: len(toks(s) & vocab) / max(len(toks(s)), 1))
    zero = (ov == 0).sum()
    print(f"  {name:26} n={len(frame):5,}  zero-overlap rows={zero:4,} "
          f"({zero/max(len(frame),1)*100:4.1f}%)   mean coverage={ov.mean():.2f}")
print("\nZero-overlap rows are where sub-model D can still return NULL.")

# ---------------- Q2: feature variants -------------------------------------
def word():
    return TfidfVectorizer(sublinear_tf=True, min_df=2, ngram_range=(1, 2), max_features=60000)

def word_mindf1():
    return TfidfVectorizer(sublinear_tf=True, min_df=1, ngram_range=(1, 2), max_features=120000)

def char():
    return TfidfVectorizer(sublinear_tf=True, analyzer="char_wb", ngram_range=(3, 5),
                           min_df=2, max_features=120000)

def union():
    return FeatureUnion([("w", word()), ("c", char())])

def run(name, vec):
    clf = make_pipeline(vec, LogisticRegression(max_iter=1000, C=4.0, class_weight="balanced"))
    clf.fit(tr.feat, tr.category)
    p = clf.predict(te.feat)
    a = accuracy_score(te.category, p)
    f = f1_score(te.category, p, average="macro", zero_division=0)
    # can it produce a prediction for every unmatched row?
    X = clf.named_steps[list(clf.named_steps)[0]].transform(unm.feat)
    empty = (X.sum(axis=1).A1 == 0).sum() if hasattr(X.sum(axis=1), "A1") else 0
    print(f"{name:34} acc={a:.3f} macroF1={f:.3f}  unmatched rows with NO features={empty}")
    return f

print(f"\ntrain {len(tr):,} rows -> test {len(te):,} rows (temporal)")
print("-" * 88)
run("word 1-2gram, min_df=2 (current)", word())
run("word 1-2gram, min_df=1", word_mindf1())
run("char_wb 3-5gram only", char())
run("word + char union", union())
