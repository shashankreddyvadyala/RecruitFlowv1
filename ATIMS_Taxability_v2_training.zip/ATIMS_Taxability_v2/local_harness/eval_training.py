"""Which training changes actually improve cluster prediction?

Honest test throughout: TEMPORAL holdout. Train on Apr+Jun+Jul, predict May.
That is the only split where the model has not already seen the rows it scores.
Reported on macro-F1, because accuracy is dominated by the two huge clusters and
hides everything happening in the tail — which is where cluster models fail.

Variants:
  V0 within-month        current design: train on May only (5-fold CV)
  V1 temporal baseline   train Apr+Jun+Jul, no class weighting
  V2 + class balancing   weight each cluster inversely to its frequency
  V3 + min rows/cluster  drop clusters with too few examples to learn
  V4 + rule weighting    keyword-rule labels down-weighted (already shipped)
  V5 all combined        what I would ship
"""
import sys
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import accuracy_score, f1_score

sys.path.insert(0, "/home/claude/harness")
exec(open("/home/claude/harness/eval_classifier.py").read().split("kw_map =")[0])

data["month"] = pd.to_datetime(data.ACCOUNTING_DATE, errors="coerce").dt.strftime("%Y-%m")
data["codes"] = ("acct_" + data.ACCOUNT_CODE.fillna("na") + " extc_" + data.EXTC.fillna("na")
                 + " mic_" + data.MIC.fillna("na") + " cc_" + data.COMPANY_CODE.fillna("na")
                 + " st_" + data.STATE.fillna("na"))
data["feat"] = data.text + " " + data.codes
m = data[data.category.notna() & data.month.notna()].copy()

TEST = "2025-05"
te = m[m.month == TEST]
tr = m[m.month != TEST]

def run(name, tr_, te_, balanced, min_per_class, rule_weight):
    t = tr_.copy()
    if min_per_class > 1:
        vc = t.category.value_counts()
        t = t[t.category.map(vc) >= min_per_class]
    if t.category.nunique() < 2:
        print(f"{name:34} insufficient"); return
    w = None
    if rule_weight:
        w = np.where(t.rule_type.values == "keyword", 0.25, 1.0)
    clf = make_pipeline(
        TfidfVectorizer(sublinear_tf=True, min_df=2, ngram_range=(1, 2), max_features=60000),
        LogisticRegression(max_iter=1000, C=4.0,
                           class_weight="balanced" if balanced else None))
    if w is not None:
        clf.fit(t.feat, t.category, logisticregression__sample_weight=w)
    else:
        clf.fit(t.feat, t.category)
    p = clf.predict(te_.feat)
    a = accuracy_score(te_.category, p)
    f = f1_score(te_.category, p, average="macro", zero_division=0)
    cov = len(set(te_.category) & set(t.category)) / te_.category.nunique()
    print(f"{name:34} n={len(t):>6,} acc={a:.3f} macroF1={f:.3f} clusters_learnable={cov*100:4.0f}%")
    return f

print(f"train months: {sorted(tr.month.unique())}   test month: {TEST}")
print(f"train rows {len(tr):,}   test rows {len(te):,}   "
      f"clusters in train {tr.category.nunique()}, in test {te.category.nunique()}\n")

# V0 within-month CV for reference
vc = te.category.value_counts(); te_cv = te[te.category.map(vc) >= 5]
pred = cross_val_predict(
    make_pipeline(TfidfVectorizer(sublinear_tf=True, min_df=2, ngram_range=(1, 2)),
                  LogisticRegression(max_iter=1000, C=4.0)),
    te_cv.feat, te_cv.category, cv=StratifiedKFold(5, shuffle=True, random_state=0), n_jobs=1)
print(f"{'V0 within-month (current, CV)':34} n={len(te_cv):>6,} "
      f"acc={accuracy_score(te_cv.category, pred):.3f} "
      f"macroF1={f1_score(te_cv.category, pred, average='macro', zero_division=0):.3f}"
      f"   <- sees May during training")
print("-" * 92)
run("V1 temporal baseline",       tr, te, False, 1, False)
run("V2 + class balancing",       tr, te, True,  1, False)
run("V3 + min 3 rows/cluster",    tr, te, True,  3, False)
run("V4 + rule weighting",        tr, te, True,  1, True)
run("V5 all combined",            tr, te, True,  3, True)

print("\n--- cluster coverage problem ---")
print(f"canonical clusters in the rules table : {data.category.nunique()}")
for mo in sorted(m.month.unique()):
    print(f"  {mo}: model label space would be {m[m.month==mo].category.nunique():3} clusters")
print("\nA cluster absent from the training month can never be predicted that month,")
print("no matter how obvious the line is.")

print("\n--- how thin is the tail? ---")
vc = m.category.value_counts()
for band, lo, hi in [("1-2 rows", 1, 2), ("3-9 rows", 3, 9), ("10-49", 10, 49), ("50+", 50, 10**9)]:
    cl = vc[(vc >= lo) & (vc <= hi)]
    print(f"  clusters with {band:10} : {len(cl):3}  covering {cl.sum():6,} rows")
