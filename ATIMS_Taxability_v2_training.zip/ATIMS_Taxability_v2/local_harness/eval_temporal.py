"""Does the training scope matter?

CURRENT DESIGN: Task 3.1 filters prediction_ready to MONTH. Task 3.2 trains on
STAGE['rules_matched'] -- which is THAT MONTH's rule-matched rows only -- and
predicts THAT MONTH's unmatched rows. A brand-new model every month. No other
month is ever seen.

Compared here:
  S1 WITHIN-MONTH   train on May's rule-matched rows, test on May   (current)
  S2 POOLED         train on all months' rule-matched rows, test on May
  S3 TEMPORAL       train on Apr+Jun+Jul only, test on May          (true holdout)

S3 is the only one that answers "would a model built last month still work this
month". S1 and S2 both let the model see May rows during training.

CAVEAT that applies to every number below: labels come from the rules, so this
measures agreement with the rules, not tax correctness.
"""
import re, sys
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import accuracy_score, f1_score

sys.path.insert(0, "/home/claude/harness")
# reuse the rule-replay from eval_classifier (everything before kw_map)
exec(open("/home/claude/harness/eval_classifier.py").read().split("kw_map =")[0])

data["month"] = pd.to_datetime(data.ACCOUNTING_DATE, errors="coerce").dt.strftime("%Y-%m")
data["codes"] = ("acct_" + data.ACCOUNT_CODE.fillna("na") + " extc_" + data.EXTC.fillna("na")
                 + " mic_" + data.MIC.fillna("na") + " cc_" + data.COMPANY_CODE.fillna("na")
                 + " st_" + data.STATE.fillna("na"))
data["feat"] = data.text + " " + data.codes
m = data[data.category.notna() & data.month.notna()].copy()

print("rule-matched rows per month:")
print(m.month.value_counts().sort_index().to_string())
print("\nunmatched (what the model must actually predict) per month:")
print(data[data.category.isna()].month.value_counts().sort_index().to_string())

TEST_MONTH = "2025-05"
te = m[m.month == TEST_MONTH]
tr_pool = m
tr_other = m[m.month != TEST_MONTH]

def build():
    return make_pipeline(
        TfidfVectorizer(sublinear_tf=True, min_df=2, ngram_range=(1, 2), max_features=60000),
        LogisticRegression(max_iter=1000, C=4.0, class_weight="balanced"))

def fit_predict(tr, te_):
    vc = tr.category.value_counts()
    tr = tr[tr.category.map(vc) >= 2]
    clf = build().fit(tr.feat, tr.category)
    p = clf.predict(te_.feat)
    return (accuracy_score(te_.category, p),
            f1_score(te_.category, p, average="macro", zero_division=0),
            len(tr), len(te_), set(tr.category))

print("\n" + "=" * 84)
print(f"{'scenario':40} {'n_train':>8} {'n_test':>7} {'acc':>7} {'macroF1':>8}")
print("=" * 84)

# S1 within-month, cross-validated (cannot train and test on identical rows)
vc = te.category.value_counts()
te_cv = te[te.category.map(vc) >= 5]
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
pred = cross_val_predict(build(), te_cv.feat, te_cv.category, cv=skf, n_jobs=1)
a1 = accuracy_score(te_cv.category, pred)
f1_ = f1_score(te_cv.category, pred, average="macro", zero_division=0)
print(f"{'S1 within-month (current design, 5-fold CV)':40} {len(te_cv):>8,} {len(te_cv):>7,} "
      f"{a1:>7.3f} {f1_:>8.3f}")

a2, f2, n2, nt2, _ = fit_predict(tr_pool, te)
print(f"{'S2 pooled all months -> May':40} {n2:>8,} {nt2:>7,} {a2:>7.3f} {f2:>8.3f}")

a3, f3, n3, nt3, seen = fit_predict(tr_other, te)
print(f"{'S3 TEMPORAL Apr+Jun+Jul -> May':40} {n3:>8,} {nt3:>7,} {a3:>7.3f} {f3:>8.3f}")

print("=" * 84)

# What May categories does a model trained on other months not even know?
may_cats = set(te.category)
unseen = may_cats - seen
n_unseen = te[te.category.isin(unseen)].shape[0]
print(f"\nMay categories the Apr+Jun+Jul model has NEVER seen: {len(unseen)} of {len(may_cats)}")
if unseen:
    for c in sorted(unseen):
        print(f"   {c}  ({te[te.category == c].shape[0]:,} May lines)")
print(f"May lines whose true category is unlearnable by that model: {n_unseen:,} "
      f"({n_unseen/len(te)*100:.1f}%)")

# Model instability: does the label space change month to month?
print("\nlabel space per month (the model is rebuilt from scratch each run):")
for mo in sorted(m.month.unique()):
    cats = set(m[m.month == mo].category)
    print(f"   {mo}: {len(cats):3} categories, {m[m.month==mo].shape[0]:6,} training rows")
allc = set(m.category)
common = set.intersection(*[set(m[m.month == mo].category) for mo in sorted(m.month.unique())])
print(f"   categories present in EVERY month: {len(common)} of {len(allc)} total")
