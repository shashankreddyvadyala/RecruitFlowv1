"""Calibrate nlp_min_confidence / nlp_min_coverage against measured precision.

Today NLP_HIGH means "decision margin > 0.60", a number nobody measured. It
should mean "at this margin the model is right at least X% of the time on a
holdout". This finds the margin that delivers a target precision, and reports
what fraction of rows survive it (the accept rate) so the trade-off is visible.

CAVEAT, unchanged and important: labels come from the rules. "Right" here means
"agrees with the rule that labelled the row", NOT "correct for tax purposes".
This calibrates the model's self-knowledge, not its correctness.
"""
import sys
import numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import StratifiedKFold, cross_val_predict

sys.path.insert(0, "/home/claude/harness")
exec(open("/home/claude/harness/eval_classifier.py").read().split("kw_map =")[0])

data["codes"] = ("acct_" + data.ACCOUNT_CODE.fillna("na") + " extc_" + data.EXTC.fillna("na")
                 + " mic_" + data.MIC.fillna("na") + " cc_" + data.COMPANY_CODE.fillna("na")
                 + " st_" + data.STATE.fillna("na"))
data["feat"] = data.text + " " + data.codes
m = data[data.category.notna()].copy()
vc = m.category.value_counts()
m = m[m.category.map(vc) >= 5]
print(f"calibration set: {len(m):,} rule-labelled rows, {m.category.nunique()} classes")

pipe = make_pipeline(
    TfidfVectorizer(sublinear_tf=True, min_df=2, ngram_range=(1, 2), max_features=60000),
    LogisticRegression(max_iter=1000, C=4.0, class_weight="balanced"))
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

proba = cross_val_predict(pipe, m.feat, m.category, cv=skf, method="predict_proba", n_jobs=1)
classes = np.unique(m.category)
pred = classes[proba.argmax(1)]
srt = np.sort(proba, axis=1)
margin = srt[:, -1] - srt[:, -2]          # top1 - top2, same statistic as production
correct = (pred == m.category.values)

print(f"\noverall accept-everything accuracy: {correct.mean():.3f}")
print("\n{:>8}  {:>10}  {:>10}  {:>12}".format("margin", "accept %", "precision", "rows accepted"))
print("-" * 48)
best = None
for t in [0.0, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95]:
    sel = margin >= t
    if sel.sum() == 0:
        print(f"{t:>8.2f}  {'0.0':>10}  {'-':>10}  {0:>12}")
        continue
    prec = correct[sel].mean()
    print(f"{t:>8.2f}  {sel.mean()*100:>9.1f}%  {prec:>10.3f}  {sel.sum():>12,}")

for target in (0.95, 0.98, 0.99):
    hit = None
    for t in np.arange(0.0, 0.99, 0.01):
        sel = margin >= t
        if sel.sum() >= 50 and correct[sel].mean() >= target:
            hit = (round(t, 2), sel.mean(), correct[sel].mean(), sel.sum())
            break
    if hit:
        print(f"\ntarget precision {target:.2f} -> margin >= {hit[0]:.2f} "
              f"(accepts {hit[1]*100:.1f}% of rows, {hit[3]:,} rows, measured precision {hit[2]:.3f})")
    else:
        print(f"\ntarget precision {target:.2f} -> NOT reachable at any margin")

print("\n" + "=" * 62)
print("Where the CURRENT thresholds land")
print("=" * 62)
for t, name in [(0.60, "nlp_min_confidence (current default)")]:
    sel = margin >= t
    print(f"{name}: margin >= {t}")
    print(f"   accepts {sel.mean()*100:.1f}% of rows ({sel.sum():,})")
    print(f"   measured precision on those: {correct[sel].mean():.3f}")
    print(f"   rows REJECTED to human review: {(~sel).sum():,} "
          f"({(~sel).mean()*100:.1f}%), of which {correct[~sel].mean()*100:.1f}% "
          f"the model would actually have got right")
