# Databricks notebook source
# MAGIC %md
# MAGIC # Load ML input -> prediction_ready
# MAGIC
# MAGIC One-off loader: read the Phase 1/2 ML input from ADLS and write it to the
# MAGIC Delta table that Task 3.1 reads. Phase 3 normalizes the schema automatically
# MAGIC (see `normalize_input` in config_notebook), so keep the raw column names
# MAGIC (MIC, TRAN_AMOUNT, INVOICE_AMOUNT, ...) — they map to mic_cln / amount at read.
# MAGIC
# MAGIC **Steps**
# MAGIC 1. Confirm `source_path` + `source_format` below.
# MAGIC 2. Run. It prints the months present so you can pick the right widget value.
# MAGIC 3. In every Task notebook, set the **month** widget to match the data
# MAGIC    (e.g. **2023-01**), or Task 3.1 will match zero rows.

# COMMAND ----------

catalog = "31500_atims_dev"
schema  = "atims_taxability"

# Real ML input location (ADLS Gen2). The cluster must already have access to
# the nprdatimsstore storage account (UC external location / credential passthrough).
source_path   = "abfss://atims@nprdatimsstore.dfs.core.windows.net/TAXABILITY_DATA/ML_INPUT"
source_format = "delta"   # change to "parquet" or "csv" if ML_INPUT is not Delta

# COMMAND ----------

if source_format == "csv":
    raw = (spark.read.option("header", True).option("inferSchema", True).csv(source_path))
else:
    raw = spark.read.format(source_format).load(source_path)

print(f"loaded {raw.count():,} rows, {len(raw.columns)} columns from {source_path}")
print("columns:", raw.columns)
print("months present:")
raw.selectExpr("date_format(to_date(ACCOUNTING_DATE), 'yyyy-MM') AS m").groupBy("m").count().orderBy("m").show()

# COMMAND ----------

# Option A (default): copy into a managed prediction_ready Delta table.
(raw.write.format("delta").mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"`{catalog}`.{schema}.prediction_ready"))

print("prediction_ready rows:",
      spark.table(f"`{catalog}`.{schema}.prediction_ready").count())