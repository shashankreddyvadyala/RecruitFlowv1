# Databricks notebook source
# MAGIC %md
# MAGIC # Task 3.4 · tax_writer_notebook
# MAGIC Generates an auditor-facing justification per line. Retrieves similar **prior
# MAGIC write-ups** via Vector Search (few-shot grounding), then calls `ai_query` with a
# MAGIC structured prompt. When `Reverse_UseTax = 'Yes'`, the prompt must reference the
# MAGIC self-assessment and `use_tax_amount`.
# MAGIC
# MAGIC Output: `t34_writeup` with `short_justification`, `full_writeup`.

# COMMAND ----------
# MAGIC %run ./00_config_common

# COMMAND ----------
from pyspark.sql.functions import col

IN_TABLE  = resolve_input("t33b_use_tax")
OUT_TABLE = resolve_output("t34_writeup")

df = read_stage(IN_TABLE)
key_cols = [COLS["invoice_id"], COLS["inv_line_number"]]

# COMMAND ----------
# MAGIC %md ### 1. Retrieve prior write-ups (Vector Search, batched)

from databricks.vector_search.client import VectorSearchClient

def retrieve_priors(pdf):
    vsc = VectorSearchClient(disable_notice=True)
    idx = vsc.get_index(VS_ENDPOINT, VS_WRITEUPS_INDEX)
    examples = []
    for _, r in pdf.iterrows():
        q = f"{r['final_category']} | {r['final_description'] or ''}"
        res = idx.similarity_search(query_text=q, columns=["full_writeup"], num_results=2)
        rows = (res.get("result", {}).get("data_array") or [])
        examples.append(" ||| ".join(x[0] for x in rows) if rows else "")
    pdf = pdf.copy(); pdf["prior_examples"] = examples
    return pdf

ctx_cols = key_cols + ["final_category", "final_description", "taxability",
                       "Reverse_UseTax", "use_tax_amount", COLS["vendor_name"], COLS["extc"]]
pdf = df.select(*[c for c in ctx_cols if c in df.columns]).toPandas()
pdf = retrieve_priors(pdf)
priors_df = spark.createDataFrame(pdf[key_cols + ["prior_examples"]])
work = df.join(priors_df, key_cols, "left")

# COMMAND ----------
# MAGIC %md
# MAGIC ### 2. Structured write-up generation (ai_query)
# MAGIC Asks for a strict JSON object so the two fields parse cleanly. The use-tax
# MAGIC clause is injected only when `Reverse_UseTax = 'Yes'`.

work.createOrReplaceTempView("writer_ctx")
writer = spark.sql(f"""
  SELECT *,
    ai_query(
      '{LLM_ENDPOINT}',
      concat(
        'You are a corporate tax analyst. Using the prior examples for tone, write a ',
        'justification for the tax treatment of this invoice line. Return STRICT JSON ',
        'with keys "short_justification" (<=200 chars) and "full_writeup" (2-4 sentences). ',
        'No prose outside the JSON.\\n',
        'Category: ', coalesce(final_category, 'NA'), '\\n',
        'Taxability: ', coalesce(taxability, 'NA'), '\\n',
        CASE WHEN Reverse_UseTax = 'Yes'
             THEN concat('Reverse use tax APPLIES; self-assessed use_tax_amount = ',
                         cast(use_tax_amount AS string), '. Explain the self-assessment.\\n')
             ELSE '' END,
        'Vendor: ', coalesce({COLS['vendor_name']}, 'NA'),
        '  EXTC: ', coalesce({COLS['extc']}, 'NA'), '\\n',
        'Description: ', coalesce(final_description, ''), '\\n',
        'Prior examples: ', coalesce(prior_examples, 'none')
      )
    ) AS _writeup_json
  FROM writer_ctx
""")

# Parse the JSON the model returned. get_json_object is null-safe on malformed JSON.
from pyspark.sql.functions import get_json_object
writer = (writer
    .withColumn("short_justification", get_json_object(col("_writeup_json"), "$.short_justification"))
    .withColumn("full_writeup",        get_json_object(col("_writeup_json"), "$.full_writeup"))
    .drop("_writeup_json", "prior_examples"))

write_stage(writer, OUT_TABLE)
