# Databricks notebook source
# MAGIC %md
# MAGIC # Task 3.6 · reroute_notebook
# MAGIC Takes the QA output, isolates `override_suggested = true` records, and re-runs
# MAGIC the classify → tax → use-tax → write-up → QA chain on **just that subset**, up to
# MAGIC `MAX_REROUTE_PASSES` (default 2). Each child notebook is invoked with
# MAGIC `input_table`/`output_table` overrides so it operates only on the flagged subset.
# MAGIC After the passes, reprocessed rows are merged back over the originals.
# MAGIC
# MAGIC Output: `t36_final` (full population with rerouted rows updated).

# COMMAND ----------
# MAGIC %run ./00_config_common

# COMMAND ----------
from pyspark.sql.functions import col

QA_TABLE  = staging("t35_qa")
OUT_TABLE = staging("t36_final")
key_cols  = [COLS["invoice_id"], COLS["inv_line_number"]]

base = read_stage(QA_TABLE)
current = base
NB_DIR = "."   # sibling notebooks live in the same workspace folder

def run_child(nb, in_tbl, out_tbl, extra=None):
    args = {"run_id": RUN_ID, "invoice_month": INVOICE_MONTH,
            "input_table": in_tbl, "output_table": out_tbl}
    if extra:
        args.update(extra)
    dbutils.notebook.run(f"{NB_DIR}/{nb}", 3600, args)

# COMMAND ----------
# MAGIC %md ### Reroute passes

for p in range(1, MAX_REROUTE_PASSES + 1):
    flagged = current.filter(col("override_suggested") == True)  # noqa: E712
    n = flagged.count()
    print(f"\n=== Reroute pass {p}/{MAX_REROUTE_PASSES} — {n:,} flagged ===")
    if n == 0:
        print("   Nothing flagged; stopping.")
        break

    # The classifier consumes an 'unmatched'-shaped frame, so seed pass input from
    # the flagged rows' original feature columns. We strip prior predictions first.
    pass_in = staging(f"t36_p{p}_in")
    drop_cols = ["xgb_category", "xgb_confidence", "llm_category", "final_category",
                 "ensemble_confidence", "decision_path", "taxability", "tax_source",
                 "Reverse_UseTax", "short_justification", "full_writeup",
                 "anomaly_score", "review_priority", "override_suggested"]
    flagged.drop(*[c for c in drop_cols if c in flagged.columns]) \
           .write.format("delta").mode("overwrite") \
           .option("overwriteSchema", "true").saveAsTable(pass_in)

    c_out  = staging(f"t36_p{p}_classified")
    t_out  = staging(f"t36_p{p}_tax")
    u_out  = staging(f"t36_p{p}_usetax")
    w_out  = staging(f"t36_p{p}_writeup")
    q_out  = staging(f"t36_p{p}_qa")

    run_child("classifier_notebook",      pass_in, c_out)
    run_child("tax_lookup_notebook",      c_out,   t_out)
    run_child("use_tax_lookup_notebook",  t_out,   u_out)
    run_child("tax_writer_notebook",      u_out,   w_out)
    run_child("qa_notebook",              w_out,   q_out)

    reprocessed = read_stage(q_out)

    # Merge reprocessed rows over the current population by key.
    keep = current.join(reprocessed.select(*key_cols), key_cols, "left_anti")
    current = keep.unionByName(reprocessed, allowMissingColumns=True)

    # If a reprocessed row is still flagged, it carries into the next pass.
    still = current.filter(col("override_suggested") == True).count()  # noqa: E712
    print(f"   Still flagged after pass {p}: {still:,}")
    if still == 0:
        break

write_stage(current, OUT_TABLE)
