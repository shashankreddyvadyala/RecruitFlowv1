# Databricks notebook source
# MAGIC %md
# MAGIC # Task 3.2 · classifier_notebook
# MAGIC Classifies the **unmatched** frame three ways and ensembles them, then unifies
# MAGIC with the rule/RAG frames so one table carries every record forward.
# MAGIC
# MAGIC 1. **Served XGBoost** (`mlflow.deployments` batch predict) → `xgb_category`, `xgb_confidence`
# MAGIC 2. **LLM zero-shot** (`ai_classify`) → `llm_category`
# MAGIC 3. **Disagreement resolution** (`ai_query`) when 1 ≠ 2 → `final_category`
# MAGIC
# MAGIC Output: `t32_classified` with `final_category`, `ensemble_confidence`, `decision_path`.

# COMMAND ----------
# MAGIC %run ./00_config_common

# COMMAND ----------
import json
from pyspark.sql.functions import col, lit, when

IN_UNMATCHED = resolve_input("t31_unmatched")          # reroute can override this
OUT_TABLE    = resolve_output("t32_classified")

unmatched = read_stage(IN_UNMATCHED)
n = unmatched.count()
print(f"   To classify: {n:,}  (from {IN_UNMATCHED})")

# COMMAND ----------
# MAGIC %md ### 1. XGBoost via serving endpoint (batched deploy-client calls)

from mlflow.deployments import get_deploy_client

FEATURE_COLS = ["final_description", COLS["extc"], COLS["mic"], COLS["company_code"],
                COLS["state"], COLS["invoice_source"], COLS["vendor_name"], COLS["tran_amount"]]

def xgb_batch_predict(pdf, batch_size=512):
    client = get_deploy_client("databricks")
    cats, confs = [], []
    for start in range(0, len(pdf), batch_size):
        chunk = pdf.iloc[start:start + batch_size][FEATURE_COLS]
        resp = client.predict(endpoint=MODEL_ENDPOINT,
                              inputs={"dataframe_split": json.loads(chunk.to_json(orient="split"))})
        preds = resp["predictions"]
        cats  += [p["xgb_category"]   for p in preds]
        confs += [p["xgb_confidence"] for p in preds]
    pdf = pdf.copy()
    pdf["xgb_category"], pdf["xgb_confidence"] = cats, confs
    return pdf

key_cols = [COLS["invoice_id"], COLS["inv_line_number"]]
pdf = unmatched.select(*key_cols, *FEATURE_COLS).toPandas()
pdf = xgb_batch_predict(pdf)
xgb_df = spark.createDataFrame(pdf[key_cols + ["xgb_category", "xgb_confidence"]])
work = unmatched.join(xgb_df, key_cols, "left")

# COMMAND ----------
# MAGIC %md ### 2. LLM zero-shot with ai_classify

labels_sql = "array(" + ", ".join("'" + c.replace("'", "\\'") + "'" for c in CATEGORIES) + ")"
work.createOrReplaceTempView("xgb_scored")
work = spark.sql(f"""
  SELECT *, ai_classify(final_description, {labels_sql}) AS llm_category
  FROM xgb_scored
""")

# COMMAND ----------
# MAGIC %md
# MAGIC ### 3. Ensemble + ai_query resolution on disagreements
# MAGIC Agreement → accept with a confidence boost. Disagreement → ask the LLM to pick
# MAGIC between the two candidates given the line context; confidence set conservatively.

work.createOrReplaceTempView("dual_scored")
resolved = spark.sql(f"""
  SELECT *,
    CASE WHEN xgb_category = llm_category THEN xgb_category
         ELSE trim(ai_query(
                '{LLM_ENDPOINT}',
                concat(
                  'You are an AP sales/use-tax classification expert. Choose the single best ',
                  'category for this invoice line. Reply with ONLY the category, exactly as written.\\n',
                  'Candidate A (gradient-boosted model): ', xgb_category, '\\n',
                  'Candidate B (zero-shot LLM): ', llm_category, '\\n',
                  'Vendor: ', coalesce({COLS['vendor_name']}, 'NA'),
                  '  EXTC: ', coalesce({COLS['extc']}, 'NA'),
                  '  MIC: ', coalesce({COLS['mic']}, 'NA'), '\\n',
                  'Description: ', coalesce(final_description, '')
                )))
    END AS final_category,
    CASE WHEN xgb_category = llm_category
         THEN least(1.0, greatest(xgb_confidence, 0.85))
         ELSE 0.55
    END AS ensemble_confidence,
    CASE WHEN xgb_category = llm_category THEN 'ml_agree' ELSE 'ml_resolved' END AS decision_path
  FROM dual_scored
""")

# Below-threshold ensemble rows are flagged for review downstream (kept, not dropped).
resolved = resolved.withColumn("decision_path",
    when(col("ensemble_confidence") < ACCEPT_CONF, lit("need_to_review"))
    .otherwise(col("decision_path")))

# COMMAND ----------
# MAGIC %md
# MAGIC ### 4. Unify with rule + RAG frames → single forward table
# MAGIC Only on the MAIN run. When reroute calls this with an `input_table` override,
# MAGIC the input is already a flagged subset — unioning the full rule/RAG frames here
# MAGIC would re-inject the entire non-flagged population, so we skip it.

classified = resolved
if not INPUT_TABLE_OVERRIDE:
    for tbl in ("t31_rules_matched", "t31_rag_matched"):
        fq = staging(tbl)
        if spark.catalog.tableExists(fq):
            classified = classified.unionByName(read_stage(fq), allowMissingColumns=True)

write_stage(classified, OUT_TABLE)
