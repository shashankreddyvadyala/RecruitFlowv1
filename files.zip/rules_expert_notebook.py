# Databricks notebook source
# MAGIC %md
# MAGIC # Task 3.1 · rules_expert_notebook
# MAGIC **Deterministic rule lookup (Spark SQL JOIN)** first, then **Vector Search RAG**
# MAGIC for whatever the rules miss. Splits the month into three frames.
# MAGIC
# MAGIC Outputs (staging tables):
# MAGIC - `t31_rules_matched` — matched by deterministic lookup (`final_category`, conf = 1.0)
# MAGIC - `t31_rag_matched`   — matched by Vector Search above `RAG_SIM_THRESHOLD`
# MAGIC - `t31_unmatched`     — neither; goes to the classifier

# COMMAND ----------
# MAGIC %run ./00_config_common

# COMMAND ----------
from pyspark.sql.functions import col, lit, broadcast

# COMMAND ----------
# MAGIC %md ### 1. Load the month + build final_description

src = (spark.read.format("delta").load(SOURCE_TABLE)
            .filter(f"{COLS['accounting_date']} like '{INVOICE_MONTH}%'"))
src = build_final_description(src)
print(f"   Loaded {src.count():,} invoice lines for {INVOICE_MONTH}")

# COMMAND ----------
# MAGIC %md
# MAGIC ### 2. Deterministic lookup (Spark SQL JOIN)
# MAGIC The original `_assign` rule chain is materialized once into a priority-ordered
# MAGIC `rule_lookup` table (cols: `priority, match_type, mic_pat, extc_pat, account_pat,
# MAGIC vendor_pat, desc_kw, company_pat, cluster`). Highest `priority` wins — the SQL
# MAGIC equivalent of "later `_assign` calls override earlier ones".
# MAGIC See README → "Materializing rule_lookup" for how to generate it from the rule chain.

src.createOrReplaceTempView("month_lines")

matched_sql = spark.sql(f"""
WITH ranked AS (
  SELECT  l.*, r.cluster AS final_category, r.priority,
          ROW_NUMBER() OVER (
            PARTITION BY l.{COLS['invoice_id']}, l.{COLS['inv_line_number']}
            ORDER BY r.priority DESC
          ) AS rk
  FROM    month_lines l
  JOIN    {RULES_LOOKUP_TABLE} r
    ON   (r.mic_pat     IS NULL OR l.{COLS['mic']}          LIKE r.mic_pat)
   AND   (r.extc_pat    IS NULL OR l.{COLS['extc']}         LIKE r.extc_pat)
   AND   (r.account_pat IS NULL OR l.{COLS['account_code']} LIKE r.account_pat)
   AND   (r.vendor_pat  IS NULL OR l.{COLS['vendor_name']}  LIKE r.vendor_pat)
   AND   (r.company_pat IS NULL OR l.{COLS['company_code']} LIKE r.company_pat)
   AND   (r.desc_kw     IS NULL OR lower(l.final_description) LIKE lower(r.desc_kw))
)
SELECT * FROM ranked WHERE rk = 1
""").drop("rk", "priority")

rules_matched = (matched_sql
    .withColumn("ensemble_confidence", lit(1.0))
    .withColumn("decision_path", lit("rule")))

matched_ids = rules_matched.select(COLS["invoice_id"], COLS["inv_line_number"])
remainder = src.join(broadcast(matched_ids), [COLS["invoice_id"], COLS["inv_line_number"]], "left_anti")
print(f"   Rule-matched: {rules_matched.count():,}  |  Remainder: {remainder.count():,}")

# COMMAND ----------
# MAGIC %md
# MAGIC ### 3. RAG fallback — Vector Search over labeled examples
# MAGIC Batch-search each remaining description against the labeled-example index.
# MAGIC Accept the nearest label when similarity ≥ `RAG_SIM_THRESHOLD`.

from databricks.vector_search.client import VectorSearchClient

def rag_label_batch(pdf):
    vsc = VectorSearchClient(disable_notice=True)
    idx = vsc.get_index(VS_ENDPOINT, VS_RULES_INDEX)
    out = []
    for _, row in pdf.iterrows():
        q = (row["final_description"] or "").strip()
        if not q:
            out.append((None, 0.0)); continue
        res = idx.similarity_search(query_text=q, columns=["category"], num_results=1)
        rows = (res.get("result", {}).get("data_array") or [])
        if rows:
            out.append((rows[0][0], float(rows[0][-1])))   # [category, score]
        else:
            out.append((None, 0.0))
    pdf["rag_category"], pdf["rag_score"] = zip(*out)
    return pdf

rem_pdf = remainder.select(
    COLS["invoice_id"], COLS["inv_line_number"], "final_description").toPandas()
rem_pdf = rag_label_batch(rem_pdf)
rag_spark = spark.createDataFrame(rem_pdf[[COLS["invoice_id"], COLS["inv_line_number"],
                                           "rag_category", "rag_score"]])

remainder = remainder.join(rag_spark, [COLS["invoice_id"], COLS["inv_line_number"]], "left")

rag_matched = (remainder.filter(col("rag_score") >= RAG_SIM_THRESHOLD)
    .withColumnRenamed("rag_category", "final_category")
    .withColumn("ensemble_confidence", col("rag_score").cast("double"))
    .withColumn("decision_path", lit("rag"))
    .drop("rag_score"))

unmatched = (remainder.filter((col("rag_score") < RAG_SIM_THRESHOLD) | col("rag_score").isNull())
    .drop("rag_category", "rag_score"))

print(f"   RAG-matched: {rag_matched.count():,}  |  Unmatched → ML: {unmatched.count():,}")

# COMMAND ----------
# MAGIC %md ### 4. Write the three frames

write_stage(rules_matched, staging("t31_rules_matched"))
write_stage(rag_matched,   staging("t31_rag_matched"))
write_stage(unmatched,     staging("t31_unmatched"))
set_task_value("unmatched_count", unmatched.count())
