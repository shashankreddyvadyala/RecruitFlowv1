# Databricks notebook source
# MAGIC %md
# MAGIC # 00 · Config & Common Helpers
# MAGIC `%run` this notebook at the top of every task. It defines all widgets,
# MAGIC the shared column map, the canonical category list, staging-table naming,
# MAGIC and the `final_description` builder carried over from the original pipeline.
# MAGIC
# MAGIC Nothing here triggers Spark work — it only declares config and functions.

# COMMAND ----------

from datetime import datetime
from pyspark.sql.functions import col, when, lit, concat_ws, coalesce

# COMMAND ----------
# MAGIC %md ### Widgets — every task inherits these via %run

def _w(name, default):
    try:
        dbutils.widgets.text(name, default)
    except Exception:
        pass
    return dbutils.widgets.get(name)

# Run identity (one logical pipeline run; scopes all staging tables)
RUN_ID          = _w("run_id", datetime.now().strftime("%Y%m%d_%H%M%S"))
INVOICE_MONTH   = _w("invoice_month", "2022-01")          # "YYYY-MM"

# Catalog / schemas
CATALOG         = _w("catalog", "atims")
STAGING_SCHEMA  = _w("staging_schema", "atims_staging")
PROD_SCHEMA     = _w("prod_schema", "atims_prod")

# Source + reference tables
SOURCE_TABLE        = _w("source_table",
    "abfss://atims@prdatimsstore.dfs.core.windows.net/FACT_TABLES/VMAP_FACT_TABLE")
RULES_LOOKUP_TABLE  = _w("rules_lookup_table",  f"{CATALOG}.{PROD_SCHEMA}.rule_lookup")
TAXABILITY_MATRIX   = _w("taxability_matrix",   f"{CATALOG}.{PROD_SCHEMA}.taxability_matrix")
HISTORICAL_STATS    = _w("historical_stats",    f"{CATALOG}.{PROD_SCHEMA}.historical_stats")
STATE_RULES         = _w("state_rules",         f"{CATALOG}.{PROD_SCHEMA}.state_rules")
PROD_OUTPUT_TABLE   = _w("prod_output_table",   f"{CATALOG}.{PROD_SCHEMA}.ap_tax_classified")

# Model serving + LLM + Vector Search endpoints
MODEL_ENDPOINT      = _w("model_endpoint", "ap_tax_xgb")                 # served pyfunc (your XGBoost)
LLM_ENDPOINT        = _w("llm_endpoint",   "databricks-meta-llama-3-3-70b-instruct")
VS_ENDPOINT         = _w("vs_endpoint",    "ap_tax_vs")
VS_RULES_INDEX      = _w("vs_rules_index",    f"{CATALOG}.{PROD_SCHEMA}.labeled_examples_idx")
VS_WRITEUPS_INDEX   = _w("vs_writeups_index", f"{CATALOG}.{PROD_SCHEMA}.prior_writeups_idx")

# Thresholds
RAG_SIM_THRESHOLD   = float(_w("rag_sim_threshold", "0.82"))   # accept RAG label above this
ACCEPT_CONF         = float(_w("accept_conf", "0.60"))         # ensemble accept threshold
ANOMALY_REVIEW_THR  = float(_w("anomaly_review_thr", "0.70"))  # QA → override_suggested above this

# Reroute + integration
MAX_REROUTE_PASSES  = int(_w("max_reroute_passes", "2"))
FASTAPI_WEBHOOK_URL = _w("fastapi_webhook_url", "https://your-fastapi-host/ap-tax/run-complete")

# Per-task I/O overrides (used by reroute to operate on a flagged subset).
# Empty string => task uses its default table for this RUN_ID.
INPUT_TABLE_OVERRIDE  = _w("input_table", "")
OUTPUT_TABLE_OVERRIDE = _w("output_table", "")

# COMMAND ----------
# MAGIC %md ### Column map (carried from the original single-file pipeline)

COLS = {
    "invoice_id": "INVOICE_ID", "inv_line_number": "INV_LINE_NUMBER",
    "invoice_num": "INVOICE_NUM", "accounting_date": "ACCOUNTING_DATE",
    "line_description": "LINE_DESCRIPTION", "description": "DESCRIPTION",
    "dist_all_description": "DIST_ALL_DESCRIPTION", "extc": "EXTC_CODE",
    "mic": "MIC", "account_code": "ACCOUNT_CODE", "vendor_name": "VENDOR_NAME",
    "company_code": "COMPANY_CODE", "state": "STATE", "invoice_source": "INVOICE_SOURCE",
    "tran_amount": "TRAN_AMOUNT", "use_tax_amount": "USE_TAX_AMOUNT",
}

# Canonical tax categories (= original "clusters"). ai_classify uses this list
# as its candidate labels, so KEEP IT COMPLETE / authoritative.
# TODO: replace with the full canonical list from your cluster→account map.
CATEGORIES = [
    "ERTU", "CPE", "Computer Equipments", "Miscellaneous Materials - Telecom",
    "Network Equipment", "Tower Materials", "Telecom Equipment", "Communications Equipment",
    "Freight - Common Carrier Charges", "Research and Development", "Permits",
    "Contract plant labor", "Vendor Engineering", "Freight", "Maintenance",
    "Nontaxable", "Inventory", "Operating Lease", "Software - ERTU",
    "Tools and Testing Equipment", "Safety Equipment", "Outside Plant Construction",
    "Storage Services", "Cable - Nonmetalic", "Capital Lease", "Data Processing",
    "Propane / Fuels", "Real Property Construction", "Security Service",
    "Food/Beverage", "DTV", "Landscape Services", "Installation Services - Telecom",
]

# COMMAND ----------
# MAGIC %md ### Staging-table naming + read/write helpers

def staging(name: str) -> str:
    """Fully-qualified, run-scoped staging table name, e.g. atims.atims_staging.t31_unmatched__<run>."""
    return f"{CATALOG}.{STAGING_SCHEMA}.{name}__{RUN_ID}"

def resolve_input(default_name: str) -> str:
    return INPUT_TABLE_OVERRIDE if INPUT_TABLE_OVERRIDE else staging(default_name)

def resolve_output(default_name: str) -> str:
    return OUTPUT_TABLE_OVERRIDE if OUTPUT_TABLE_OVERRIDE else staging(default_name)

def write_stage(df, fq_name: str):
    (df.write.format("delta").mode("overwrite")
       .option("overwriteSchema", "true").saveAsTable(fq_name))
    print(f"   ✓ wrote {df.count():,} rows → {fq_name}")
    return fq_name

def read_stage(fq_name):
    return spark.read.table(fq_name)

def set_task_value(key, value):
    try:
        dbutils.jobs.taskValues.set(key=key, value=value)
    except Exception:
        print(f"   (taskValues unavailable; {key}={value})")

# COMMAND ----------
# MAGIC %md ### final_description builder (verbatim port of the original logic)

def build_final_description(df):
    filler = ["SCM Purchase", "SCM PURCHASE", "scm purchase"]
    def _clean(c):
        return when(col(c).isin(filler) | col(c).isNull(), lit(None)).otherwise(col(c))
    df = (df.withColumn("_l", _clean(COLS["line_description"]))
            .withColumn("_d", _clean(COLS["description"]))
            .withColumn("_x", _clean(COLS["dist_all_description"])))
    df = df.withColumn("final_description", coalesce(
        when(col("_l").isNotNull() & col("_d").isNotNull(), concat_ws(" ", col("_l"), col("_d"))),
        col("_l"), col("_d"), col("_x"), lit(""),
    )).drop("_l", "_d", "_x")
    return df

print("✓ 00_config_common loaded · RUN_ID =", RUN_ID)
