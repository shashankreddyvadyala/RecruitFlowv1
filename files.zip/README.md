# AP Tax Classification — Agentic Databricks Workflow

Your original single-notebook pipeline (rules → XGBoost+LightGBM ensemble → KMeans
discovery → Excel) re-architected as a **single Databricks Workflow of 7 chained
notebook tasks**. The XGBoost model and the deterministic rule logic are carried
forward ("same model"); LightGBM is dropped (the binary/ABI issue), and its slot in
the ensemble is filled by an LLM (`ai_classify`) resolved by `ai_query`.

## Task DAG

```
3.1 rules_expert ─▶ 3.2 classifier ─▶ 3.3 tax_lookup ─▶ 3.3b use_tax ─▶ 3.4 tax_writer ─▶ 3.5 qa ─▶ 3.6 reroute ─▶ 3.7 write_output
   SQL JOIN +          XGB(serving)        LEFT JOIN on      conditional      prior-writeup       window-fn       re-run 3.2–3.5     MERGE→atims_prod
   Vector Search       + ai_classify       taxability_       Reverse_         RAG + ai_query      anomaly         on flagged subset  + FastAPI webhook
   RAG fallback        + ai_query resolve   matrix           UseTax           write-up gen        scoring         (max 2 passes)
```

## Files

| File | Task | Role |
|---|---|---|
| `00_config_common.py` | — | `%run` by every task. Widgets, `COLS`, `CATEGORIES`, staging-table naming, `build_final_description`. |
| `90_register_model.py` | setup | Wraps your **existing** `xgb_model.ubj` + `tfidf.pkl` + encoders as an MLflow pyfunc, registers to UC, and is served as `ap_tax_xgb`. Run once / on retrain. |
| `rules_expert_notebook.py` | 3.1 | Deterministic `rule_lookup` JOIN, then Vector Search RAG fallback. → `rules_matched`, `rag_matched`, `unmatched`. |
| `classifier_notebook.py` | 3.2 | Served XGBoost + `ai_classify` + `ai_query` resolution. → `classified` (`final_category`, `ensemble_confidence`). |
| `tax_lookup_notebook.py` | 3.3 | LEFT JOIN on `taxability_matrix`. → `taxability`, `tax_source`. |
| `use_tax_lookup_notebook.py` | 3.3b | Conditional logic. → `Reverse_UseTax` ∈ {Yes, No, null}. |
| `tax_writer_notebook.py` | 3.4 | Prior-writeup RAG + structured `ai_query`. → `short_justification`, `full_writeup`. |
| `qa_notebook.py` | 3.5 | Window-fn anomaly scoring + stats/state-rule joins. → `anomaly_score`, `review_priority`, `override_suggested`. |
| `reroute_notebook.py` | 3.6 | Re-invokes 3.2–3.5 on flagged subset, ≤ 2 passes, merges back. |
| `write_output_notebook.py` | 3.7 | MERGE into `atims_prod` + POST to FastAPI. |
| `databricks_job.yml` | — | Asset Bundle defining the DAG. |

## Data contract between tasks

Tasks do **not** pass DataFrames in memory. Each writes a run-scoped Delta table and
the next reads it. Naming: `{catalog}.{staging_schema}.{name}__{run_id}` (e.g.
`atims.atims_staging.t31_unmatched__20220101_...`). Small scalars go via
`dbutils.jobs.taskValues`. Every task also accepts `input_table` / `output_table`
widget overrides — this is what lets **3.6 reroute** run the chain on a flagged subset
without touching the main tables.

## What you must fill in before running

1. **Serve the model** — run `90_register_model.py`, then create the `ap_tax_xgb`
   serving endpoint (snippet at the bottom of that notebook).
2. **`CATEGORIES`** in `00_config_common.py` — replace the starter list with your full
   canonical cluster set. `ai_classify` uses these as its only candidate labels.
3. **Reference tables**: `rule_lookup`, `taxability_matrix` (`category, state,
   taxability, tax_source`), `historical_stats` (`category, hist_mean, hist_std`),
   `state_rules` (`state, category, flag`).
4. **Vector Search indexes**: `labeled_examples_idx` (col `category`) and
   `prior_writeups_idx` (col `full_writeup`) on endpoint `ap_tax_vs`.
5. **`fastapi_webhook_url`** widget → your FastAPI endpoint.
6. Confirm cluster **network egress** allows the FastAPI host (3.7) and that the
   serving/VS/LLM endpoints are reachable.

### Materializing `rule_lookup` (the SQL-JOIN form of your `_assign` chain)

Each original `_assign(df, condition, cluster, label)` becomes one row with a
`priority` (row order in the original chain = priority; later wins). Columns:
`priority, mic_pat, extc_pat, account_pat, vendor_pat, company_pat, desc_kw, cluster`
— any unused predicate column is `NULL` (the JOIN treats `NULL` as "no constraint").
`%`-wildcards map directly to SQL `LIKE`. Compound conditions (e.g. `MIC='COEOTHER'
AND EXTC='450'`) populate multiple predicate columns on the same row. The
`ROW_NUMBER() ... ORDER BY priority DESC` in 3.1 enforces the override semantics.

> Predicates that can't be expressed as `LIKE` (the keyword "but not X" exclusions)
> are the one place a pure JOIN falls short — handle those either as extra
> `NOT LIKE` predicate columns or by keeping that small subset as a CASE expression
> in 3.1. Flagged in the notebook.

## Run

```bash
databricks bundle deploy
databricks bundle run ap_tax_classification --params invoice_month=2022-01
```

## Notes / caveats

- **Driver collection**: 3.1 (RAG), 3.2 (XGB batch), 3.4 (writeups) call `.toPandas()`
  on the unmatched/flagged subset. Fine per-month; if a month's unmatched set is huge,
  switch XGB scoring to `mlflow.pyfunc.spark_udf` (distributed, no endpoint) and batch
  the Vector Search calls with a Pandas UDF.
- **LLM cost**: `ai_query` fires per disagreement (3.2) and per row (3.4). Watch token
  spend; consider only generating write-ups for `review_priority != LOW`.
- **`ai_query` JSON**: 3.4 asks for strict JSON and parses with `get_json_object`
  (null-safe). If your DBR supports `responseFormat`, prefer that for guaranteed schema.
- **Reroute loop**: `dbutils.notebook.run` executes child notebooks on the *current*
  cluster; the 2-pass cap prevents runaway cost. A row still flagged after pass 2 is
  published with `override_suggested = true` for human review.
