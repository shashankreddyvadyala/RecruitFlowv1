# Databricks notebook source
# MAGIC %md
# MAGIC # Task 3.3 · tax_lookup_notebook
# MAGIC LEFT JOIN the classified records onto the `taxability_matrix` (keyed by
# MAGIC `final_category` + `STATE`) to attach `taxability` and `tax_source`.
# MAGIC Misses fall back to `UNDETERMINED` so nothing is silently dropped.
# MAGIC
# MAGIC Output: `t33_tax`.

# COMMAND ----------
# MAGIC %run ./00_config_common

# COMMAND ----------
from pyspark.sql.functions import col, coalesce, lit, broadcast

IN_TABLE  = resolve_input("t32_classified")
OUT_TABLE = resolve_output("t33_tax")

classified = read_stage(IN_TABLE)

# taxability_matrix expected cols: category, state, taxability, tax_source
matrix = (spark.read.table(TAXABILITY_MATRIX)
          .select(col("category").alias("_cat"),
                  col("state").alias("_st"),
                  col("taxability").alias("_taxability"),
                  col("tax_source").alias("_tax_source")))

joined = classified.join(
    broadcast(matrix),
    (col("final_category") == col("_cat")) & (col(COLS["state"]) == col("_st")),
    "left",
)

tax_result = (joined
    .withColumn("taxability", coalesce(col("_taxability"), lit("UNDETERMINED")))
    .withColumn("tax_source",
        coalesce(col("_tax_source"),
                 when(col("_taxability").isNotNull(), lit("matrix")).otherwise(lit("unmatched"))))
    .drop("_cat", "_st", "_taxability", "_tax_source"))

undetermined = tax_result.filter(col("taxability") == "UNDETERMINED").count()
print(f"   Taxability resolved: {tax_result.count() - undetermined:,}  |  Undetermined: {undetermined:,}")

write_stage(tax_result, OUT_TABLE)
