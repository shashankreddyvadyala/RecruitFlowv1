# Databricks notebook source
# MAGIC %md
# MAGIC # Task 3.3b · use_tax_lookup_notebook
# MAGIC Pure conditional logic (no joins, no models). Decides whether a self-assessed
# MAGIC **reverse use tax** is owed, from `taxability` and `use_tax_amount`.
# MAGIC
# MAGIC Rule (adjust to your tax policy):
# MAGIC - `taxability = 'Taxable'` **and** `use_tax_amount > 0`  → `Reverse_UseTax = 'Yes'`
# MAGIC   (item is taxable but no tax was collected at source → self-assess)
# MAGIC - `taxability = 'Taxable'` **and** `use_tax_amount = 0`  → `'No'` (tax already handled)
# MAGIC - `taxability IN ('Exempt','Nontaxable')`               → `'No'`
# MAGIC - otherwise (`UNDETERMINED`/null)                        → `null` (defer to QA/review)
# MAGIC
# MAGIC Output: `t33b_use_tax`.

# COMMAND ----------
# MAGIC %run ./00_config_common

# COMMAND ----------
from pyspark.sql.functions import col, when, lit, coalesce

IN_TABLE  = resolve_input("t33_tax")
OUT_TABLE = resolve_output("t33b_use_tax")

df = read_stage(IN_TABLE)

# Ensure a numeric use_tax_amount exists (source column or default 0).
ut_col = COLS["use_tax_amount"]
if ut_col in df.columns:
    df = df.withColumn("use_tax_amount", coalesce(col(ut_col).cast("double"), lit(0.0)))
else:
    df = df.withColumn("use_tax_amount", lit(0.0))

use_tax = df.withColumn(
    "Reverse_UseTax",
    when((col("taxability") == "Taxable") & (col("use_tax_amount") > 0), lit("Yes"))
    .when((col("taxability") == "Taxable") & (col("use_tax_amount") <= 0), lit("No"))
    .when(col("taxability").isin("Exempt", "Nontaxable"), lit("No"))
    .otherwise(lit(None).cast("string"))
)

summary = use_tax.groupBy("Reverse_UseTax").count().toPandas()
print(summary.to_string(index=False))

write_stage(use_tax, OUT_TABLE)
