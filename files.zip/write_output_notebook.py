# Databricks notebook source
# MAGIC %md
# MAGIC # Task 3.7 · write_output_notebook
# MAGIC Final task. Selects the published column set, MERGE-upserts into the prod table
# MAGIC (`atims_prod`), and POSTs a completion webhook to the FastAPI service.
# MAGIC
# MAGIC Reads `t36_final` if reroute produced it, else falls back to `t35_qa`.

# COMMAND ----------
# MAGIC %run ./00_config_common

# COMMAND ----------
import requests
from delta.tables import DeltaTable
from pyspark.sql.functions import lit, current_timestamp

final_tbl = staging("t36_final")
if not spark.catalog.tableExists(final_tbl):
    final_tbl = staging("t35_qa")
df = read_stage(final_tbl)
print(f"   Source: {final_tbl}  ({df.count():,} rows)")

# COMMAND ----------
# MAGIC %md ### 1. Shape the published record

published_cols = [
    COLS["invoice_id"], COLS["inv_line_number"], COLS["invoice_num"],
    COLS["accounting_date"], COLS["vendor_name"], COLS["state"],
    COLS["extc"], COLS["mic"], COLS["account_code"], COLS["tran_amount"],
    "final_description", "final_category", "ensemble_confidence", "decision_path",
    "taxability", "tax_source", "use_tax_amount", "Reverse_UseTax",
    "short_justification", "full_writeup",
    "anomaly_score", "review_priority", "override_suggested",
]
out = (df.select(*[c for c in published_cols if c in df.columns])
         .withColumn("run_id", lit(RUN_ID))
         .withColumn("invoice_month", lit(INVOICE_MONTH))
         .withColumn("processed_at", current_timestamp()))

# COMMAND ----------
# MAGIC %md ### 2. MERGE-upsert into prod (idempotent on key + run_id)

if not spark.catalog.tableExists(PROD_OUTPUT_TABLE):
    out.limit(0).write.format("delta").saveAsTable(PROD_OUTPUT_TABLE)

tgt = DeltaTable.forName(spark, PROD_OUTPUT_TABLE)
(tgt.alias("t").merge(
        out.alias("s"),
        f"t.{COLS['invoice_id']} = s.{COLS['invoice_id']} AND "
        f"t.{COLS['inv_line_number']} = s.{COLS['inv_line_number']}")
    .whenMatchedUpdateAll()
    .whenNotMatchedInsertAll()
    .execute())
print(f"   ✓ merged into {PROD_OUTPUT_TABLE}")

# COMMAND ----------
# MAGIC %md ### 3. Completion webhook → FastAPI

counts = {r["review_priority"]: r["count"]
          for r in out.groupBy("review_priority").count().collect()}
payload = {
    "run_id": RUN_ID,
    "invoice_month": INVOICE_MONTH,
    "total_rows": out.count(),
    "prod_table": PROD_OUTPUT_TABLE,
    "review_priority_counts": counts,
    "status": "complete",
}
try:
    resp = requests.post(FASTAPI_WEBHOOK_URL, json=payload, timeout=30)
    print(f"   Webhook → {FASTAPI_WEBHOOK_URL}  [{resp.status_code}]")
except Exception as e:
    print(f"   ⚠ Webhook failed (non-fatal): {e}")

set_task_value("prod_table", PROD_OUTPUT_TABLE)
set_task_value("total_rows", payload["total_rows"])
print("\n" + "="*56 + f"\n  PIPELINE COMPLETE · {INVOICE_MONTH} · run {RUN_ID}\n" + "="*56)
