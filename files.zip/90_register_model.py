# Databricks notebook source
# MAGIC %md
# MAGIC # 90 · Register the original model as a served pyfunc  (one-time / on retrain)
# MAGIC This is the bridge for "same model". It loads your **existing** artifacts
# MAGIC (`xgb_model.ubj`, `tfidf.pkl`, `cat_encoders.pkl`, `label_encoder.pkl`),
# MAGIC bundles the feature engineering INSIDE an `mlflow.pyfunc` model, registers it
# MAGIC to Unity Catalog, and (re)creates a serving endpoint. After this runs,
# MAGIC Task 3.2 can call the endpoint with raw columns — no feature plumbing over HTTP.
# MAGIC
# MAGIC > LightGBM is intentionally dropped here (binary/ABI incompatibility on the
# MAGIC > cluster). The served ensemble is XGBoost + LLM `ai_classify`, resolved by `ai_query`.

# COMMAND ----------
# MAGIC %run ./00_config_common

# COMMAND ----------
# MAGIC %pip install mlflow xgboost scikit-learn
# MAGIC %restart_python

# COMMAND ----------
import hashlib, pickle, numpy as np, pandas as pd, mlflow, mlflow.pyfunc
from xgboost import XGBClassifier

ARTIFACT_DIR = "/dbfs/models/ap_tax"   # where your original artifacts live
REGISTERED_NAME = f"{CATALOG}.{PROD_SCHEMA}.ap_tax_xgb"

# COMMAND ----------
# MAGIC %md ### pyfunc wrapper — feature engineering carried over verbatim

class APTaxModel(mlflow.pyfunc.PythonModel):
    CAT_COLS = ["EXTC_CODE", "MIC", "COMPANY_CODE", "STATE", "INVOICE_SOURCE"]

    def load_context(self, context):
        self.xgb = XGBClassifier(); self.xgb.load_model(context.artifacts["xgb"])
        with open(context.artifacts["tfidf"], "rb") as f:        self.tfidf = pickle.load(f)
        with open(context.artifacts["cat_encoders"], "rb") as f: self.cat_encoders = pickle.load(f)
        with open(context.artifacts["label_encoder"], "rb") as f: self.label_enc = pickle.load(f)

    @staticmethod
    def _hash_vendor(name, n_bins=5000):
        return int(hashlib.md5(str(name).encode()).hexdigest(), 16) % n_bins

    def _features(self, pdf):
        X_text = self.tfidf.transform(pdf["final_description"].fillna("").astype(str)).toarray().astype(np.float32)
        cat_parts = []
        for c in self.CAT_COLS:
            vals = pdf[c].fillna("UNKNOWN").astype(str).values
            known = set(self.cat_encoders[c].classes_)
            vals = np.array([v if v in known else "UNKNOWN" for v in vals])
            cat_parts.append(self.cat_encoders[c].transform(vals).reshape(-1, 1).astype(np.float32))
        vh = pdf["VENDOR_NAME"].fillna("").apply(self._hash_vendor).values.reshape(-1, 1).astype(np.float32)
        amt = np.log1p(np.abs(pdf["TRAN_AMOUNT"].fillna(0).astype(float).values)).reshape(-1, 1).astype(np.float32)
        return np.hstack([X_text] + cat_parts + [vh, amt])

    def predict(self, context, model_input: pd.DataFrame):
        X = self._features(model_input)
        proba = self.xgb.predict_proba(X)
        idx = np.argmax(proba, axis=1)
        return pd.DataFrame({
            "xgb_category":   self.label_enc.inverse_transform(idx),
            "xgb_confidence": proba[np.arange(len(proba)), idx].astype(float),
        })

# COMMAND ----------
# MAGIC %md ### Log + register

mlflow.set_registry_uri("databricks-uc")
with mlflow.start_run(run_name=f"ap_tax_register_{RUN_ID}"):
    info = mlflow.pyfunc.log_model(
        artifact_path="model",
        python_model=APTaxModel(),
        artifacts={
            "xgb":           f"{ARTIFACT_DIR}/xgb_model.ubj",
            "tfidf":         f"{ARTIFACT_DIR}/tfidf.pkl",
            "cat_encoders":  f"{ARTIFACT_DIR}/cat_encoders.pkl",
            "label_encoder": f"{ARTIFACT_DIR}/label_encoder.pkl",
        },
        pip_requirements=["xgboost", "scikit-learn", "pandas", "numpy"],
        registered_model_name=REGISTERED_NAME,
    )
print("Registered:", info.model_uri)

# COMMAND ----------
# MAGIC %md
# MAGIC ### Serve it
# MAGIC Create a Serving endpoint named `MODEL_ENDPOINT` (default `ap_tax_xgb`) pointing
# MAGIC at the latest version of `REGISTERED_NAME`, via the Serving UI or the SDK:
# MAGIC ```python
# MAGIC from databricks.sdk import WorkspaceClient
# MAGIC from databricks.sdk.service.serving import EndpointCoreConfigInput, ServedEntityInput
# MAGIC w = WorkspaceClient()
# MAGIC w.serving_endpoints.create_and_wait(
# MAGIC     name=MODEL_ENDPOINT,
# MAGIC     config=EndpointCoreConfigInput(served_entities=[ServedEntityInput(
# MAGIC         entity_name=REGISTERED_NAME, entity_version="1",
# MAGIC         workload_size="Small", scale_to_zero_enabled=True)]))
# MAGIC ```
