# Databricks notebook source
# MAGIC %md
# MAGIC # Task 3.5 · qa_notebook
# MAGIC Anomaly detection on the classified output. Uses window functions for
# MAGIC vendor-category consistency and per-category amount z-scores, joined against
# MAGIC `historical_stats` and `state_rules`. Emits `anomaly_score`, `review_priority`,
# MAGIC and `override_suggested` (consumed by Task 3.6 reroute).
# MAGIC
# MAGIC Output: `t35_qa`.

# COMMAND ----------
# MAGIC %run ./00_config_common

# COMMAND ----------
from pyspark.sql import Window
from pyspark.sql.functions import (col, count, avg, stddev, abs as sabs, when, lit,
                                    coalesce, broadcast, greatest)

IN_TABLE  = resolve_input("t34_writeup")
OUT_TABLE = resolve_output("t35_qa")

df = read_stage(IN_TABLE)

# COMMAND ----------
# MAGIC %md ### 1. Vendor consistency — does this vendor usually get this category?

vendor_win = Window.partitionBy(COLS["vendor_name"])
vendor_cat_win = Window.partitionBy(COLS["vendor_name"], "final_category")

df = (df
    .withColumn("_vendor_n",      count(lit(1)).over(vendor_win))
    .withColumn("_vendor_cat_n",  count(lit(1)).over(vendor_cat_win))
    .withColumn("vendor_cat_share", col("_vendor_cat_n") / col("_vendor_n")))
# Low share for a frequently-seen vendor = inconsistent → higher anomaly
df = df.withColumn("_vendor_inconsistency",
        when(col("_vendor_n") >= 10, lit(1.0) - col("vendor_cat_share")).otherwise(lit(0.0)))

# COMMAND ----------
# MAGIC %md ### 2. Amount z-score within category (this run) + vs historical stats

cat_win = Window.partitionBy("final_category")
df = (df
    .withColumn("_cat_mean", avg(col(COLS["tran_amount"]).cast("double")).over(cat_win))
    .withColumn("_cat_std",  stddev(col(COLS["tran_amount"]).cast("double")).over(cat_win)))
df = df.withColumn("amount_zscore",
        when(col("_cat_std") > 0,
             sabs((col(COLS["tran_amount"]).cast("double") - col("_cat_mean")) / col("_cat_std")))
        .otherwise(lit(0.0)))

# Optional: blend with historical category stats if the table exists.
if spark.catalog.tableExists(HISTORICAL_STATS):
    hist = (spark.read.table(HISTORICAL_STATS)
            .select(col("category").alias("_hcat"),
                    col("hist_mean").alias("_hmean"),
                    col("hist_std").alias("_hstd")))
    df = df.join(broadcast(hist), col("final_category") == col("_hcat"), "left")
    df = df.withColumn("amount_zscore_hist",
            when(col("_hstd") > 0,
                 sabs((col(COLS["tran_amount"]).cast("double") - col("_hmean")) / col("_hstd")))
            .otherwise(lit(0.0)))
    df = df.withColumn("amount_zscore", greatest("amount_zscore", "amount_zscore_hist")) \
           .drop("_hcat", "_hmean", "_hstd", "amount_zscore_hist")

# COMMAND ----------
# MAGIC %md ### 3. State-rule violations (e.g., category illegal/atypical in a state)

if spark.catalog.tableExists(STATE_RULES):
    # state_rules cols: state, category, flag (1 = disallowed/atypical)
    sr = (spark.read.table(STATE_RULES)
          .select(col("state").alias("_sst"), col("category").alias("_scat"),
                  col("flag").alias("_sflag")))
    df = df.join(broadcast(sr),
                 (col(COLS["state"]) == col("_sst")) & (col("final_category") == col("_scat")),
                 "left")
    df = df.withColumn("_state_violation", coalesce(col("_sflag").cast("double"), lit(0.0))) \
           .drop("_sst", "_scat", "_sflag")
else:
    df = df.withColumn("_state_violation", lit(0.0))

# COMMAND ----------
# MAGIC %md
# MAGIC ### 4. Composite anomaly score → review priority + override flag
# MAGIC Weighted blend, squashed to [0,1]. Low ensemble confidence and undetermined
# MAGIC taxability also push the score up.

df = df.withColumn("_low_conf", when(col("ensemble_confidence") < ACCEPT_CONF, lit(1.0)).otherwise(lit(0.0)))
df = df.withColumn("_undet",    when(col("taxability") == "UNDETERMINED", lit(1.0)).otherwise(lit(0.0)))

from pyspark.sql.functions import least
_raw_score = (col("_vendor_inconsistency") * 0.30
              + (col("amount_zscore") / lit(4.0)) * 0.30
              + col("_state_violation") * 0.20
              + col("_low_conf") * 0.10
              + col("_undet") * 0.10)
df = df.withColumn("anomaly_score", least(lit(1.0), _raw_score))

df = df.withColumn("review_priority",
        when(col("anomaly_score") >= 0.80, lit("HIGH"))
        .when(col("anomaly_score") >= ANOMALY_REVIEW_THR, lit("MEDIUM"))
        .otherwise(lit("LOW")))

df = df.withColumn("override_suggested",
        col("anomaly_score") >= ANOMALY_REVIEW_THR)

qa = df.drop("_vendor_n", "_vendor_cat_n", "_vendor_inconsistency",
             "_cat_mean", "_cat_std", "_state_violation", "_low_conf", "_undet")

flagged = qa.filter(col("override_suggested")).count()
print(f"   override_suggested: {flagged:,} / {qa.count():,}")
write_stage(qa, OUT_TABLE)
set_task_value("flagged_count", flagged)
