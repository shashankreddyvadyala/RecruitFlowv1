# Databricks notebook source
# MAGIC %md
# MAGIC # Task 3.0 · model_notebook  — train → register → serve  (END TO END)
# MAGIC **The pipeline goes through this every run.**
# MAGIC - `retrain=false` (default): verify the registered model + serving endpoint are
# MAGIC   live, point the endpoint at the latest version, and smoke-test it. No training.
# MAGIC - `retrain=true`: re-train XGBoost on rule-labeled history, save artifacts,
# MAGIC   register a new Unity Catalog version, then update + smoke-test the endpoint.
# MAGIC
# MAGIC **"Same model":** identical features (TF-IDF + categorical + vendor-hash +
# MAGIC log-amount) and identical XGBoost params as the original pipeline.
# MAGIC LightGBM is dropped (binary/ABI incompatibility on the cluster).
# MAGIC
# MAGIC Steps:  1 load+label → 2 features → 3 train → 4 evaluate → 5 save →
# MAGIC 6 register → 7 ensure endpoint → 8 smoke-test

# COMMAND ----------
# MAGIC %pip install mlflow xgboost scikit-learn
# MAGIC %restart_python

# COMMAND ----------
# MAGIC %run ./00_config_common
# MAGIC %md  (re-run AFTER %restart_python so config survives the interpreter restart)

# COMMAND ----------
import os, pickle, hashlib, numpy as np, pandas as pd, mlflow, mlflow.pyfunc
from xgboost import XGBClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score
from pyspark.sql.functions import col

RETRAIN         = _w("retrain", "false").strip().lower() == "true"
ARTIFACT_DIR    = "/dbfs/models/ap_tax"                       # raw artifacts (carried over)
REGISTERED_NAME = f"{CATALOG}.{PROD_SCHEMA}.ap_tax_xgb"        # UC model name

# Features + hyperparameters — carried verbatim from the original pipeline.
CAT_COLS = ["EXTC_CODE", "MIC", "COMPANY_CODE", "STATE", "INVOICE_SOURCE"]
MODEL_CONFIG = {
    "max_training_rows": 50_000, "min_class_samples": 10,
    "test_size": 0.20, "random_seed": 42, "tfidf_max_features": 10_000,
    "xgb_params": {"n_estimators": 300, "max_depth": 6, "learning_rate": 0.05,
        "subsample": 0.8, "colsample_bytree": 0.8, "eval_metric": "mlogloss",
        "tree_method": "hist", "grow_policy": "lossguide", "random_state": 42, "n_jobs": -1},
}
print(f"   RETRAIN = {RETRAIN}   model = {REGISTERED_NAME}   endpoint = {MODEL_ENDPOINT}")

# COMMAND ----------
# MAGIC %md ### Shared feature builders (train-time fit + serve-time transform must match)

def _hash_vendor(name, n_bins=5000):
    return int(hashlib.md5(str(name).encode()).hexdigest(), 16) % n_bins

def build_feature_matrix(pdf, tfidf=None, cat_encoders=None, fit=False):
    texts = pdf["final_description"].fillna("").astype(str).tolist()
    if fit:
        tfidf = TfidfVectorizer(max_features=MODEL_CONFIG["tfidf_max_features"],
                                ngram_range=(1, 2), sublinear_tf=True, min_df=2, analyzer="word")
        X_text = tfidf.fit_transform(texts).toarray().astype(np.float32)
        cat_encoders = {}
    else:
        X_text = tfidf.transform(texts).toarray().astype(np.float32)
    cat_parts = []
    for c in CAT_COLS:
        vals = pdf[c].fillna("UNKNOWN").astype(str).values
        if fit:
            enc = LabelEncoder(); enc.fit(np.append(vals, "UNKNOWN")); cat_encoders[c] = enc
        else:
            enc = cat_encoders[c]; known = set(enc.classes_)
            vals = np.array([v if v in known else "UNKNOWN" for v in vals])
        cat_parts.append(enc.transform(vals).reshape(-1, 1).astype(np.float32))
    vh = pdf[COLS["vendor_name"]].fillna("").apply(_hash_vendor).values.reshape(-1, 1).astype(np.float32)
    amt = np.log1p(np.abs(pdf[COLS["tran_amount"]].fillna(0).astype(float).values)).reshape(-1, 1).astype(np.float32)
    X = np.hstack([X_text] + cat_parts + [vh, amt])
    return X, tfidf, cat_encoders

# COMMAND ----------
# MAGIC %md ### pyfunc wrapper — feature engineering bundled INSIDE the served model

class APTaxModel(mlflow.pyfunc.PythonModel):
    CAT_COLS = ["EXTC_CODE", "MIC", "COMPANY_CODE", "STATE", "INVOICE_SOURCE"]  # must match training
    def load_context(self, context):
        self.xgb = XGBClassifier(); self.xgb.load_model(context.artifacts["xgb"])
        with open(context.artifacts["tfidf"], "rb") as f:         self.tfidf = pickle.load(f)
        with open(context.artifacts["cat_encoders"], "rb") as f:  self.cat_encoders = pickle.load(f)
        with open(context.artifacts["label_encoder"], "rb") as f: self.label_enc = pickle.load(f)
    @staticmethod
    def _hash_vendor(name, n_bins=5000):
        return int(hashlib.md5(str(name).encode()).hexdigest(), 16) % n_bins
    def _features(self, pdf):
        X_text = self.tfidf.transform(pdf["final_description"].fillna("").astype(str)).toarray().astype(np.float32)
        parts = []
        for c in self.CAT_COLS:
            vals = pdf[c].fillna("UNKNOWN").astype(str).values
            known = set(self.cat_encoders[c].classes_)
            vals = np.array([v if v in known else "UNKNOWN" for v in vals])
            parts.append(self.cat_encoders[c].transform(vals).reshape(-1, 1).astype(np.float32))
        vh = pdf["VENDOR_NAME"].fillna("").apply(self._hash_vendor).values.reshape(-1, 1).astype(np.float32)
        amt = np.log1p(np.abs(pdf["TRAN_AMOUNT"].fillna(0).astype(float).values)).reshape(-1, 1).astype(np.float32)
        return np.hstack([X_text] + parts + [vh, amt])
    def predict(self, context, model_input: pd.DataFrame):
        X = self._features(model_input); proba = self.xgb.predict_proba(X)
        idx = np.argmax(proba, axis=1)
        return pd.DataFrame({"xgb_category": self.label_enc.inverse_transform(idx),
                             "xgb_confidence": proba[np.arange(len(proba)), idx].astype(float)})

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 1 · Load + label training data  (rule-labeled history)
# MAGIC Same design as the original: the deterministic rules ARE the training labels.
# MAGIC We apply the `rule_lookup` JOIN (identical to Task 3.1) to historical data and
# MAGIC keep the rule-matched rows. Target = `final_category` (the cluster).

if RETRAIN:
    _hist_tbl = _w("historical_table", "")
    train_src = _hist_tbl if _hist_tbl else SOURCE_TABLE
    hist = build_final_description(spark.read.format("delta").load(train_src))
    hist.createOrReplaceTempView("hist_lines")
    labeled = spark.sql(f"""
      WITH ranked AS (
        SELECT l.*, r.cluster AS final_category,
               ROW_NUMBER() OVER (
                 PARTITION BY l.{COLS['invoice_id']}, l.{COLS['inv_line_number']}
                 ORDER BY r.priority DESC) AS rk
        FROM hist_lines l
        JOIN {RULES_LOOKUP_TABLE} r
          ON (r.mic_pat     IS NULL OR l.{COLS['mic']}          LIKE r.mic_pat)
         AND (r.extc_pat    IS NULL OR l.{COLS['extc']}         LIKE r.extc_pat)
         AND (r.account_pat IS NULL OR l.{COLS['account_code']} LIKE r.account_pat)
         AND (r.vendor_pat  IS NULL OR l.{COLS['vendor_name']}  LIKE r.vendor_pat)
         AND (r.company_pat IS NULL OR l.{COLS['company_code']} LIKE r.company_pat)
         AND (r.desc_kw     IS NULL OR lower(l.final_description) LIKE lower(r.desc_kw))
      ) SELECT * FROM ranked WHERE rk = 1
    """)
    feat_cols = ["final_description", "final_category"] + CAT_COLS + [COLS["vendor_name"], COLS["tran_amount"]]
    df_lab = labeled.select(*[c for c in feat_cols if c in labeled.columns]).dropna(subset=["final_category"])
    print(f"   Rule-labeled rows: {df_lab.count():,}")

# COMMAND ----------
# MAGIC %md ## Step 2 · Feature matrix  (drop rare classes, cap rows, fit TF-IDF + encoders)

if RETRAIN:
    from pyspark.sql.functions import count as _count
    valid = [r["final_category"] for r in df_lab.groupBy("final_category").agg(_count("*").alias("n"))
                                            .filter(col("n") >= MODEL_CONFIG["min_class_samples"]).collect()]
    df_lab = df_lab.filter(col("final_category").isin(valid))
    n = df_lab.count()
    if n > MODEL_CONFIG["max_training_rows"]:
        df_lab = df_lab.sample(fraction=MODEL_CONFIG["max_training_rows"]/n, seed=MODEL_CONFIG["random_seed"])
    pdf = df_lab.toPandas()
    if len(pdf) > MODEL_CONFIG["max_training_rows"]:
        pdf = pdf.sample(n=MODEL_CONFIG["max_training_rows"], random_state=MODEL_CONFIG["random_seed"]).reset_index(drop=True)
    label_enc = LabelEncoder(); y = label_enc.fit_transform(pdf["final_category"].astype(str))
    X, tfidf, cat_encoders = build_feature_matrix(pdf, fit=True)
    print(f"   Training matrix: {X.shape[0]:,} × {X.shape[1]:,}  ·  classes: {len(label_enc.classes_)}")

# COMMAND ----------
# MAGIC %md ## Step 3 · Train XGBoost  (original params; LightGBM dropped)

if RETRAIN:
    min_count = np.bincount(y).min()
    strat = y if min_count >= 2 else None
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=MODEL_CONFIG["test_size"],
                                              random_state=MODEL_CONFIG["random_seed"], stratify=strat)
    # Re-index labels to those present in train (handles a class landing only in test).
    tr_enc = LabelEncoder().fit(y_tr); y_tr = tr_enc.transform(y_tr)
    mask = np.isin(y_te, tr_enc.classes_); X_te, y_te = X_te[mask], tr_enc.transform(y_te[mask])
    label_enc.classes_ = label_enc.classes_[tr_enc.classes_]
    n_classes = len(label_enc.classes_)
    xgb = XGBClassifier(**MODEL_CONFIG["xgb_params"], objective="multi:softprob", num_class=n_classes)
    xgb.fit(X_tr, y_tr, eval_set=[(X_te, y_te)], verbose=50)

# COMMAND ----------
# MAGIC %md ## Step 4 · Evaluate

if RETRAIN:
    pred = xgb.predict(X_te)
    acc = accuracy_score(y_te, pred); f1 = f1_score(y_te, pred, average="weighted", zero_division=0)
    print(f"   XGBoost  acc={acc:.4f}  f1={f1:.4f}  (test rows: {len(X_te):,})")

# COMMAND ----------
# MAGIC %md ## Step 5 · Save raw artifacts to DBFS

if RETRAIN:
    os.makedirs(ARTIFACT_DIR, exist_ok=True)
    xgb.save_model(f"{ARTIFACT_DIR}/xgb_model.ubj")
    with open(f"{ARTIFACT_DIR}/tfidf.pkl", "wb") as f:         pickle.dump(tfidf, f)
    with open(f"{ARTIFACT_DIR}/cat_encoders.pkl", "wb") as f:  pickle.dump(cat_encoders, f)
    with open(f"{ARTIFACT_DIR}/label_encoder.pkl", "wb") as f: pickle.dump(label_enc, f)
    print(f"   Saved artifacts → {ARTIFACT_DIR}")

# COMMAND ----------
# MAGIC %md ## Step 6 · Register pyfunc to Unity Catalog

if RETRAIN:
    mlflow.set_registry_uri("databricks-uc")
    with mlflow.start_run(run_name=f"ap_tax_train_{RUN_ID}"):
        mlflow.log_metrics({"acc": float(acc), "f1": float(f1)})
        info = mlflow.pyfunc.log_model(
            artifact_path="model", python_model=APTaxModel(),
            artifacts={"xgb": f"{ARTIFACT_DIR}/xgb_model.ubj", "tfidf": f"{ARTIFACT_DIR}/tfidf.pkl",
                       "cat_encoders": f"{ARTIFACT_DIR}/cat_encoders.pkl",
                       "label_encoder": f"{ARTIFACT_DIR}/label_encoder.pkl"},
            pip_requirements=["xgboost", "scikit-learn", "pandas", "numpy"],
            registered_model_name=REGISTERED_NAME)
    print(f"   Registered: {info.model_uri}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 7 · Ensure serving endpoint points at the latest version  (ALWAYS runs)

from mlflow import MlflowClient
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import EndpointCoreConfigInput, ServedEntityInput

mlflow.set_registry_uri("databricks-uc")
versions = MlflowClient().search_model_versions(f"name='{REGISTERED_NAME}'")
if not versions:
    raise RuntimeError(
        f"No registered model '{REGISTERED_NAME}'. Run this notebook once with "
        f"retrain=true before inference.")
latest = str(max(int(v.version) for v in versions))
print(f"   Latest version: {latest}")

w = WorkspaceClient()
served = [ServedEntityInput(entity_name=REGISTERED_NAME, entity_version=latest,
                            workload_size="Small", scale_to_zero_enabled=True)]
try:
    w.serving_endpoints.get(MODEL_ENDPOINT)
    w.serving_endpoints.update_config_and_wait(name=MODEL_ENDPOINT, served_entities=served)
    print(f"   Updated endpoint '{MODEL_ENDPOINT}' → v{latest}")
except Exception:
    w.serving_endpoints.create_and_wait(name=MODEL_ENDPOINT,
        config=EndpointCoreConfigInput(served_entities=served))
    print(f"   Created endpoint '{MODEL_ENDPOINT}' → v{latest}")

# COMMAND ----------
# MAGIC %md ## Step 8 · Smoke-test the live endpoint  (ALWAYS runs)

from mlflow.deployments import get_deploy_client
sample = pd.DataFrame([{
    "final_description": "fiber optic cable installation", COLS["extc"]: "455",
    COLS["mic"]: "FBR10K", COLS["company_code"]: "SS00", COLS["state"]: "TX",
    COLS["invoice_source"]: "AP", COLS["vendor_name"]: "JK COMMUNICATIONS",
    COLS["tran_amount"]: 12500.0,
}])
import json as _json
resp = get_deploy_client("databricks").predict(
    endpoint=MODEL_ENDPOINT,
    inputs={"dataframe_split": _json.loads(sample.to_json(orient="split"))})
pred0 = resp["predictions"][0]
assert "xgb_category" in pred0 and "xgb_confidence" in pred0, f"Bad schema: {pred0}"
print(f"   ✓ Endpoint live. Sample → {pred0}")
set_task_value("model_version", latest)
print("\n" + "="*56 + f"\n  MODEL READY · v{latest} · endpoint {MODEL_ENDPOINT}\n" + "="*56)
