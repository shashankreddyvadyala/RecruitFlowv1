# ATIMS Non-NORAD Classification — Existing-Model Pipeline

This packages the **architecture-document pipeline** (the Phase-3 data flow) on
top of the **existing trained model**, as requested:

> Keep the model and MLflow exactly the same — don't change anything in the
> model. Use `ai_classify()` and `ai_query()`. Follow the Phase 3 data flow.

The model layer (TF-IDF features, the XGBoost+LightGBM ensemble, the DBFS
artifacts, the rules engine) is ported **verbatim** into `atims_common.py` and
is never retrained or swapped. `ai_classify()` and `ai_query()` are added as the
architecture draws them — they are Foundation Model API **SQL functions on your
cluster**, not part of the trained model. GTE-Large and Vector Search are *not*
used (the model keeps its TF-IDF features), so the data flow's Vector-Search
steps are omitted; everything `ai_classify`/`ai_query` is fully wired.

## Task DAG

```
t30 ingest/prep → t31 rules → t32 classifier → t33 tax lookup →
t33b use-tax → t34 tax writer → t35 QA → t36 reroute/finalize → t37 write+notify
```

| Task | File | Role |
|------|------|------|
| t30  | `t30_ingest_prep.py`     | Read VMAP_FACT_TABLE, month filter, build `final_description` |
| t31  | `t31_rules_expert.py`    | Rules engine (keyword + generic + Parker-Volpe) → rule / no_rule |
| t32  | `t32_classifier.py`      | **Existing ensemble (Sub-model A) + `ai_classify` (Sub-model B) + `ai_query` resolution** |
| t33  | `t33_tax_lookup.py`      | LEFT JOIN to taxability matrix; null → HIGH review |
| t33b | `t33b_use_tax_lookup.py` | `Reverse_UseTax` CASE logic |
| t34  | `t34_tax_writer.py`      | Write-ups via **`ai_query`** (GPT-4o) |
| t35  | `t35_qa.py`              | Six Spark window/statistical checks |
| t36  | `t36_reroute.py`         | Escalation/finalize (see note below) |
| t37  | `t37_write_output.py`    | Write prod Delta + MLflow metrics + Excel report + webhook |

Shared code: `atims_common.py`. Job spec: `atims_workflow.json`.

## How the Phase 3 data flow maps here

| Data-flow component | This pipeline |
|---|---|
| Sub-model A — XGBoost (on `gte_embedding`) | **Existing TF-IDF + XGB+LGB ensemble**, unchanged. Predicts `final_pred`/`final_conf`. |
| Sub-model B — `ai_classify()` | **`ai_classify(final_description, array(<labels>))`** → `llm_pred` (t32) |
| Agreement: both agree + conf>0.8 → ACCEPT; low → MEDIUM; disagree → `ai_query` | Implemented exactly — agreement in category space; disagreements get `ai_query` GPT-4o resolution (t32) |
| Tax Writer — `ai_query` + Vector-Search RAG | **`ai_query`** write-up (t34); **RAG omitted** (needs GTE/Vector Search) |
| Rules Expert Vector-Search fallback | **Omitted** — deterministic rules only (model keeps TF-IDF) |
| Re-route iterative LLM passes | Single escalation pass (re-running the deterministic ensemble is a no-op) |

## Preserved verbatim vs. the one thing I changed

- **Preserved:** all model/feature/rules logic, including the known
  brittle `_parse_parker_volpe` row offsets and the rule-priority quirk where a
  later `MIC like "CEQ%"` overwrites an earlier exact `MIC == "CEQ"`. Left as-is
  per "everything same" — flag for a separate cleanup if you want it.
- **Fixed (one structural bug):** the legacy ML join keyed on `INVOICE_ID`
  alone, which fans out multi-line invoices into a cartesian product. In a
  Delta-staged pipeline that silently corrupts the output table, so `t32` now
  joins on `INVOICE_ID + INV_LINE_NUMBER`. The model is untouched — only the
  join key changed.

## Wiring TODOs before a real run (edit `atims_common.py`)

1. **`CATALOG` / `PROD_TABLE`** — set to your dev vs prod targets.
2. **`LLM_ENDPOINT`** — Foundation Model endpoint for `ai_query` (default
   `databricks-gpt-4o`). `ai_classify` uses the workspace default FM endpoint.
3. **`CATEGORY_LABELS`** — seeded with 33 names from the rules engine; **replace
   with your full ~120 categories** so `ai_classify` has the real label space.
4. **`ACCOUNT_TO_CATEGORY`** — the existing model predicts an **account code**;
   `ai_classify` returns a **category name**. Set this table (`account_code`,
   `category`) so the two share a comparison space. **If left None, model_category
   = the account code, so most no_rule rows "disagree" and fall through to
   `ai_query` resolution** — correct, but it makes `ai_query` run on ~all no_rule
   rows instead of the architecture's ~10–15%. Wire the map to control LLM cost.
5. **`TAXABILITY_MATRIX`** — `t33` joins on `final_category` (rule cluster /
   agreed category / `ai_query`-resolved category) + state. Key your matrix to
   match. Unmatched → NULL → HIGH review (the architecture's fallback).
6. **`USE_TAX_COL`** — use-tax column name. Absent → `Reverse_UseTax` NULL
   (DEFERRED branch; confirm NULL-vs-data-gap treatment with the client).
7. **`HISTORICAL_STATS` / `STATE_RULES`** — optional QA reference tables
   (checks 3 and 5). Unset → those checks return 0 (no false flags).
8. **`WEBHOOK_URL`** — FastAPI completion endpoint. Unset → notify skipped.
9. **DBFS model paths in `PATHS`** — already point at the existing artifacts.
10. **Cluster** — you provide it. `atims_workflow.json` has
    `existing_cluster_id: "REPLACE_WITH_YOUR_CLUSTER_ID"` on each task; set it
    (or attach a cluster in the Workflows UI). The cluster must have Foundation
    Model APIs / `ai_classify` + `ai_query` enabled.

## Deploy

1. Put all files in one **Databricks Repo / Git folder** (so `import
   atims_common` resolves as a sibling module).
2. Import `atims_workflow.json` via **Workflows → Create → JSON**, or
   `databricks jobs create --json @atims_workflow.json`.
3. Run with parameter `invoice_month=YYYY-MM`.

## Carried-over caveats (model-level, unchanged by design)

- **Train/serve mismatch:** the model was trained only on rule-matched rows but
  runs only on no_rule rows — reported acc/f1 measure in-rule performance, not
  the served population.
- **QA Check 4** (rule vs classifier conflict) is dormant: the classifier never
  runs on rule rows, so there's no prediction to compare. Enable a shadow
  prediction pass in `t32` if you want it live.
- **TF-IDF densification** (`.toarray()`) collects to the driver — the known
  memory ceiling at 100K×10k. This is inherent to the existing model.

## Static verification (this build)

- `py_compile`: all 10 `.py` files pass.
- `pyflakes`: clean apart from Databricks-injected `spark`/`dbutils`.
- `ai_classify` + `ai_query` SQL: paren- and quote-balanced; labels apostrophe-safe.
- DAG contract: read→write hand-off chain verified end to end.
- Constraint check: GTE-Large / Vector Search excluded; `ai_classify` + `ai_query` present per the data flow.

## Validated end-to-end locally (`tests/run_local.py`)

Ran the actual task files t30→t37 in order on a local Spark with sample data,
throwaway artifacts trained via the production feature pipeline, and
`ai_classify`/`ai_query`/`dbutils` stubbed (Delta and the Foundation Model API
aren't reachable offline). Result on 100 sample line items (incl. multi-line
invoices):

- 100 source rows → **100 prod rows** — the line-grain join fix holds (no fan-out)
- rules path 60, ML path 40; disagreements correctly routed through `ai_query`
- `taxability` populated via the matrix join; `Reverse_UseTax` Yes/No correct
- QA escalated 22 rows to HIGH; `full_writeup` and `final_category` non-null on every row

Run it yourself (needs `pyspark`, `xgboost`, `lightgbm`, `scikit-learn`,
`openpyxl`): `python3 tests/run_local.py`. On a real Databricks cluster the
stubs are unnecessary — `ai_classify`/`ai_query` and Delta resolve natively.
