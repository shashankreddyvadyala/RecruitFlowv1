# Databricks notebook source
# t33b_use_tax_lookup.py
# -----------------------------------------------------------------------------
# TASK 3.3b — Use Tax Lookup (pure Spark withColumn logic). No model, no LLM.
# Direct port of the architecture's Reverse_UseTax CASE expression.
#
# Needs a use_tax_amount column. The legacy fact table / COLS has none, so if
# ac.USE_TAX_COL is absent the amount is treated as NULL -> Reverse_UseTax NULL,
# which matches the architecture's explicitly-DEFERRED branch
# ("confirm NULL use_tax_amount treatment with client").
# -----------------------------------------------------------------------------
import atims_common as ac
from pyspark.sql.functions import col, lit, when

# COMMAND ----------

spark = ac.get_spark()
df    = ac.read_stage(ac.T["taxed"], spark)

if ac.USE_TAX_COL in df.columns:
    use_tax = col(ac.USE_TAX_COL).cast("double")
else:
    print(f"[t33b] NOTE: '{ac.USE_TAX_COL}' not in source -> use_tax_amount = NULL (DEFERRED branch).")
    df = df.withColumn("use_tax_amount", lit(None).cast("double"))
    use_tax = col("use_tax_amount")

if "use_tax_amount" not in df.columns:
    df = df.withColumn("use_tax_amount", use_tax)

# COMMAND ----------

df = df.withColumn(
    "Reverse_UseTax",
    when((use_tax > 0) & (col("taxability") == "Exempt"),  lit("Yes"))
    .when((use_tax > 0) & (col("taxability") == "Taxable"), lit("No"))
    .when(use_tax == 0, lit("No"))
    .when(use_tax.isNull(), lit(None).cast("string"))      # DEFERRED
    .when(col("taxability").isNull(), lit(None).cast("string"))
    .otherwise(lit(None).cast("string"))
)

ac.write_stage(df, ac.T["use_tax"])
print("[t33b] done.")
