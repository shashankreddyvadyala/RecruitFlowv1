# Databricks notebook source
# t35_qa.py
# -----------------------------------------------------------------------------
# TASK 3.5 — QA. Pure Spark window functions + statistical checks. No model/LLM.
# Ports the architecture's six checks. Checks 3 & 5 need reference tables
# (HISTORICAL_STATS, STATE_RULES); they are skipped gracefully if unset.
#
# Check 4 (rule vs classifier conflict) can only fire where BOTH a rule label
# and a model prediction exist. In this pipeline the model runs only on no_rule
# rows, so xgb_pred is null for rule rows and Check 4 is effectively dormant —
# same limitation flagged in the architecture review. Toggle a shadow-prediction
# pass in t32 if you want it live.
# -----------------------------------------------------------------------------
import atims_common as ac
from pyspark.sql import Window
from pyspark.sql import functions as F
from pyspark.sql.functions import col, lit, when, count, expr

# COMMAND ----------

spark = ac.get_spark()
df    = ac.read_stage(ac.T["written"], spark)

vendor = ac.COLS["vendor_name"]
state  = ac.COLS["state"]
amt    = ac.COLS["tran_amount"]

# COMMAND ----------
# Check 1 — vendor/category consistency (modal category per vendor)
w_vendor = Window.partitionBy(vendor)
w_vc     = Window.partitionBy(vendor, "final_category")
df = df.withColumn("_vc_n", count("*").over(w_vc))
df = df.withColumn("_v_n",  count("*").over(w_vendor))
df = df.withColumn("_vc_frac", col("_vc_n") / col("_v_n"))
df = df.withColumn("f_vendor_inconsistent",
                   when((col("_v_n") >= 5) & (col("_vc_frac") < 0.5), lit(1)).otherwise(lit(0)))

# Check 2 — amount z-score within category
w_cat = Window.partitionBy("final_category")
df = df.withColumn("_mean_amt", F.avg(col(amt).cast("double")).over(w_cat))
df = df.withColumn("_std_amt",  F.stddev(col(amt).cast("double")).over(w_cat))
df = df.withColumn("_zscore",
                   when((col("_std_amt").isNotNull()) & (col("_std_amt") > 0),
                        (col(amt).cast("double") - col("_mean_amt")) / col("_std_amt")).otherwise(lit(0.0)))
df = df.withColumn("f_amount_outlier", when(F.abs(col("_zscore")) > 3.0, lit(1)).otherwise(lit(0)))

# Check 6 — batch-level outlier: category differs from >=95% of same-vendor rows
df = df.withColumn("f_batch_outlier",
                   when((col("_v_n") >= 10) & (col("_vc_frac") <= 0.05), lit(1)).otherwise(lit(0)))

# COMMAND ----------
# Check 3 — state/category history (optional reference table)
if ac.HISTORICAL_STATS:
    hist = (spark.read.table(ac.HISTORICAL_STATS)
                 .select(col("final_category").alias("_h_cat"), col("state").alias("_h_state")).distinct())
    df = df.join(hist, (col("final_category") == col("_h_cat")) & (col(state) == col("_h_state")), "left")
    df = df.withColumn("f_new_state_cat", when(col("_h_cat").isNull(), lit(1)).otherwise(lit(0))).drop("_h_cat", "_h_state")
else:
    df = df.withColumn("f_new_state_cat", lit(0))

# Check 5 — taxability sanity (optional reference table)
if ac.STATE_RULES:
    srules = (spark.read.table(ac.STATE_RULES)
                   .select(col("state").alias("_s_state"), col("service_taxable").alias("_svc_taxable")))
    df = df.join(srules, col(state) == col("_s_state"), "left")
    df = df.withColumn("f_tax_sanity",
                       when((col("final_category").like("%Service%")) &
                            (col("taxability") == "Taxable") &
                            (col("_svc_taxable") == False), lit(1)).otherwise(lit(0))).drop("_s_state", "_svc_taxable")
else:
    df = df.withColumn("f_tax_sanity", lit(0))

# Check 4 — rule vs classifier conflict (dormant unless shadow preds exist)
df = df.withColumn("f_rule_ml_conflict",
                   when((col("rule_matched").isNotNull()) & (col("xgb_pred").isNotNull()) &
                        (col("final_category") != col("xgb_pred")), lit(1)).otherwise(lit(0)))

# COMMAND ----------
# Assemble anomalies array + score
flag_cols = {
    "vendor_inconsistent": "f_vendor_inconsistent",
    "amount_outlier":      "f_amount_outlier",
    "new_state_category":  "f_new_state_cat",
    "rule_ml_conflict":    "f_rule_ml_conflict",
    "taxability_sanity":   "f_tax_sanity",
    "batch_outlier":       "f_batch_outlier",
}
df = df.withColumn("anomalies", expr("filter(array({}), x -> x is not null)".format(
    ", ".join(["CASE WHEN {} = 1 THEN '{}' END".format(c, name) for name, c in flag_cols.items()]))))

flag_sum = sum([col(c) for c in flag_cols.values()])
df = df.withColumn("anomaly_score", F.least(flag_sum / lit(float(len(flag_cols))) * lit(2.0), lit(1.0)).cast("double"))

# review_priority: respect HIGH already set when taxability is null (t33)
df = df.withColumn("review_priority",
    when(col("review_priority_pre") == "HIGH", lit("HIGH"))
    .when(col("anomaly_score") >= 0.66, lit("CRITICAL"))
    .when(col("anomaly_score") >= 0.33, lit("HIGH"))
    .when(col("anomaly_score") > 0.0,  lit("MED"))
    .when(col("label_source") == "need_to_review", lit("MED"))
    .otherwise(lit("LOW")))

df = df.withColumn("override_suggested",
                   when((col("anomaly_score") >= 0.33) | (col("review_priority").isin("HIGH", "CRITICAL")), lit(True)).otherwise(lit(False)))
df = df.withColumn("recommendation",
                   when(col("override_suggested"), lit("review_and_reclassify")).otherwise(lit("accept")))

# drop scratch cols
df = df.drop("_vc_n", "_v_n", "_vc_frac", "_mean_amt", "_std_amt", "_zscore")

# COMMAND ----------
ac.write_stage(df, ac.T["qa"])
print("[t35] done.")
