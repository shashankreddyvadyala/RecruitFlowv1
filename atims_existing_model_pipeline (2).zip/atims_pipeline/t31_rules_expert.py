# Databricks notebook source
# t31_rules_expert.py
# -----------------------------------------------------------------------------
# TASK 3.1 — Rules Expert.
# Applies the existing rules engine (keyword + generic + Parker-Volpe) verbatim.
# Architecture's "Vector Search fallback" is NOT used (it required GTE-Large /
# Vector Search, which are excluded). Deterministic rules only — same as legacy.
# Output: every record tagged label_source = 'rule' | 'no_rule'.
# -----------------------------------------------------------------------------
import atims_common as ac
from pyspark.sql.functions import col

# COMMAND ----------

spark = ac.get_spark()

df    = ac.read_stage(ac.T["prepped"], spark)
rules = ac.load_rules(ac.PATHS.get("cluster_rules_excel"))

# build_labels re-derives final_description; it is idempotent on the prepped df.
df = ac.build_labels(df, rules, spark)

# COMMAND ----------

rule_n = df.filter(col("label_source") == "rule").count()
tot    = df.count()
print(f"[t31] rule-matched={rule_n:,}  no_rule={tot-rule_n:,}  total={tot:,}")

ac.write_stage(df, ac.T["rules"])
print("[t31] done.")
