# Databricks notebook source
# t33_tax_lookup.py
# -----------------------------------------------------------------------------
# TASK 3.3 — Tax Lookup (pure Spark SQL LEFT JOIN). No model, no LLM.
#
# Joins each record's category + state against the taxability matrix.
#
# CATEGORY KEY DECISION (see README): the existing model predicts an ACCOUNT
# CODE, not a 120-way cluster. We expose final_category = coalesce(cluster,
# final_pred): rule rows join on cluster; ML rows join on predicted account
# code. Your taxability_matrix MUST be keyed to match. Unmatched -> taxability
# NULL -> review HIGH, exactly as the architecture specifies.
# -----------------------------------------------------------------------------
import atims_common as ac
from pyspark.sql.functions import col, coalesce, lit, when

# COMMAND ----------

spark = ac.get_spark()
df    = ac.read_stage(ac.T["classified"], spark)

# final_category is produced by t32 (rule cluster, agreed category, or ai_query
# resolution). Keep it; only fall back if somehow absent.
df = df.withColumn("final_category",
                   coalesce(col("final_category"), col("cluster"), col("final_pred")))
state_col = ac.COLS["state"]

# COMMAND ----------

matrix_ok = True
try:
    matrix = (spark.read.table(ac.TAXABILITY_MATRIX)
                   .select(col("cluster").alias("_cat"),
                           col("state").alias("_state"),
                           col("taxability").alias("_taxability")))
except Exception as e:
    matrix_ok = False
    print(f"[t33] WARNING: taxability_matrix unavailable ({e}); taxability=NULL for all.")

if matrix_ok:
    df = (df.join(matrix,
                  (col("final_category") == col("_cat")) & (col(state_col) == col("_state")),
                  "left")
            .withColumn("taxability", col("_taxability"))
            .drop("_cat", "_state", "_taxability"))
else:
    df = df.withColumn("taxability", lit(None).cast("string"))

# tax_source: matrix hit vs no_match
df = df.withColumn("tax_source",
                   when(col("taxability").isNotNull(), lit("matrix")).otherwise(lit("no_match")))

# Pre-escalation: no taxability match -> HIGH (architecture rule; no Tax-Reasoning agent)
df = df.withColumn("review_priority_pre",
                   when(col("taxability").isNull(), lit("HIGH")).otherwise(lit("LOW")))

# COMMAND ----------

ac.write_stage(df, ac.T["taxed"])
print("[t33] done.")
