# Databricks notebook source
# t37_write_output.py
# -----------------------------------------------------------------------------
# TASK 3.7 — Write Final Output + Notify.
# Selects the final schema, writes to the prod table, logs batch metrics to the
# EXISTING MLflow experiment, optionally generates the legacy need-to-review
# Excel report (with KMeans cluster discovery on TF-IDF — existing behavior),
# and POSTs the completion webhook.
# -----------------------------------------------------------------------------
import atims_common as ac
from pyspark.sql.functions import col

# COMMAND ----------

dbutils = ac.get_dbutils()
spark   = ac.get_spark()

dbutils.widgets.text("invoice_month", "2022-01", "Invoice month (YYYY-MM)")
INVOICE_MONTH = dbutils.widgets.get("invoice_month")

df = ac.read_stage(ac.T["rerouted"], spark)

# COMMAND ----------
# Final output schema (architecture Task 3.7)
C = ac.COLS
final_cols = [
    C["invoice_id"], C["inv_line_number"], "final_description",
    C["vendor_name"], C["state"], C["tran_amount"],
    "final_category", "taxability", "tax_source",
    "use_tax_amount", "Reverse_UseTax",
    "final_pred", "final_conf", "rule_matched", "decision_path",
    "xgb_pred", "xgb_conf", "lgb_pred", "lgb_conf", "models_agree", "confidence_tier",
    "short_justification", "full_writeup", "audit_ready",
    "anomalies", "anomaly_score", "review_priority", "override_suggested",
    "recommendation", "iteration", "processing_path",
    "label_source", C["accounting_date"],
]
present = [c for c in final_cols if c in df.columns]
out = df.select(present)

(out.write.format("delta").mode("append")
    .partitionBy(C["accounting_date"])
    .option("mergeSchema", "true")
    .saveAsTable(ac.PROD_TABLE))
print(f"[t37] wrote {out.count():,} rows -> {ac.PROD_TABLE}")

# COMMAND ----------
# Batch metrics -> existing MLflow
try:
    import mlflow
    if ac.PATHS.get("mlflow_tracking_uri"):
        mlflow.set_tracking_uri(ac.PATHS["mlflow_tracking_uri"])
    mlflow.set_experiment("ap_tax_classification")
    counts = {r["label_source"]: r["count"] for r in out.groupBy("label_source").count().collect()}
    total  = sum(counts.values()) or 1
    with mlflow.start_run(run_name=f"batch_{INVOICE_MONTH}"):
        mlflow.log_params({"invoice_month": INVOICE_MONTH, "model": "xgb+lgb (existing)"})
        mlflow.log_metrics({
            "total": total,
            "rule":  counts.get("rule", 0),
            "ml":    counts.get("ml", 0),
            "need_to_review": counts.get("need_to_review", 0),
            "auto_pct": (counts.get("rule", 0) + counts.get("ml", 0)) / total,
        })
    print("[t37] logged batch metrics to MLflow.")
except Exception as e:
    print(f"[t37] MLflow logging skipped: {e}")

# COMMAND ----------
# Optional: legacy Excel need-to-review report + KMeans discovery (TF-IDF).
# discover_new_clusters loads the fitted TF-IDF vectorizer itself if needed.
try:
    df_disc, cluster_summary = ac.discover_new_clusters(df, spark)
    report_path = ac.generate_report(df_disc, cluster_summary, INVOICE_MONTH)
    print(f"[t37] report: {report_path}")
except Exception as e:
    print(f"[t37] report step skipped: {e}")

# COMMAND ----------
# Notify FastAPI backend
if ac.WEBHOOK_URL:
    try:
        import json
        import urllib.request
        flagged = out.filter(col("review_priority").isin("HIGH", "CRITICAL")).count()
        payload = json.dumps({"month": INVOICE_MONTH,
                              "records_processed": out.count(),
                              "flagged_count": flagged}).encode()
        req = urllib.request.Request(ac.WEBHOOK_URL, data=payload,
                                     headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=30)
        print("[t37] webhook posted.")
    except Exception as e:
        print(f"[t37] webhook failed: {e}")
else:
    print("[t37] WEBHOOK_URL unset — skipping notify.")

print("[t37] done.")
