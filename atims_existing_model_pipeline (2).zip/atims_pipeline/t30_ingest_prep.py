# Databricks notebook source
# t30_ingest_prep.py
# -----------------------------------------------------------------------------
# PHASE 1 (Ingestion) + start of PHASE 2 (text prep), restructured as Task t30.
# Reads the existing VMAP_FACT_TABLE, filters to the run month, and builds the
# cleaned final_description. No model involved.
# -----------------------------------------------------------------------------
import atims_common as ac

# COMMAND ----------

dbutils = ac.get_dbutils()
spark   = ac.get_spark()

dbutils.widgets.text("invoice_month", "2022-01", "Invoice month (YYYY-MM)")
INVOICE_MONTH = dbutils.widgets.get("invoice_month")

# COMMAND ----------

print(f"[t30] Loading {ac.PATHS['daily_invoices']} for {INVOICE_MONTH}")
df = (spark.read.format("delta").load(ac.PATHS["daily_invoices"])
           .filter(f"{ac.COLS['accounting_date']} like '{INVOICE_MONTH}%'"))
print(f"      {df.count():,} records")

df = ac.build_final_description(df)

ac.write_stage(df, ac.T["prepped"])
print("[t30] done.")
