# Databricks notebook source
# t34_tax_writer.py
# -----------------------------------------------------------------------------
# TASK 3.4 — Tax Writer, following the architecture's data flow.
# Generates the justification with ai_query('databricks-gpt-4o', ...).
#
# The architecture also did Vector Search batch RAG over a prior-write-ups KB.
# That step requires GTE-Large / Vector Search indexes (excluded here), so the
# RAG retrieval is omitted; the ai_query call itself is fully wired. When
# Reverse_UseTax = 'Yes', the prompt forces the write-up to state the reversal
# requirement and reference the amount.
# -----------------------------------------------------------------------------
import atims_common as ac
from pyspark.sql.functions import col, lit, expr, concat_ws, coalesce

# COMMAND ----------

spark = ac.get_spark()
df    = ac.read_stage(ac.T["use_tax"], spark)

state_col = ac.COLS["state"]
amt_col   = ac.COLS["tran_amount"]

# COMMAND ----------
# Full write-up via ai_query (one call per record, per the data flow).
writeup_prompt = (
    "ai_query('" + ac.LLM_ENDPOINT + "', "
    "concat('Write a concise, audit-ready taxability justification (2-4 sentences) "
    "for an AP invoice line. "
    "Category: ', coalesce(final_category, 'Uncategorized'), "
    "'. State: ', coalesce(" + state_col + ", 'Unknown'), "
    "'. Taxability: ', coalesce(taxability, 'undetermined (no matrix match)'), "
    "'. Reverse use tax: ', coalesce(Reverse_UseTax, 'n/a'), "
    "'. Use tax amount: ', coalesce(cast(use_tax_amount as string), 'n/a'), "
    "'. Transaction amount: ', coalesce(cast(" + amt_col + " as string), 'n/a'), "
    "'. Basis: ', coalesce(rule_matched, "
    "concat('model ensemble, confidence ', cast(round(final_conf, 2) as string))), "
    "'.', "
    "CASE WHEN Reverse_UseTax = 'Yes' "
    "THEN ' State explicitly that a use tax reversal is required and reference the use tax amount.' "
    "ELSE '' END))"
)
df = df.withColumn("full_writeup", expr(writeup_prompt))

# COMMAND ----------
# short_justification: lightweight template (avoids a second LLM call per record)
df = df.withColumn("short_justification", concat_ws(" ",
    coalesce(col("final_category"), lit("Uncategorized")),
    lit("in"), coalesce(col(state_col), lit("Unknown")),
    lit("->"), coalesce(col("taxability"), lit("undetermined"))))

df = (df.withColumn("reviewer_note", lit("LLM-generated (ai_query)"))
        .withColumn("audit_ready", col("taxability").isNotNull()))

ac.write_stage(df, ac.T["written"])
print("[t34] done.")
