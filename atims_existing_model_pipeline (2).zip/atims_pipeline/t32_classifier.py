# Databricks notebook source
# t32_classifier.py
# -----------------------------------------------------------------------------
# TASK 3.2 — Classifier, following the architecture's PHASE 3 DATA FLOW.
#
#   Sub-model A: EXISTING model (TF-IDF + XGBoost + LightGBM ensemble) — UNCHANGED.
#                Loaded from existing DBFS artifacts; produces final_pred/final_conf.
#   Sub-model B: ai_classify(final_description, array(<labels>)) -> llm_pred.
#
#   Agreement logic (DataFrame ops):
#     both agree + ensemble_conf > high_conf  -> ACCEPT   (tier HIGH,  path STANDARD)
#     both agree + low conf                   -> MEDIUM   (tier MEDIUM, path STANDARD)
#     disagree                                -> ai_query('databricks-gpt-4o', ...)
#                                                resolution (tier RESOLVED, path COMPLEX)
#
# Note: comparison happens in CATEGORY space. The existing model outputs an
# account code; set ac.ACCOUNT_TO_CATEGORY to map it to a category so it lines up
# with ai_classify's labels (else most rows fall to ai_query — see README).
# No GTE / no Vector Search: the model is unchanged and uses TF-IDF features.
# -----------------------------------------------------------------------------
import atims_common as ac
from pyspark.sql.functions import col, lit, when, expr, coalesce
from pyspark.sql.types import StringType, FloatType

# COMMAND ----------

spark = ac.get_spark()
df    = ac.read_stage(ac.T["rules"], spark)
id_col, line_col = ac.COLS["invoice_id"], ac.COLS["inv_line_number"]

df_rule    = df.filter(col("label_source") == "rule")
df_no_rule = df.filter(col("label_source") == "no_rule")
rule_n, no_rule_n = df_rule.count(), df_no_rule.count()
print(f"[t32] rule={rule_n:,}  to-ML={no_rule_n:,}")

# COMMAND ----------
# Rule rows: deterministic, category = cluster, confidence 1.0
df_rule = (df_rule
    .withColumn("final_pred",          col("label_account_code"))
    .withColumn("final_conf",          lit(1.0).cast(FloatType()))
    .withColumn("xgb_pred",            lit(None).cast(StringType()))
    .withColumn("xgb_conf",            lit(None).cast(FloatType()))
    .withColumn("lgb_pred",            lit(None).cast(StringType()))
    .withColumn("lgb_conf",            lit(None).cast(FloatType()))
    .withColumn("models_agree",        lit(None).cast(StringType()))
    .withColumn("llm_pred",            lit(None).cast(StringType()))
    .withColumn("agreement",           lit(None).cast(StringType()))
    .withColumn("final_category",      col("cluster"))
    .withColumn("ensemble_confidence", lit(1.0).cast(FloatType()))
    .withColumn("confidence_tier",     lit("RULE"))
    .withColumn("decision_path",       lit("rule"))
    .withColumn("label_source",        lit("rule")))

# COMMAND ----------
if no_rule_n == 0:
    df_final = df_rule
    print("[t32] all rows matched by rules.")
else:
    # Sub-model A — existing ensemble (UNCHANGED). Raw predictions only.
    xgb, lgb, label_enc, cat_encoders = ac.load_artifacts()
    preds = ac.predict_no_rule(df_no_rule, xgb, lgb, label_enc, cat_encoders, spark)

    # Join predictions at LINE GRAIN (fixes legacy invoice_id-only fan-out).
    nr = (df_no_rule.drop("label_source")
                    .join(preds, on=[id_col, line_col], how="left"))

    # model_category: map account_code -> category if a map is provided.
    if ac.ACCOUNT_TO_CATEGORY:
        amap = (spark.read.table(ac.ACCOUNT_TO_CATEGORY)
                     .select(col("account_code").alias("_ac"), col("category").alias("_cat")))
        nr = (nr.join(amap, col("final_pred") == col("_ac"), "left")
                .withColumn("model_category", coalesce(col("_cat"), col("final_pred")))
                .drop("_ac", "_cat"))
    else:
        nr = nr.withColumn("model_category", col("final_pred"))

    # Sub-model B — ai_classify() zero-shot
    nr = nr.withColumn("llm_pred", expr(f"ai_classify(final_description, {ac.labels_sql_array()})"))

    # Agreement (category space)
    nr = nr.withColumn("agreement", (col("model_category") == col("llm_pred")))

    high = ac.THRESHOLDS["high_conf"]
    agree_df    = nr.filter(col("agreement") == True)                       # noqa: E712
    disagree_df = nr.filter((col("agreement") == False) | col("agreement").isNull())  # noqa: E712

    # ACCEPT on agreement
    agree_df = (agree_df
        .withColumn("final_category", col("model_category"))
        .withColumn("confidence_tier",
                    when(col("final_conf") > lit(high), lit("HIGH")).otherwise(lit("MEDIUM")))
        .withColumn("decision_path", lit("STANDARD")))

    # RESOLVE disagreements via ai_query (GPT-4o). Runs only on this subset.
    resolve_prompt = (
        "ai_query('" + ac.LLM_ENDPOINT + "', "
        "concat('Two classifiers disagree on the category of an AP invoice line. "
        "Model A predicted: ', model_category, "
        "'. Model B (LLM zero-shot) predicted: ', llm_pred, "
        "'. Line description: ', final_description, "
        "'. Choose the single best category and return ONLY the category name from: "
        + ac.labels_text().replace("'", "''") + "'))"
    )
    disagree_df = (disagree_df
        .withColumn("final_category", expr(resolve_prompt))
        .withColumn("confidence_tier", lit("RESOLVED"))
        .withColumn("decision_path", lit("COMPLEX")))

    nr2 = (agree_df.unionByName(disagree_df)
        .withColumn("ensemble_confidence", col("final_conf"))
        .withColumn("agreement", col("agreement").cast("string"))
        .withColumn("label_source", lit("ml")))

    df_final = df_rule.unionByName(nr2, allowMissingColumns=True)

# COMMAND ----------
for r in df_final.groupBy("decision_path").count().collect():
    print(f"   path={r['decision_path']:<10}{r['count']:>10,}")

ac.write_stage(df_final, ac.T["classified"])
print("[t32] done.")
