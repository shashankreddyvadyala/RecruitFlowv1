# Databricks notebook source
# t36_reroute.py
# -----------------------------------------------------------------------------
# TASK 3.6 — Re-route / Finalize.
# The architecture re-ran the classifier with a QA hint injected into the LLM
# prompt (max 2 passes). With the EXISTING deterministic ensemble there is no
# prompt and re-running yields identical output — so iterative re-routing is a
# no-op here. This task therefore FINALIZES instead: flagged records are
# escalated to human review rather than looped.
#
#   override_suggested = True  -> escalate (need_to_review), priority kept/raised
#   else                       -> finalized
# Keeps an `iteration` column for schema parity with the architecture.
# -----------------------------------------------------------------------------
import atims_common as ac
from pyspark.sql.functions import col, lit, when

# COMMAND ----------

spark = ac.get_spark()
df    = ac.read_stage(ac.T["qa"], spark)

df = df.withColumn("iteration", lit(0))

df = df.withColumn("label_source",
                   when(col("override_suggested") == True, lit("need_to_review"))  # noqa: E712
                   .otherwise(col("label_source")))

df = df.withColumn("processing_path",
                   when(col("decision_path") == "rule", lit("FAST"))
                   .when(col("label_source") == "need_to_review", lit("ESCALATION"))
                   .when(col("models_agree") == "True", lit("STANDARD"))
                   .otherwise(lit("COMPLEX")))

n_esc = df.filter(col("label_source") == "need_to_review").count()
print(f"[t36] escalated to human review: {n_esc:,}")

# COMMAND ----------
ac.write_stage(df, ac.T["rerouted"])
print("[t36] done.")
