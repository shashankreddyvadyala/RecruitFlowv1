#!/usr/bin/env python3
# tests/run_local.py — end-to-end smoke test of the ATIMS pipeline on sample data.
# Runs the REAL task files (t30..t37) with these test-only substitutions:
#   - plain Spark + in-memory tables (no Delta jar available offline)
#   - ai_classify() / ai_query() registered as deterministic mock SQL UDFs
#   - dbutils stubbed; tiny real XGB+LGB artifacts trained so the model code loads
import os, sys, pickle, random
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
PIPE = os.path.dirname(HERE)
sys.path.insert(0, PIPE)

from pyspark.sql import SparkSession, DataFrameReader, DataFrameWriter
from pyspark.sql.types import StringType

spark = (SparkSession.builder.master("local[2]").appName("atims_test")
         .config("spark.sql.shuffle.partitions", "4")
         .config("spark.ui.enabled", "false").getOrCreate())
spark.sparkContext.setLogLevel("ERROR")

import atims_common as ac

# ----------------------------------------------------------------------------
# 1) Sample data (line grain; includes multi-line invoices, rule hits + misses)
# ----------------------------------------------------------------------------
random.seed(1); np.random.seed(1)
rows = []
inv = 1000
# Rule-matched rows (varied generic rules -> several account codes/clusters)
rule_specs = [
    ("MIC", "SW",   "ERTU",                  "1130.10"),
    ("MIC", "CEQ",  "Telecom Equipment",     "4010.22"),   # note: CEQ% overrides exact CEQ (known quirk)
    ("MIC", "SEQ1", "Network Equipment",     "1220.121"),
    ("EXTC","48C",  "Freight - Common Carrier Charges", "6114.1"),
    ("VEND","IRON MOUNTAIN INC", "Storage Services", "1130.55"),
    ("VEND","TEKSYSTEMS INC",    "Data Processing",  "399C"),
]
for s in range(60):
    kind, key, _clu, acct = rule_specs[s % len(rule_specs)]
    mic   = key if kind == "MIC" else "ZZZ"
    extc  = key if kind == "EXTC" else "100"
    vend  = key if kind == "VEND" else f"VENDOR_{s%7}"
    rows.append((inv+s, 1, f"INV{inv+s}", "2022-01-15",
                 f"line desc {s}", "DESCRIPTION X", "", extc, mic, acct,
                 vend, "CC01", "TX", "SRC_A", float(100+s*3),
                 float(0 if s % 3 else 5)))   # some use_tax_amount > 0
# No-rule rows (unknown codes/vendors, free text) -> ML + ai_classify + ai_query
no_rule_texts = ["fiber optic cable splice kit", "annual software maintenance renewal",
                 "scaffolding rental for tower work", "generator diesel fuel delivery",
                 "consulting engineering services", "office cleaning monthly contract"]
for s in range(40):
    iid = inv + 500 + (s // 2)        # pairs share an INVOICE_ID -> multi-line, tests join grain
    rows.append((iid, (s % 2) + 1, f"INV{iid}", "2022-01-15",
                 no_rule_texts[s % len(no_rule_texts)], "", "",
                 f"X{s%5}", f"UNK{s%4}", f"9{s%6}99.00",
                 f"NOVENDOR_{s%9}", "CC02", "CA", "SRC_B", float(250+s*7),
                 float(7 if s % 4 == 0 else 0)))

cols = [ac.COLS[k] for k in ["invoice_id","inv_line_number","invoice_num","accounting_date",
        "line_description","description","dist_all_description","extc","mic","account_code",
        "vendor_name","company_code","state","invoice_source","tran_amount"]] + ["USE_TAX_AMOUNT"]
SOURCE_DF = spark.createDataFrame(rows, cols)
print(f"[setup] sample source rows: {SOURCE_DF.count()} "
      f"(invoices: {SOURCE_DF.select(ac.COLS['invoice_id']).distinct().count()})")

# ----------------------------------------------------------------------------
# 2) Train tiny REAL artifacts so load_artifacts()/predict_no_rule() work
#    (uses the same build_feature_matrix + artifact format as production)
# ----------------------------------------------------------------------------
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from sklearn.preprocessing import LabelEncoder

labeled = ac.build_labels(SOURCE_DF, ac.load_rules(None), spark)
train_pdf = (labeled.filter("label_source = 'rule'")
             .select("final_description", "label_account_code",
                     *ac.CAT_COLS, ac.COLS["vendor_name"], ac.COLS["tran_amount"]).toPandas())
le = LabelEncoder(); y = le.fit_transform(train_pdf["label_account_code"].astype(str))
X, cat_enc = ac.build_feature_matrix(train_pdf, fit=True)
nclass = len(le.classes_)
xgb = XGBClassifier(n_estimators=40, max_depth=4, objective="multi:softprob",
                    num_class=nclass, tree_method="hist", verbosity=0).fit(X, y)
lgb = LGBMClassifier(n_estimators=40, num_leaves=15, objective="multiclass",
                     num_class=nclass, verbose=-1).fit(X, y)

MODELDIR = "/tmp/atims_models"; os.makedirs(MODELDIR, exist_ok=True)
ac.PATHS.update({
    "xgb_model":     f"{MODELDIR}/xgb_model.ubj",
    "lgb_model":     f"{MODELDIR}/lgb_model.txt",
    "label_encoder": f"{MODELDIR}/label_encoder.pkl",
    "cat_encoders":  f"{MODELDIR}/cat_encoders.pkl",
    "tfidf":         f"{MODELDIR}/tfidf.pkl",
})
xgb.save_model(ac.PATHS["xgb_model"]); lgb.booster_.save_model(ac.PATHS["lgb_model"])
pickle.dump(le, open(ac.PATHS["label_encoder"], "wb"))
pickle.dump(cat_enc, open(ac.PATHS["cat_encoders"], "wb"))
pickle.dump(ac._tfidf_vec, open(ac.PATHS["tfidf"], "wb"))
print(f"[setup] trained throwaway artifacts: {nclass} account-code classes")

# account_code -> category map (so ensemble vs ai_classify share a space)
acct_cat = (labeled.filter("label_source='rule'")
            .select(ac.COLS["account_code"], "cluster").distinct()
            .withColumnRenamed(ac.COLS["account_code"], "account_code")
            .withColumnRenamed("cluster", "category"))
acct_cat.createOrReplaceTempView("acct_cat_v")

# taxability matrix keyed on category + state
cats = [r["category"] for r in acct_cat.select("category").distinct().collect()]
mat = []
for c in cats + ac.CATEGORY_LABELS:
    for st in ["TX", "CA"]:
        mat.append((c, st, "Taxable" if (hash(c+st) % 2 == 0) else "Exempt"))
spark.createDataFrame(mat, ["cluster", "state", "taxability"]).dropDuplicates(
    ["cluster", "state"]).createOrReplaceTempView("tax_matrix_v")

# ----------------------------------------------------------------------------
# 3) Test-only monkeypatches
# ----------------------------------------------------------------------------
ac.CATALOG = "spark_catalog"; ac.STAGING_SCHEMA = "atims_test"
ac.PROD_TABLE = "prod_out"
ac.TAXABILITY_MATRIX = "tax_matrix_v"
ac.ACCOUNT_TO_CATEGORY = "acct_cat_v"
ac.WEBHOOK_URL = None
ac.HISTORICAL_STATS = None; ac.STATE_RULES = None

_TABLES = {}
def _write_stage(df, name, mode="overwrite"):
    df = df.cache(); df.count()
    _TABLES[name] = df
    print(f"   -> wrote {name} ({df.count()} rows)")
def _read_stage(name, spark_):
    return _TABLES[name]
ac.write_stage = _write_stage
ac.read_stage = _read_stage
ac.get_spark = lambda: spark

class _Widgets:
    def text(self, *a, **k): pass
    def get(self, key): return "2022-01"
class _FS:
    def cp(self, *a, **k): pass
class _DBUtils:
    widgets = _Widgets(); fs = _FS()
ac.get_dbutils = lambda *a, **k: _DBUtils()

# Intercept the source delta read in t30 and the prod delta write in t37
_orig_load = DataFrameReader.load
def _patched_load(self, path=None, *a, **k):
    if path == ac.PATHS["daily_invoices"]:
        return SOURCE_DF
    return _orig_load(self, path, *a, **k)
DataFrameReader.load = _patched_load

_orig_saveAsTable = DataFrameWriter.saveAsTable
def _patched_saveAsTable(self, name, *a, **k):
    _TABLES[name] = self._df.cache(); _TABLES[name].count()
    print(f"   -> prod write captured: {name} ({_TABLES[name].count()} rows)")
DataFrameWriter.saveAsTable = _patched_saveAsTable

# ai_classify / ai_query mock UDFs (deterministic)
LABELS = ac.CATEGORY_LABELS
def _ai_classify(text, labels):
    labels = labels or LABELS
    t = (text or "").lower()
    kw = {"cable": "Cable - Nonmetalic", "software": "Software - ERTU",
          "fuel": "Propane / Fuels", "engineering": "Vendor Engineering",
          "cleaning": "Food/Beverage", "tower": "Tower Materials"}
    for k, v in kw.items():
        if k in t and v in labels:
            return v
    return labels[hash(t) % len(labels)]
def _ai_query(endpoint, prompt):
    p = prompt or ""
    if "category" in p.lower() and "return only" in p.lower():
        return "Telecom Equipment"                      # resolution -> a valid category
    rev = " Use tax reversal is required." if "use tax reversal is required" in p.lower() else ""
    return ("Determination based on category and state per the taxability matrix." + rev)
spark.udf.register("ai_classify", _ai_classify, StringType())
spark.udf.register("ai_query", _ai_query, StringType())
print("[setup] registered ai_classify / ai_query mock UDFs")

# ----------------------------------------------------------------------------
# 4) Seed t30 output (run t30's real logic) then exec t31..t37 in order
# ----------------------------------------------------------------------------
def run_task(fname):
    print(f"\n===== {fname} =====")
    g = {"__name__": "__main__"}
    with open(os.path.join(PIPE, fname)) as f:
        exec(compile(f.read(), fname, "exec"), g)

for f in ["t30_ingest_prep.py", "t31_rules_expert.py", "t32_classifier.py",
          "t33_tax_lookup.py", "t33b_use_tax_lookup.py", "t34_tax_writer.py",
          "t35_qa.py", "t36_reroute.py", "t37_write_output.py"]:
    run_task(f)

# ----------------------------------------------------------------------------
# 5) Assertions + sample output
# ----------------------------------------------------------------------------
from pyspark.sql.functions import col
out = _TABLES["prod_out"]
print("\n===== RESULTS =====")
n = out.count()
print(f"prod rows: {n}")
assert n > 0, "no output rows"

# join-grain check: no fan-out — output rows == source rows
assert n == SOURCE_DF.count(), f"row count changed ({n} vs {SOURCE_DF.count()}) -> join fan-out!"
print(f"row-count integrity vs source: OK ({n})")

# every row has a final_category and a write-up
nullcat = out.filter(col("final_category").isNull()).count()
nullwrite = out.filter(col("full_writeup").isNull()).count()
print(f"null final_category: {nullcat} | null full_writeup: {nullwrite}")
assert nullcat == 0 and nullwrite == 0

print("\npath distribution:")
out.groupBy("decision_path").count().show(truncate=False)
print("review_priority distribution:")
out.groupBy("review_priority").count().show(truncate=False)
print("taxability distribution:")
out.groupBy("taxability").count().show(truncate=False)
print("Reverse_UseTax distribution:")
out.groupBy("Reverse_UseTax").count().show(truncate=False)

print("\nsample rows (no_rule / ML path):")
_want = ["final_category", "confidence_tier", "taxability", "Reverse_UseTax", "review_priority"]
_have = [c for c in _want if c in out.columns]
(out.filter(col("decision_path").isin("STANDARD", "COMPLEX"))
    .select(*_have)
    .show(6, truncate=False))
print("sample full_writeup:")
for r in out.select("full_writeup").limit(2).collect():
    print("  -", r["full_writeup"][:160])

print("\n*** END-TO-END SMOKE TEST PASSED ***")

# ----------------------------------------------------------------------------
# 6) Dump the full output table for inspection
# ----------------------------------------------------------------------------
show_cols = [ac.COLS["invoice_id"], ac.COLS["inv_line_number"], ac.COLS["vendor_name"],
             "final_description", "decision_path", "confidence_tier", "final_category",
             "final_conf", "taxability", "use_tax_amount", "Reverse_UseTax",
             "anomaly_score", "review_priority", "short_justification", "full_writeup"]
show_cols = [c for c in show_cols if c in out.columns]
pdf_out = out.select(*show_cols).orderBy(ac.COLS["invoice_id"], ac.COLS["inv_line_number"]).toPandas()

import os as _os
_os.makedirs("/mnt/user-data/outputs", exist_ok=True)
csv_path = "/mnt/user-data/outputs/atims_sample_output.csv"
pdf_out.to_csv(csv_path, index=False)
print(f"\n[dump] wrote full {len(pdf_out)}-row output -> {csv_path}")

import pandas as _pd
_pd.set_option("display.max_colwidth", 60); _pd.set_option("display.width", 240)

print("\n========== RULE-PATH rows (sample) ==========")
rule_rows = pdf_out[pdf_out["decision_path"] == "rule"].head(5)
print(rule_rows[[ac.COLS["invoice_id"], ac.COLS["inv_line_number"], ac.COLS["vendor_name"],
                 "final_category", "taxability", "Reverse_UseTax", "review_priority"]].to_string(index=False))

print("\n========== ML-PATH rows (sample, multi-line invoices) ==========")
ml_rows = pdf_out[pdf_out["decision_path"].isin(["STANDARD", "COMPLEX"])].head(8)
print(ml_rows[[ac.COLS["invoice_id"], ac.COLS["inv_line_number"], "final_description",
               "confidence_tier", "final_category", "taxability", "Reverse_UseTax",
               "review_priority"]].to_string(index=False))

print("\n========== Two full records (vertical) ==========")
for i in [0, len(pdf_out) - 1]:
    r = pdf_out.iloc[i]
    print("-" * 70)
    for c in show_cols:
        print(f"  {c:<20}: {r[c]}")

spark.stop()
