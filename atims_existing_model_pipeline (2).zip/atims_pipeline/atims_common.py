# Databricks notebook source
# atims_common.py
# =============================================================================
# SHARED MODULE for the ATIMS multi-task Databricks Workflow.
#
# The MODEL LAYER below (rules engine, TF-IDF feature engineering, artifact
# loading, ensemble prediction) is ported VERBATIM from the existing legacy
# notebook. No model, embedding, or LLM component has been changed:
#   - TF-IDF (10k feats, uni+bigram, sublinear)  -> unchanged
#   - XGBoost + LightGBM 50/50 ensemble           -> unchanged
#   - DBFS artifacts (.ubj / .txt / .pkl)         -> unchanged
#   - Existing MLflow tracking                    -> unchanged
#
# What is NEW is only the ORCHESTRATION: the single notebook is split into the
# task DAG from the architecture document, with tasks passing data via Delta
# staging tables (Databricks tasks do not share in-memory DataFrames).
#
# Import this module from each task notebook:  import atims_common as ac
# (Works when all files live in the same Databricks Repo / Git folder.)
# =============================================================================

import pickle
import hashlib
import numpy as np
import pandas as pd

from datetime import datetime
from xgboost import XGBClassifier
from lightgbm import Booster
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.functions import (
    col, when, lit, lower, concat_ws, coalesce, count,
)
from pyspark.sql.types import StringType, FloatType, StructType, StructField


# =============================================================================
# SPARK / DBUTILS ACCESSORS  (so task notebooks and pyflakes both stay happy)
# =============================================================================
def get_spark():
    return SparkSession.builder.getOrCreate()


def get_dbutils(spark=None):
    """Return dbutils whether running in a notebook or via job context."""
    try:
        import IPython
        return IPython.get_ipython().user_ns["dbutils"]
    except Exception:
        from pyspark.dbutils import DBUtils
        return DBUtils(spark or get_spark())


# =============================================================================
# PIPELINE CONFIG  (orchestration + staging — NEW)
# =============================================================================
# Unity Catalog locations for the staged hand-off tables between tasks.
CATALOG        = "atims_dev"          # set to atims_prod for the prod job
STAGING_SCHEMA = "staging"
PROD_TABLE     = "atims_prod.ml_output.non_norad_predictions"

# Tables the architecture references but the legacy model does not produce.
# Wire these to your real tables; tasks degrade gracefully when unset.
TAXABILITY_MATRIX = "atims_shared.reference.taxability_matrix"   # cluster/category + state -> taxability
HISTORICAL_STATS  = None    # e.g. "atims_shared.reference.historical_stats"   (QA check 3)
STATE_RULES       = None    # e.g. "atims_shared.reference.state_service_tax_rules" (QA check 5)
WEBHOOK_URL       = None    # e.g. "https://<fastapi-host>/atims/complete"

# Column in the source fact table holding the AP-system use-tax amount.
# Legacy COLS has no such column; if absent, Reverse_UseTax stays NULL
# (matches the architecture's DEFERRED branch).
USE_TAX_COL = "USE_TAX_AMOUNT"

# ---- Foundation Model API (ai_classify / ai_query) -------------------------
# These are used per the architecture's Phase 3 data flow. They do NOT touch the
# trained model — they are SQL functions on the cluster's Foundation Model API.
LLM_ENDPOINT = "databricks-gpt-4o"   # ai_query resolution + Tax Writer endpoint

# ai_classify label set (Sub-model B). REPLACE with your full ~120 categories.
# Seeded from the cluster names in the rules engine.
CATEGORY_LABELS = [
    "ERTU", "CPE", "Computer Equipments", "Miscellaneous Materials - Telecom",
    "Network Equipment", "Tower Materials", "Telecom Equipment",
    "Communications Equipment", "Freight - Common Carrier Charges",
    "Research and Development", "Permits", "Contract plant labor",
    "Vendor Engineering", "Freight", "Maintenance", "Nontaxable", "Inventory",
    "Operating Lease", "Software - ERTU", "Tools and Testing Equipment",
    "Safety Equipment", "Outside Plant Construction", "Storage Services",
    "Cable - Nonmetalic", "Capital Lease", "Data Processing", "Propane / Fuels",
    "Real Property Construction", "Security Service", "Food/Beverage", "DTV",
    "Landscape Services", "Installation Services - Telecom",
]

# Optional table mapping the model's predicted account_code -> category name,
# so the ensemble prediction and ai_classify output share a comparison space.
# Columns expected: account_code, category. If None, model_category = final_pred
# (account code), which will disagree with most ai_classify labels and route more
# rows to ai_query resolution — see README.
ACCOUNT_TO_CATEGORY = None


def labels_sql_array():
    """SQL array(...) literal of CATEGORY_LABELS for ai_classify()."""
    esc = [s.replace("'", "''") for s in CATEGORY_LABELS]
    return "array(" + ", ".join(f"'{s}'" for s in esc) + ")"


def labels_text():
    """Comma-separated label list for embedding in ai_query() prompts."""
    return ", ".join(CATEGORY_LABELS)


def tbl(name):
    """Fully-qualified staging table name."""
    return f"{CATALOG}.{STAGING_SCHEMA}.{name}"


# Staging hand-off tables (task -> task)
T = {
    "prepped":    tbl("t30_prepped"),
    "rules":      tbl("t31_rules_labeled"),
    "classified": tbl("t32_classified"),
    "taxed":      tbl("t33_tax_lookup"),
    "use_tax":    tbl("t33b_use_tax"),
    "written":    tbl("t34_tax_writer"),
    "qa":         tbl("t35_qa"),
    "rerouted":   tbl("t36_rerouted"),
}


# =============================================================================
# LEGACY CONFIG  (VERBATIM)
# =============================================================================
PATHS = {
    "daily_invoices":      "abfss://atims@prdatimsstore.dfs.core.windows.net/FACT_TABLES/VMAP_FACT_TABLE",
    # Model files — saved to DBFS, no changes
    "xgb_model":       "/dbfs/models/ap_tax/xgb_model.ubj",
    "lgb_model":       "/dbfs/models/ap_tax/lgb_model.txt",
    "label_encoder":   "/dbfs/models/ap_tax/label_encoder.pkl",
    "cat_encoders":    "/dbfs/models/ap_tax/cat_encoders.pkl",
    "tfidf":           "/dbfs/models/ap_tax/tfidf.pkl",
    # Optional
    "cluster_rules_excel": None,
    "cluster_account_map": None,
    "mlflow_tracking_uri": None,
    "reports_output":      None,
}

COLS = {
    "invoice_id":           "INVOICE_ID",
    "inv_line_number":      "INV_LINE_NUMBER",
    "invoice_num":          "INVOICE_NUM",
    "accounting_date":      "ACCOUNTING_DATE",
    "line_description":     "LINE_DESCRIPTION",
    "description":          "DESCRIPTION",
    "dist_all_description": "DIST_ALL_DESCRIPTION",
    "extc":                 "EXTC_CODE",
    "mic":                  "MIC",
    "account_code":         "ACCOUNT_CODE",
    "vendor_name":          "VENDOR_NAME",
    "company_code":         "COMPANY_CODE",
    "state":                "STATE",
    "invoice_source":       "INVOICE_SOURCE",
    "tran_amount":          "TRAN_AMOUNT",
}

MODEL_CONFIG = {
    "max_training_rows":  50_000,
    "min_class_samples":  10,
    "test_size":          0.20,
    "random_seed":        42,
    "tfidf_max_features": 10_000,
    "xgb_params": {
        "n_estimators": 300, "max_depth": 6, "learning_rate": 0.05,
        "subsample": 0.8, "colsample_bytree": 0.8, "eval_metric": "mlogloss",
        "tree_method": "hist", "grow_policy": "lossguide",
        "random_state": 42, "n_jobs": -1,
    },
    "lgb_params": {
        "n_estimators": 300, "max_depth": -1, "learning_rate": 0.05,
        "subsample": 0.8, "colsample_bytree": 0.8, "num_leaves": 63,
        "min_child_samples": 20, "random_state": 42, "n_jobs": -1, "verbose": -1,
    },
    "ensemble_weights": {"xgb": 0.5, "lgb": 0.5},
}

THRESHOLDS = {
    "accept_conf": 0.60,   # legacy threshold (retained, unused by new t32 routing)
    "high_conf":   0.80,   # architecture: both agree + conf > 0.8 -> ACCEPT (HIGH)
}

DISCOVERY_CONFIG = {
    "max_clusters": 10, "min_cluster_size": 5,
    "samples_per_cluster": 5, "random_seed": 42,
}

CAT_COLS = ["EXTC_CODE", "MIC", "COMPANY_CODE", "STATE", "INVOICE_SOURCE"]


# =============================================================================
# RULES ENGINE  (VERBATIM business logic from the legacy notebook)
# =============================================================================
def load_rules(excel_path=None):
    if not excel_path:
        print("   [RULES] No Excel path — all invoices go to ML.")
        empty = pd.DataFrame(columns=["rule", "cluster"])
        return {"keyword": empty, "generic": empty, "parker_volpe": pd.DataFrame()}

    local_path = "/tmp/cluster_rules.xlsx"
    get_dbutils().fs.cp(excel_path, f"file:{local_path}", recurse=False)

    keyword_df = pd.read_excel(local_path, sheet_name="Keyword Rules")
    generic_df = pd.read_excel(local_path, sheet_name="Generic Rules")
    pv_raw     = pd.read_excel(local_path, sheet_name="Parker Volpe - Rules")

    keyword_df.columns = ["rule", "cluster", "generic_satisfied"]
    generic_df.columns = ["rule", "cluster", "generic_satisfied", "notes"]

    rules = {
        "keyword":      keyword_df.dropna(subset=["rule", "cluster"]),
        "generic":      generic_df.dropna(subset=["rule", "cluster"]),
        "parker_volpe": _parse_parker_volpe(pv_raw),
    }
    print(f"   Keyword: {len(rules['keyword'])}  Generic: {len(rules['generic'])}  Parker Volpe: {len(rules['parker_volpe'])}")
    return rules


def _parse_parker_volpe(raw):
    # NOTE (known issue, intentionally unchanged): hardcoded iloc row ranges are
    # brittle to Excel layout changes. Preserved verbatim per "everything same".
    records = []
    records.append({"extc": "69A", "cluster": "Operating Lease", "rule_type": "extc_only"})

    for _, row in raw.iloc[6:18, :2].dropna(how="all").iterrows():
        if pd.notna(row.iloc[0]) and pd.notna(row.iloc[1]):
            records.append({"vendor_name": str(row.iloc[0]).strip(), "cluster": str(row.iloc[1]).strip(), "rule_type": "vendor_only"})

    for _, row in raw.iloc[21:29, :3].dropna(how="all").iterrows():
        if pd.notna(row.iloc[0]) and pd.notna(row.iloc[2]):
            records.append({"vendor_name": str(row.iloc[0]).strip(), "extc": str(row.iloc[1]).strip(), "cluster": str(row.iloc[2]).strip(), "rule_type": "vendor_extc"})

    for _, row in raw.iloc[32:42, :3].dropna(how="all").iterrows():
        if pd.notna(row.iloc[0]) and pd.notna(row.iloc[2]):
            records.append({"vendor_name": str(row.iloc[0]).strip(), "description_keyword": str(row.iloc[1]).strip() if pd.notna(row.iloc[1]) else "", "cluster": str(row.iloc[2]).strip(), "rule_type": "vendor_desc"})

    for _, row in raw.iloc[45:50, :4].dropna(how="all").iterrows():
        if pd.notna(row.iloc[0]) and pd.notna(row.iloc[3]):
            records.append({"vendor_name": str(row.iloc[0]).strip(), "description_keyword": str(row.iloc[1]).strip() if pd.notna(row.iloc[1]) else "", "extc": str(row.iloc[2]).strip(), "cluster": str(row.iloc[3]).strip(), "rule_type": "vendor_desc_extc"})

    return pd.DataFrame(records)


def _assign(df, condition, cluster_name, rule_label):
    """Overwrite cluster/rule_matched where condition is True. Later calls win."""
    return (
        df.withColumn("cluster",      when(condition, lit(cluster_name)).otherwise(col("cluster")))
          .withColumn("rule_matched", when(condition, lit(rule_label)).otherwise(col("rule_matched")))
    )


def _desc_contains(*keywords):
    if not keywords:
        return lit(False)
    cond = lower(col("final_description")).like(f"%{keywords[0].lower()}%")
    for kw in keywords[1:]:
        cond = cond | lower(col("final_description")).like(f"%{kw.lower()}%")
    return cond


def build_final_description(df):
    filler = ["SCM Purchase", "SCM PURCHASE", "scm purchase"]

    def _clean(c):
        return when(col(c).isin(filler) | col(c).isNull(), lit(None)).otherwise(col(c))

    df = (df.withColumn("_l", _clean(COLS["line_description"]))
            .withColumn("_d", _clean(COLS["description"]))
            .withColumn("_x", _clean(COLS["dist_all_description"])))

    df = df.withColumn("final_description", coalesce(
        when(col("_l").isNotNull() & col("_d").isNotNull(), concat_ws(" ", col("_l"), col("_d"))),
        col("_l"), col("_d"), col("_x"), lit(""),
    )).drop("_l", "_d", "_x")
    return df


def _apply_keyword_rules(df, keyword_rules):
    if keyword_rules.empty:
        return df
    for _, rule in keyword_rules.iterrows():
        raw = str(rule["rule"]).strip()
        if "but not" in raw.lower():
            base, excl_str = raw.lower().split("but not", 1)
            excls = [e.strip() for e in excl_str.replace("(", "").replace(")", "").split(",")]
            cond  = lower(col("final_description")).like(f"%{base.strip()}%")
            for e in excls:
                cond = cond & ~lower(col("final_description")).like(f"%{e}%")
        elif "," in raw:
            cond = _desc_contains(*[k.strip() for k in raw.split(",")])
        else:
            cond = lower(col("final_description")).like(f"%{raw.lower()}%")
        df = _assign(df, cond, rule["cluster"], f"kw:{raw[:40]}")
    return df


def _apply_generic_rules(df):
    MIC    = COLS["mic"]
    EXTC   = COLS["extc"]
    ACCT   = COLS["account_code"]
    VENDOR = COLS["vendor_name"]
    CO     = COLS["company_code"]

    df = _assign(df, col(MIC) == "SW",                            "ERTU",                              "generic:mic=SW")
    df = _assign(df, col(MIC).isin(["CPEMIS", "CPERTR"]),         "CPE",                               "generic:mic=CPEMIS/CPERTR")
    df = _assign(df, col(MIC) == "CEQ",                           "Computer Equipments",               "generic:mic=CEQ")
    df = _assign(df, col(MIC).isin(["COE10K", "CHROR1K"]),        "Miscellaneous Materials - Telecom", "generic:mic=COE10K/CHROR1K")
    df = _assign(df, col(MIC).like("SEQ%"),                       "Network Equipment",                 "generic:mic=SEQ%")
    df = _assign(df, col(MIC).like("NEQ%"),                       "Network Equipment",                 "generic:mic=NEQ%")
    df = _assign(df, col(MIC).like("TOWER%"),                     "Tower Materials",                   "generic:mic=TOWER%")
    df = _assign(df, col(MIC).like("CEQ%"),                       "Telecom Equipment",                 "generic:mic=CEQ%")
    df = _assign(df, col(MIC).like("FBR%") & col(MIC).like("%K"), "Telecom Equipment",                 "generic:mic=FBR%K")
    df = _assign(df, col(MIC).like("ANT%") & col(MIC).like("%K"), "Communications Equipment",          "generic:mic=ANT%K")
    df = _assign(df, col(EXTC) == "48C",                          "Freight - Common Carrier Charges",  "generic:extc=48C")
    df = _assign(df, col(EXTC) == "89Q",                          "Research and Development",          "generic:extc=89Q")
    df = _assign(df, col(EXTC).like("894%"),                      "Permits",                           "generic:extc=894%")
    df = _assign(df, (col(EXTC) == "520") & col(MIC).isin(["COE1K", "COEOTHER"]), "Miscellaneous Materials - Telecom", "generic:extc=520+mic")
    df = _assign(df, (col(MIC) == "COEOTHER") & (col(EXTC) == "450"), "Contract plant labor", "generic:mic=COEOTHER+extc=450")
    df = _assign(df, (col(MIC) == "COEOTHER") & (col(EXTC) == "460"), "Vendor Engineering",   "generic:mic=COEOTHER+extc=460")
    df = _assign(df, col(MIC).like("EFI%") & (col(EXTC) == "450"),    "Contract plant labor", "generic:mic=EFI%+extc=450")
    df = _assign(df, (col(MIC) == "CPEMIS") & (col(EXTC) == "48C"),   "Freight",              "generic:mic=CPEMIS+extc=48C")
    df = _assign(df, (col(EXTC) == "520") & col(ACCT).like("%M"),     "Maintenance",          "generic:extc=520+account=%M")
    df = _assign(df, col(ACCT).like("1130%"),                        "Nontaxable",           "generic:account=1130%")
    df = _assign(df, col(ACCT).isin(["1220.121", "1220.147"]),       "Inventory",            "generic:account=1220.x")
    df = _assign(df, col(ACCT).like("4010%") & ~_desc_contains("freight charges"), "Inventory", "generic:account=4010%")
    df = _assign(df, (col(ACCT) == "6124.570M") & (col(EXTC) == "6A9"), "Operating Lease",     "generic:account=6124.570M+extc=6A9")
    df = _assign(df, (col(ACCT) == "399C") & (col(EXTC) == "61J"),      "Software - ERTU",     "generic:account=399C+extc=61J")
    df = _assign(df, col(ACCT) == "6114.1",                            "Tools and Testing Equipment", "generic:account=6114.1")
    df = _assign(df, (col(ACCT) == "6114.1") & _desc_contains("insulated gloves"), "Safety Equipment", "generic:account=6114.1+gloves")
    df = _assign(df, (col(EXTC) == "450") & (col(ACCT) == "2003.85C"),  "Outside Plant Construction", "generic:extc=450+account=2003.85C")
    df = _assign(df, (col(EXTC) == "460") & (col(ACCT) == "2003.85C"),  "Outside Plant Construction", "generic:extc=460+account=2003.85C")

    for vendor, cluster in {
        "IRON MOUNTAIN": "Storage Services", "DIVERSIFIED WIRE & CABLE": "Cable - Nonmetalic",
        "CISCO SYSTEMS CAPITAL": "Capital Lease", "TEKSYSTEMS INC": "Data Processing",
        "HIGHTOWERS PETROLEUM": "Propane / Fuels", "JK COMMUNICATIONS": "Real Property Construction",
        "AMERICAN SAFETY UTILITY": "Safety Equipment", "IMAGE SOLUTIONS APPAREL": "Safety Equipment",
        "SAF T GARD INTERNATIONAL": "Safety Equipment", "STANLEY CONVERGENT": "Security Service",
        "CANTEEN ONE": "Food/Beverage", "ARAMARK REFRESHMENT": "Food/Beverage",
    }.items():
        df = _assign(df, col(VENDOR).like(f"%{vendor}%"), cluster, f"generic:vendor={vendor}")

    df = _assign(df, col(CO) == "7M39", "DTV", "generic:company=7M39")
    df = _assign(df, _desc_contains("landscape") & (col(ACCT) == "6121.235") & (col(CO) == "SS00"), "Landscape Services", "generic:landscape+6121.235")
    df = _assign(df, _desc_contains("base service") & (col(ACCT) == "6123.91"), "Security service", "generic:base_service+6123.91")
    df = _assign(df, _desc_contains("ceeot") & (col(EXTC) == "455"), "Installation Services - Telecom", "generic:ceeot+455")
    df = _assign(df, _desc_contains("ceeot") & (col(EXTC) == "465"), "Vendor Engineering", "generic:ceeot+465")
    df = _assign(df, _desc_contains("ceeot") & (col(EXTC) == "520"), "Miscellaneous Materials - Telecom", "generic:ceeot+520")
    return df


def _apply_parker_volpe_rules(df, pv_rules):
    if pv_rules.empty or "rule_type" not in pv_rules.columns:
        return df
    EXTC   = COLS["extc"]
    VENDOR = COLS["vendor_name"]
    for _, r in pv_rules[pv_rules["rule_type"] == "extc_only"].iterrows():
        df = _assign(df, col(EXTC) == r["extc"], r["cluster"], f"pv:extc={r['extc']}")
    for _, r in pv_rules[pv_rules["rule_type"] == "vendor_only"].iterrows():
        df = _assign(df, col(VENDOR) == r["vendor_name"], r["cluster"], f"pv:vendor={r['vendor_name']}")
    for _, r in pv_rules[pv_rules["rule_type"] == "vendor_extc"].iterrows():
        df = _assign(df, (col(VENDOR) == r["vendor_name"]) & col(EXTC).isin([e.strip() for e in str(r.get("extc", "")).split("OR")]), r["cluster"], "pv:vendor+extc")
    for _, r in pv_rules[pv_rules["rule_type"] == "vendor_desc"].iterrows():
        df = _assign(df, (col(VENDOR) == r["vendor_name"]) & _desc_contains(*[k.strip() for k in str(r.get("description_keyword", "")).split("OR")]), r["cluster"], "pv:vendor+desc")
    for _, r in pv_rules[pv_rules["rule_type"] == "vendor_desc_extc"].iterrows():
        df = _assign(df, (col(VENDOR) == r["vendor_name"]) & _desc_contains(*[k.strip() for k in str(r.get("description_keyword", "")).split("OR")]) & col(EXTC).isin([e.strip() for e in str(r.get("extc", "")).split("OR")]), r["cluster"], "pv:vendor+desc+extc")
    return df


def build_labels(df, rules, spark):
    """Apply rules, map clusters -> account codes, tag label_source = rule / no_rule."""
    df = build_final_description(df)
    df = df.withColumn("cluster",      lit(None).cast("string"))
    df = df.withColumn("rule_matched", lit(None).cast("string"))

    df = _apply_keyword_rules(df, rules["keyword"])
    df = _apply_generic_rules(df)
    df = _apply_parker_volpe_rules(df, rules["parker_volpe"])

    map_path = PATHS.get("cluster_account_map")
    if map_path:
        cmap = spark.read.csv(map_path, header=True).withColumnRenamed("cluster", "_c")
        df   = df.join(F.broadcast(cmap), col("cluster") == col("_c"), "left").drop("_c")
        df   = df.withColumn("label_account_code",
                             when(col("cluster").isNotNull() & col("account_code_mapped").isNotNull(), col("account_code_mapped"))
                             .otherwise(col(COLS["account_code"])))
    else:
        df = df.withColumn("account_code_mapped", lit(None).cast("string"))
        df = df.withColumn("label_account_code", col(COLS["account_code"]))

    df = df.withColumn("label_source",
                       when(col("cluster").isNotNull(), lit("rule")).otherwise(lit("no_rule")))

    rule_n = df.filter(col("label_source") == "rule").count()
    total  = df.count()
    if total:
        print(f"   Rule-matched: {rule_n:,} ({rule_n/total*100:.1f}%)  |  To ML: {total-rule_n:,} ({(total-rule_n)/total*100:.1f}%)")
    return df


# =============================================================================
# FEATURE ENGINEERING  (VERBATIM)
# =============================================================================
_tfidf_vec = None   # fitted TfidfVectorizer (restored by load_artifacts)


def _hash_vendor(name, n_bins=5000):
    return int(hashlib.md5(str(name).encode()).hexdigest(), 16) % n_bins


def _fit_tfidf(texts):
    global _tfidf_vec
    _tfidf_vec = TfidfVectorizer(
        max_features=MODEL_CONFIG["tfidf_max_features"],
        ngram_range=(1, 2), sublinear_tf=True, min_df=2, analyzer="word",
    )
    return _tfidf_vec.fit_transform(texts).toarray().astype(np.float32)


def _transform_tfidf(texts):
    return _tfidf_vec.transform(texts).toarray().astype(np.float32)


def build_feature_matrix(pdf, cat_encoders=None, fit=False):
    raw_texts = pdf["final_description"].fillna("").astype(str).tolist()
    X_text = _fit_tfidf(raw_texts) if fit else _transform_tfidf(raw_texts)

    cat_parts = []
    if fit:
        cat_encoders = {}
    for c in CAT_COLS:
        vals = pdf[c].fillna("UNKNOWN").astype(str).values
        if fit:
            enc = LabelEncoder()
            enc.fit(np.append(vals, "UNKNOWN"))
            cat_encoders[c] = enc
        else:
            enc   = cat_encoders[c]
            known = set(enc.classes_)
            vals  = np.array([v if v in known else "UNKNOWN" for v in vals])
        cat_parts.append(enc.transform(vals).reshape(-1, 1).astype(np.float32))

    vendor_hashes = (pdf[COLS["vendor_name"]].fillna("")
                     .apply(_hash_vendor).values.reshape(-1, 1).astype(np.float32))
    amounts = (np.log1p(np.abs(pdf[COLS["tran_amount"]].fillna(0).astype(float).values))
               .reshape(-1, 1).astype(np.float32))

    X = np.hstack([X_text] + cat_parts + [vendor_hashes, amounts])
    return X, cat_encoders


# =============================================================================
# ARTIFACT LOADING  (VERBATIM)  — existing DBFS model, no retrain
# =============================================================================
def load_artifacts():
    global _tfidf_vec
    xgb = XGBClassifier()
    xgb.load_model(PATHS["xgb_model"])
    lgb = Booster(model_file=PATHS["lgb_model"])
    with open(PATHS["label_encoder"], "rb") as f: label_enc    = pickle.load(f)
    with open(PATHS["cat_encoders"],  "rb") as f: cat_encoders = pickle.load(f)
    with open(PATHS["tfidf"],         "rb") as f: _tfidf_vec   = pickle.load(f)
    print("   Artifacts loaded (existing DBFS model — unchanged).")
    return xgb, lgb, label_enc, cat_encoders


# =============================================================================
# ENSEMBLE PREDICTION  (model core VERBATIM; join grain FIXED — see README)
# =============================================================================
def predict_no_rule(df_no_rule, xgb, lgb, label_enc, cat_encoders, spark):
    """
    Run the EXISTING XGB+LGB ensemble on no_rule records and return raw
    predictions only. The architecture's agreement / ai_query routing is applied
    downstream in t32 (this keeps the model core untouched).
    Returns: invoice_id, inv_line_number, xgb_pred, xgb_conf, lgb_pred, lgb_conf,
             models_agree, final_pred, final_conf.
    """
    id_col   = COLS["invoice_id"]
    line_col = COLS["inv_line_number"]

    select_cols = ([id_col, line_col, "final_description"]
                   + CAT_COLS + [COLS["vendor_name"], COLS["tran_amount"]])
    available = [c for c in select_cols if c in df_no_rule.columns]
    pdf = df_no_rule.select(available).toPandas()

    if len(pdf) == 0:
        return None

    X, _ = build_feature_matrix(pdf, cat_encoders=cat_encoders, fit=False)

    w_xgb = MODEL_CONFIG["ensemble_weights"]["xgb"]
    w_lgb = MODEL_CONFIG["ensemble_weights"]["lgb"]
    xgb_prob = xgb.predict_proba(X)
    lgb_prob = lgb.predict(X)
    ens_prob = w_xgb * xgb_prob + w_lgb * lgb_prob

    xgb_idx = np.argmax(xgb_prob, axis=1)
    lgb_idx = np.argmax(lgb_prob, axis=1)
    ens_idx = np.argmax(ens_prob, axis=1)

    xgb_pred = label_enc.inverse_transform(xgb_idx)
    lgb_pred = label_enc.inverse_transform(lgb_idx)
    ens_pred = label_enc.inverse_transform(ens_idx)
    ens_conf = ens_prob[np.arange(len(ens_prob)), ens_idx]
    xgb_conf = xgb_prob[np.arange(len(xgb_prob)), xgb_idx]
    lgb_conf = lgb_prob[np.arange(len(lgb_prob)), lgb_idx]

    agree = (xgb_idx == lgb_idx)

    pdf_out = pd.DataFrame({
        id_col:         pdf[id_col].values,
        line_col:       pdf[line_col].values,
        "xgb_pred":     xgb_pred,
        "xgb_conf":     xgb_conf.astype(float),
        "lgb_pred":     lgb_pred,
        "lgb_conf":     lgb_conf.astype(float),
        "models_agree": agree.astype(str),
        "final_pred":   ens_pred,
        "final_conf":   ens_conf.astype(float),
    })
    schema = StructType([
        StructField(id_col,         df_no_rule.schema[id_col].dataType, True),
        StructField(line_col,       df_no_rule.schema[line_col].dataType, True),
        StructField("xgb_pred",     StringType(), True),
        StructField("xgb_conf",     FloatType(),  True),
        StructField("lgb_pred",     StringType(), True),
        StructField("lgb_conf",     FloatType(),  True),
        StructField("models_agree", StringType(), True),
        StructField("final_pred",   StringType(), True),
        StructField("final_conf",   FloatType(),  True),
    ])
    return spark.createDataFrame(pdf_out, schema=schema)


# =============================================================================
# DELTA HELPERS
# =============================================================================
def write_stage(df, name, mode="overwrite"):
    (df.write.format("delta").mode(mode)
       .option("overwriteSchema", "true").saveAsTable(name))
    print(f"   -> wrote {name}")


def read_stage(name, spark):
    return spark.read.table(name)


# =============================================================================
# CLUSTER DISCOVERY + EXCEL REPORT  (VERBATIM legacy behavior, TF-IDF based)
# =============================================================================
def discover_new_clusters(df, spark):
    """KMeans (auto-k via silhouette) on TF-IDF of need_to_review descriptions.
    NOTE: uses TF-IDF (not MiniLM, despite the old comment). Requires the
    fitted vectorizer — loads artifacts if not already in memory."""
    if _tfidf_vec is None:
        load_artifacts()

    id_col = COLS["invoice_id"]
    df_ntr = df.filter(col("label_source") == "need_to_review")
    ntr_n  = df_ntr.count()
    print(f"   Need-to-review: {ntr_n:,}")

    df_final = df.withColumn("discovery_cluster_id", lit(None).cast("int"))
    if ntr_n < DISCOVERY_CONFIG["min_cluster_size"]:
        print("   Too few records — skipping discovery.")
        return df_final, pd.DataFrame()

    ctx_cols  = [id_col, "final_description", COLS["vendor_name"], COLS["extc"],
                 COLS["mic"], COLS["state"], COLS["tran_amount"]]
    available = [c for c in ctx_cols if c in df_ntr.columns]
    pdf       = df_ntr.select(available).toPandas()

    raw_texts_ntr = pdf["final_description"].fillna("").astype(str).tolist()
    X_emb = _transform_tfidf(raw_texts_ntr)

    max_k = max(2, min(DISCOVERY_CONFIG["max_clusters"], len(pdf) // 4, len(pdf) - 1))
    best_k, best_score = 2, -1.0
    for k in range(2, max_k + 1):
        labels = KMeans(n_clusters=k, random_state=42, n_init=5).fit_predict(X_emb)
        score  = silhouette_score(X_emb, labels, sample_size=min(500, len(pdf)))
        if score > best_score:
            best_k, best_score = k, score
    print(f"   Best k={best_k}  silhouette={best_score:.3f}")

    pdf["discovery_cluster_id"] = KMeans(
        n_clusters=best_k, random_state=DISCOVERY_CONFIG["random_seed"], n_init=10
    ).fit_predict(X_emb)

    sizes = pdf["discovery_cluster_id"].value_counts()
    valid = sizes[sizes >= DISCOVERY_CONFIG["min_cluster_size"]].index
    pdf["discovery_cluster_id"] = pdf["discovery_cluster_id"].apply(lambda c: int(c) if c in valid else -1)

    rows = []
    for cid in sorted(valid):
        sub = pdf[pdf["discovery_cluster_id"] == cid]
        rows.append({
            "cluster_id": int(cid), "record_count": len(sub),
            "proposed_cluster_name": "", "proposed_account_code": "",
            "top_vendors":  ", ".join(sub[COLS["vendor_name"]].value_counts().head(3).index.tolist()),
            "top_extc_codes": ", ".join(sub[COLS["extc"]].value_counts().head(3).index.tolist()),
            "top_states":   ", ".join(sub[COLS["state"]].value_counts().head(3).index.tolist()),
            "avg_tran_amount": round(sub[COLS["tran_amount"]].astype(float).mean(), 2),
            "sample_descriptions": " | ".join(sub["final_description"].dropna().head(DISCOVERY_CONFIG["samples_per_cluster"]).tolist()),
        })
    cluster_summary = pd.DataFrame(rows)

    cid_spark = spark.createDataFrame(pdf[[id_col, "discovery_cluster_id"]])
    df_final  = df.drop("discovery_cluster_id").join(cid_spark, on=id_col, how="left")
    print(f"   Valid clusters: {len(valid)}")
    return df_final, cluster_summary


def generate_report(df, cluster_summary, report_month):
    from pyspark.sql.functions import avg
    timestamp  = datetime.now().strftime("%Y%m%d_%H%M")
    local_file = f"/tmp/NeedToReview_{report_month}_{timestamp}.xlsx"

    total  = df.count()
    counts = df.groupBy("label_source").agg(count("*").alias("n")).toPandas()

    def _n(src):
        return int(counts[counts["label_source"] == src]["n"].sum()) if src in counts["label_source"].values else 0

    rule_n, ml_n, ntr_n = _n("rule"), _n("ml"), _n("need_to_review")
    avg_row = df.filter(col("label_source") == "ml").agg(avg("final_conf")).collect()[0][0]
    avg_c   = round(float(avg_row), 4) if avg_row else 0.0

    summary_df = pd.DataFrame([
        {"Metric": "Total Invoices Processed", "Value": total, "Pct": "100%"},
        {"Metric": "Classified by Rules", "Value": rule_n, "Pct": f"{rule_n/total*100:.1f}%" if total else "0%"},
        {"Metric": "Classified by ML", "Value": ml_n, "Pct": f"{ml_n/total*100:.1f}%" if total else "0%"},
        {"Metric": "Need Human Review", "Value": ntr_n, "Pct": f"{ntr_n/total*100:.1f}%" if total else "0%"},
        {"Metric": "Avg ML Confidence (ML records)", "Value": avg_c, "Pct": ""},
    ])

    desired = [COLS["invoice_id"], COLS["invoice_num"], "final_description",
               COLS["vendor_name"], COLS["extc"], COLS["mic"], COLS["state"],
               COLS["tran_amount"], COLS["account_code"], "final_category",
               "taxability", "Reverse_UseTax", "short_justification",
               "xgb_pred", "xgb_conf", "lgb_pred", "lgb_conf",
               "final_pred", "final_conf", "decision_path", "review_priority",
               "anomaly_score", "discovery_cluster_id"]
    existing = [c for c in desired if c in df.columns]
    order_by = "discovery_cluster_id" if "discovery_cluster_id" in df.columns else COLS["invoice_id"]
    raw_pdf  = (df.filter(col("label_source") == "need_to_review")
                  .select(existing).orderBy(order_by).toPandas())

    with pd.ExcelWriter(local_file, engine="openpyxl") as writer:
        summary_df.to_excel(writer, sheet_name="Executive Summary", index=False)
        if cluster_summary is not None and not cluster_summary.empty:
            cluster_summary.to_excel(writer, sheet_name="Discovered Clusters", index=False)
            try:
                from openpyxl.styles import PatternFill
                ws = writer.sheets["Discovered Clusters"]
                yellow = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
                headers = [c.value for c in ws[1]]
                for fc in ["proposed_cluster_name", "proposed_account_code"]:
                    if fc in headers:
                        ci = headers.index(fc) + 1
                        for row in ws.iter_rows(min_row=2, min_col=ci, max_col=ci):
                            for cell in row:
                                cell.fill = yellow
            except Exception:
                pass
        else:
            pd.DataFrame({"message": ["No new clusters this month."]}).to_excel(
                writer, sheet_name="Discovered Clusters", index=False)
        raw_pdf.to_excel(writer, sheet_name="Raw NTR Records", index=False)

    if PATHS.get("reports_output"):
        adls = f"{PATHS['reports_output']}NeedToReview_{report_month}_{timestamp}.xlsx"
        get_dbutils().fs.cp(f"file:{local_file}", adls, recurse=False)
        print(f"   Report -> ADLS: {adls}")
        return adls
    print(f"   Report -> driver /tmp: {local_file}")
    return local_file
